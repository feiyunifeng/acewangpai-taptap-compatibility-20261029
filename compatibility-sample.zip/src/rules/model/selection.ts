import type { Command, TriggerChoice } from './command.js';

/** Target and material selections are sets; preserve duplicates for validation to reject. */
export function canonicalIds(ids: readonly string[]): readonly string[] {
  return [...ids].sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
}

export function canonicalTriggerChoice(choice: TriggerChoice): TriggerChoice {
  return { ...choice,
    ...(choice.targetIds ? { targetIds: canonicalIds(choice.targetIds) } : {}),
    ...(choice.materialIds ? { materialIds: canonicalIds(choice.materialIds) } : {}),
  };
}

export function canonicalCommandSelections(command: Command): Command {
  switch (command.type) {
    case 'ruleSummonTerminal': return { ...command, materialIds: canonicalIds(command.materialIds) };
    case 'activateEffect': return { ...command,
      ...(command.targetIds ? { targetIds: canonicalIds(command.targetIds) } : {}),
      ...(command.materialIds ? { materialIds: canonicalIds(command.materialIds) } : {}),
    };
    case 'chooseTriggers': return { ...command,
      ...(command.choices ? { choices: command.choices.map(canonicalTriggerChoice) } : {}),
    };
    default: return command;
  }
}
