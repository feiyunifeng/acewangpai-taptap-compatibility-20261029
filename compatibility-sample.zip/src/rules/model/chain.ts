import type { EffectSource, EffectSpeed } from './effect.js';
import type { CardInstanceId, PlayerId } from './ids.js';
import type { Zone } from './state.js';
import type { TriggerCandidate } from './effect.js';
import type { IdentityVisibility } from './event.js';

export interface ChainLink {
  readonly id: string;
  readonly player: PlayerId;
  readonly source: EffectSource;
  readonly sourceName: string;
  readonly effectId: string;
  readonly sourceVisibility: IdentityVisibility;
  readonly speed: EffectSpeed;
  readonly responseTo?: string;
  readonly targetSnapshots: readonly { readonly id: CardInstanceId; readonly player: PlayerId; readonly zone: Zone;
    readonly zoneEntrySequence: number }[];
  readonly responseSourceSnapshot?: { readonly id: CardInstanceId; readonly player: PlayerId; readonly zone: Zone;
    readonly zoneEntrySequence: number };
  readonly costCardId?: CardInstanceId;
  readonly resourceCostCardId?: CardInstanceId;
  readonly tpCost: number;
  readonly payment: { readonly tp: number; readonly life: number };
  readonly terminalId?: CardInstanceId;
  readonly materialIds?: readonly CardInstanceId[];
  readonly terminalZone?: 'normal' | 'frontline';
  readonly terminalSlot?: number;
  readonly fieldMarkSlot?: number;
  readonly activationNegated: boolean;
  readonly effectNegated: boolean;
  readonly triggerOrigin?: TriggerCandidate['sourceLocation'];
}
