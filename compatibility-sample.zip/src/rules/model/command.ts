import type { CardInstanceId, PlayerId } from './ids.js';
import type { BattleTarget, Phase } from './state.js';
import type { EffectSource } from './effect.js';

export interface AdvancePhaseCommand {
  readonly type: 'advancePhase';
  readonly player: PlayerId;
  readonly to: Phase;
}

/** Explicit end-of-turn transition after cleanup and hand-limit choices settle. */
export interface AdvanceTurnCommand {
  readonly type: 'advanceTurn';
  readonly player: PlayerId;
}

export interface DrawCardCommand {
  readonly type: 'drawCard';
  readonly player: PlayerId;
}

export interface RuleSummonMonsterCommand {
  readonly type: 'ruleSummonMonster';
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly materialIds?: readonly CardInstanceId[];
  readonly slot?: number;
}

export interface DiscardCardCommand {
  readonly type: 'discardCard';
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
}

export interface ConcedeCommand {
  readonly type: 'concede';
  readonly player: PlayerId;
}

export interface RuleSummonTerminalCommand {
  readonly type: 'ruleSummonTerminal';
  readonly player: PlayerId;
  readonly terminalId: CardInstanceId;
  readonly materialIds: readonly CardInstanceId[];
  readonly zone?: 'normal' | 'frontline';
  readonly slot?: number;
}

export interface PassSummonResponseCommand {
  readonly type: 'passSummonResponse';
  readonly player: PlayerId;
}

export interface ActivateEffectCommand {
  readonly type: 'activateEffect';
  readonly player: PlayerId;
  readonly source: EffectSource;
  readonly effectId: string;
  readonly responseTo?: string;
  readonly costCardId?: CardInstanceId;
  readonly resourceCostCardId?: CardInstanceId;
  readonly targetIds?: readonly CardInstanceId[];
  readonly terminalId?: CardInstanceId;
  readonly materialIds?: readonly CardInstanceId[];
  readonly terminalZone?: 'normal' | 'frontline';
  readonly terminalSlot?: number;
  readonly fieldMarkSlot?: number;
}

export interface PassPriorityCommand {
  readonly type: 'passPriority';
  readonly player: PlayerId;
}

/** Use a one-shot Summoner Skill directly; this command never opens a chain. */
export interface UseSkillCommand {
  readonly type: 'useSkill';
  readonly player: PlayerId;
  readonly skillCopyId: string;
}

export interface SetCardCommand {
  readonly type: 'setCard';
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly slot?: number;
}

export interface ChooseTriggersCommand {
  readonly type: 'chooseTriggers';
  readonly player: PlayerId;
  /** Mandatory IDs must be included; optional IDs may be omitted. Order is player-chosen within each group. */
  readonly orderedTriggerIds: readonly string[];
  readonly choices?: readonly TriggerChoice[];
}

export interface ChooseResolutionCardCommand {
  readonly type: 'chooseResolutionCard';
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly destination?: 'hand' | 'spellCounter';
}

export interface FinishResolutionChoiceCommand {
  readonly type: 'finishResolutionChoice';
  readonly player: PlayerId;
}

export interface DeclareAttackCommand {
  readonly type: 'declareAttack';
  readonly player: PlayerId;
  readonly attackerId: CardInstanceId;
  readonly target: BattleTarget;
}

export interface ChooseBattleTargetCommand {
  readonly type: 'chooseBattleTarget';
  readonly player: PlayerId;
  readonly target: BattleTarget | null;
}

export interface TriggerChoice {
  readonly triggerId: string;
  readonly costCardId?: CardInstanceId;
  readonly resourceCostCardId?: CardInstanceId;
  readonly targetIds?: readonly CardInstanceId[];
  readonly terminalId?: CardInstanceId;
  readonly materialIds?: readonly CardInstanceId[];
  readonly terminalZone?: 'normal' | 'frontline';
  readonly terminalSlot?: number;
  readonly fieldMarkSlot?: number;
}

export type Command = AdvancePhaseCommand | AdvanceTurnCommand | DrawCardCommand | RuleSummonMonsterCommand | DiscardCardCommand |
  ConcedeCommand | RuleSummonTerminalCommand | PassSummonResponseCommand | ActivateEffectCommand |
  PassPriorityCommand | UseSkillCommand | SetCardCommand | ChooseTriggersCommand | ChooseResolutionCardCommand | FinishResolutionChoiceCommand |
  DeclareAttackCommand | ChooseBattleTargetCommand;

export type RuleErrorCode = 'CATALOG_MISMATCH' | 'GAME_OVER' | 'NOT_TURN_PLAYER' | 'NOT_OPEN_WINDOW' |
  'INVALID_PHASE' | 'DRAW_NOT_REQUIRED' | 'INVALID_CARD' | 'WRONG_ZONE' | 'WRONG_CARD_TYPE' |
  'ZONE_FULL' | 'HAND_LIMIT_NOT_EXCEEDED' | 'NAME_ALREADY_ACTIVATED' | 'MOVE_FAILED' |
  'SUMMON_QUOTA_USED' | 'INVALID_MATERIAL' | 'INVALID_SUMMON' | 'INVALID_RESPONSE' |
  'UNKNOWN_EFFECT' | 'INVALID_EFFECT_SOURCE' | 'INVALID_EFFECT_TIMING' | 'INVALID_EFFECT_SPEED' |
  'INVALID_TARGET' | 'INVALID_COST' | 'SKILL_USED' | 'SKILL_LIMIT_REACHED' | 'SKILL_DUPLICATE_RESPONSE' |
  'INVALID_TRIGGER_CHOICE' | 'INVALID_RESOLUTION_CHOICE' | 'INVALID_ATTACK' | 'INVALID_ATTACK_TARGET' | 'INSUFFICIENT_TP' |
  'UNRESOLVED_RULE';

export interface RuleError {
  readonly code: RuleErrorCode;
}
