import type { CardId, SkillId } from './ids.js';
import type { ArchetypeId } from './archetype.js';
import type { EffectDefinition } from './effect.js';

export type CardKind = 'monster' | 'spell' | 'counter';
export type CardDeck = 'main' | 'extra';
export type CardAlignment = 'pride' | 'envy' | 'wrath' | 'sloth' | 'greed' | 'gluttony' | 'lust' |
  'chastity' | 'temperance' | 'charity' | 'diligence' | 'kindness' | 'patience' | 'humility';

export interface CardEffectDetails {
  readonly effectIndex: 1 | 2 | 3;
  readonly effectName: string;
  readonly effectSummary: string;
  readonly effectText: string;
  readonly conditions?: readonly string[];
  readonly additionalCosts?: readonly string[];
}

/** Immutable catalog data. Card instances retain only definition IDs. */
export interface CardDefinition {
  readonly id: CardId;
  readonly name: string;
  readonly kind: CardKind;
  readonly deck: CardDeck;
  /** Canonical name-field memberships used by search, buffs, and summon filters. */
  readonly archetypeIds?: readonly ArchetypeId[];
  readonly profession?: string;
  /** Printed Seven Sins / Seven Virtues trait. */
  readonly alignment?: CardAlignment;
  /** Positive printed level; also the default TP price of card effects. */
  readonly level: number;
  /** Enables V1.3 card-design level-gate validation without retroactively invalidating legacy cards. */
  readonly designVersion?: '1.3' | '2.0';
  readonly atk?: number;
  readonly def?: number;
  /** Missing official main-monster combat numbers are explicit data gaps, never implicit zeroes. */
  readonly combatStatsStatus?: 'pending';
  /** Optional fixed battle damage for a mage's direct spell attack. */
  readonly directAttackDamage?: number;
  /** Structured printed numbered effects for human-readable inspectors. */
  readonly effectDetails?: readonly CardEffectDetails[];
  /** Restricted main monsters cannot be rule-summoned from hand. */
  readonly noRuleSummon?: boolean;
  /** A main monster may only be special-summoned from hand by an effect on this card. */
  readonly noOtherEffectSummonFromHand?: boolean;
  readonly spellMode?: 'normal' | 'quick' | 'continuous';
  readonly effectIds?: readonly string[];
  readonly materialConditionId?: 'sameArchetype' | 'sameProfession' | 'atLeastTwo';
  /** If specified, a rule/effect terminal summon must use exactly this many materials. */
  readonly materialCount?: number;
  /** Every entry is an existence requirement; one material may satisfy more than one entry. */
  readonly materialRequirements?: readonly { readonly archetypeId?: ArchetypeId; readonly profession?: string; readonly deck?: CardDeck;
    readonly cardId?: CardId; readonly cardIds?: readonly CardId[]; readonly minimumLevel?: number;
    readonly maximumLevel?: number; readonly noEffects?: boolean; readonly minimumCount: number }[];
  readonly text?: string;
}

export interface SkillDefinition {
  readonly id: SkillId;
  readonly name: string;
  /** One-shot, non-chain Summoner Skill used directly during the owner's Main Phase. */
  readonly directAbility?: 'heal' | 'execute' | 'reinforcement';
  readonly speed?: 2 | 3;
  readonly effectIds?: readonly string[];
  readonly text?: string;
}

export interface CardCatalog {
  readonly version: string;
  readonly cards: Readonly<Record<CardId, CardDefinition>>;
  readonly skills: Readonly<Record<SkillId, SkillDefinition>>;
  readonly effects?: Readonly<Record<string, EffectDefinition>>;
}

export interface DeckList {
  readonly main: readonly CardId[];
  readonly extra: readonly CardId[];
}
