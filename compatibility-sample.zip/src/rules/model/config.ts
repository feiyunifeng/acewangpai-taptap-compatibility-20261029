export interface RulesConfig {
  readonly version: string;
  readonly initialLife: number;
  readonly openingHand: number;
  readonly handLimit: number;
  readonly mainDeckMin: number;
  readonly mainDeckMax: number;
  readonly extraDeckMin: number;
  readonly extraDeckMax: number;
  readonly sameNameMax: number;
  readonly normalMonsterSlots: number;
  readonly frontlineSlots: number;
  readonly spellCounterSlots: number;
  readonly firstPlayerSkillCopies: number;
  readonly secondPlayerSkillCopies: number;
  readonly sameSkillMax: number;
  readonly skillsPerTurn: number;
  readonly terminalSummonsPerTurn: number;
}

export const DEFAULT_RULES_CONFIG: RulesConfig = Object.freeze({
  version: '1.3.0',
  initialLife: 6000,
  openingHand: 4,
  handLimit: 6,
  mainDeckMin: 30,
  mainDeckMax: 60,
  extraDeckMin: 0,
  extraDeckMax: 10,
  sameNameMax: 3,
  normalMonsterSlots: 3,
  frontlineSlots: 2,
  spellCounterSlots: 3,
  firstPlayerSkillCopies: 1,
  secondPlayerSkillCopies: 2,
  sameSkillMax: 2,
  skillsPerTurn: 2,
  terminalSummonsPerTurn: Number.MAX_SAFE_INTEGER,
});
