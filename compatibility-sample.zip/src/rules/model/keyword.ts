import type { CardInstanceId, PlayerId } from './ids.js';
import type { Zone } from './state.js';

export const KEYWORD_IDS = [
  'freeze', 'burn', 'weaken', 'execute', 'blast', 'send_to_heaven', 'send_to_hell', 'return_to_hand', 'return_to_deck',
] as const;
export type KeywordId = typeof KEYWORD_IDS[number];
export type KeywordCategory = 'control' | 'damage' | 'stats' | 'removal' | 'zone-movement';
export type KeywordOperationType = 'apply-card-status' | 'destroy-and-burn' | 'reduce-or-send' |
  'activated-card-send' | 'move-to-zone' | 'return-card';

export interface KeywordPresentation {
  readonly vfxKey: string;
  readonly sfxKey: string;
  readonly uiMarkerKey: string;
  readonly battleLogVerb: string;
  readonly animationHint: string;
}

export type KeywordParameterType = 'selection-key' | 'positive-integer' | 'finite-number' | 'stat' | 'phase' | 'deck-position';
export interface KeywordParameterDefinition {
  readonly name: string;
  readonly type: KeywordParameterType;
}

export interface KeywordDefinition {
  readonly keywordId: KeywordId;
  readonly displayNameZh: string;
  readonly category: KeywordCategory;
  readonly description: string;
  readonly operationType: KeywordOperationType;
  readonly parameters: readonly KeywordParameterDefinition[];
  readonly semantics: {
    readonly requiresTarget: boolean;
    readonly targetKind: 'card' | 'monster' | 'activated-card';
    readonly blocksAttack: boolean;
    readonly blocksEffectActivation: boolean;
    readonly changesZone: boolean;
    readonly countsAsDestroy: boolean;
    readonly countsAsNegate: boolean;
    readonly countsAsRelease: boolean;
    readonly countsAsSacrifice: boolean;
    readonly createsPersistentState: boolean;
    readonly durationParameter?: string;
    readonly expiryPolicy: 'none' | 'parameterized';
  };
  readonly presentation: KeywordPresentation;
}

const definition = (keywordId: KeywordId, displayNameZh: string, category: KeywordCategory,
  description: string, operationType: KeywordOperationType,
  semantics: KeywordDefinition['semantics'], animationHint: string): KeywordDefinition => ({
  keywordId, displayNameZh, category, description, operationType, parameters: parameterSchema[keywordId], semantics,
  presentation: {
    vfxKey: keywordId, sfxKey: keywordId, uiMarkerKey: ({ freeze: 'frozen', burn: 'burning', weaken: 'weakened',
      execute: 'executed', blast: 'blasted', send_to_heaven: 'heaven_sent', send_to_hell: 'hell_sent',
      return_to_hand: 'returned_hand', return_to_deck: 'returned_deck' } satisfies Record<KeywordId, string>)[keywordId],
    battleLogVerb: displayNameZh, animationHint,
  },
});

const selectionKey: KeywordParameterDefinition = { name: 'key', type: 'selection-key' };
const parameterSchema: Readonly<Record<KeywordId, readonly KeywordParameterDefinition[]>> = {
  freeze: [selectionKey, { name: 'durationTurns', type: 'positive-integer' }],
  burn: [selectionKey, { name: 'damage', type: 'positive-integer' }, { name: 'ticks', type: 'positive-integer' },
    { name: 'tickAt', type: 'phase' }],
  weaken: [selectionKey, { name: 'durationTurns', type: 'positive-integer' }],
  execute: [selectionKey, { name: 'amount', type: 'positive-integer' }],
  blast: [selectionKey],
  send_to_heaven: [selectionKey],
  send_to_hell: [selectionKey],
  return_to_hand: [selectionKey],
  return_to_deck: [selectionKey, { name: 'destination', type: 'deck-position' }],
};

const cardStatus = { requiresTarget: true, targetKind: 'monster', blocksAttack: false, blocksEffectActivation: false,
  changesZone: false, countsAsDestroy: false, countsAsNegate: false, countsAsRelease: false,
  countsAsSacrifice: false, createsPersistentState: true, durationParameter: 'durationTurns', expiryPolicy: 'parameterized' } as const;
const zoneMove = { requiresTarget: true, targetKind: 'card', blocksAttack: false, blocksEffectActivation: false,
  changesZone: true, countsAsDestroy: false, countsAsNegate: false, countsAsRelease: false,
  countsAsSacrifice: false, createsPersistentState: false, expiryPolicy: 'none' } as const;

/** Stable runtime registry. Presentation keys are API identifiers, not asset paths. */
export const KEYWORD_REGISTRY: Readonly<Record<KeywordId, KeywordDefinition>> = {
  freeze: definition('freeze', '冰冻', 'control', '目标不能攻击或发动效果；不无效其持续效果。', 'apply-card-status',
    { ...cardStatus, blocksAttack: true, blocksEffectActivation: true }, '蓝白冻结光效与冰霜锁定标记'),
  burn: definition('burn', '灼烧', 'damage', '先破坏目标，再对其控制者施加按时点结算的持续伤害。', 'destroy-and-burn',
    { requiresTarget: true, targetKind: 'monster', blocksAttack: false, blocksEffectActivation: false, changesZone: true,
      countsAsDestroy: true, countsAsNegate: false, countsAsRelease: false, countsAsSacrifice: false,
      createsPersistentState: true, durationParameter: 'ticks', expiryPolicy: 'parameterized' }, '火焰残留与周期性灼伤提示'),
  weaken: definition('weaken', '弱化', 'stats', '目标当前 ATK 与 DEF 变为 0；不破坏或无效目标。', 'apply-card-status', cardStatus,
    '紫灰衰弱波纹与数值坍塌'),
  execute: definition('execute', '斩杀', 'removal', '使目标攻击数值与防御数值各降低指定数值；任一结果低于0则送入地狱，不视为破坏或解放。', 'reduce-or-send',
    { ...zoneMove, targetKind: 'monster' }, '红色斩击划过目标后送入地狱'),
  blast: definition('blast', '爆破', 'removal', '将本回合发动过效果的合法目标送入地狱。', 'activated-card-send',
    { ...zoneMove, targetKind: 'activated-card' }, '定点爆裂并轰碎目标'),
  send_to_heaven: definition('send_to_heaven', '送入天堂', 'zone-movement', '直接移动至天堂；不视为破坏、解放或献祭。', 'move-to-zone', zoneMove,
    '上升与金白升华光效'),
  send_to_hell: definition('send_to_hell', '送入地狱', 'zone-movement', '直接移动至地狱；不视为破坏、解放或献祭。', 'move-to-zone', zoneMove,
    '下沉并被黑红裂隙吞没'),
  return_to_hand: definition('return_to_hand', '回手', 'zone-movement', '将目标返回持有者手牌并清理场上临时状态。', 'return-card', zoneMove,
    '吸回并收纳至手牌'),
  return_to_deck: definition('return_to_deck', '回组', 'zone-movement', '将目标返回持有者卡组；牌顶、牌底或洗回由参数指定。', 'return-card', zoneMove,
    '卡牌旋回并收束至卡组'),
};

export type KeywordOperation =
  | { readonly keywordId: 'freeze'; readonly key: string; readonly durationTurns: number }
  | { readonly keywordId: 'weaken'; readonly key: string; readonly durationTurns?: number;
      readonly durationPhase?: 'battleEnd' }
  | { readonly keywordId: 'burn'; readonly key: string; readonly damage: number; readonly ticks: number;
      readonly tickAt: 'turnStart' | 'turnEnd' }
  | { readonly keywordId: 'execute'; readonly key: string; readonly amount: number }
  | { readonly keywordId: 'blast'; readonly key: string }
  | { readonly keywordId: 'send_to_heaven'; readonly key: string }
  | { readonly keywordId: 'send_to_hell'; readonly key: string }
  | { readonly keywordId: 'return_to_hand'; readonly key: string }
  | { readonly keywordId: 'return_to_deck'; readonly key: string; readonly destination: 'mainDeckTop' | 'mainDeckBottom' | 'shuffle' };

export function isValidKeywordOperation(value: KeywordOperation): boolean {
  if (!value || typeof value.key !== 'string' || value.key.length === 0 || !KEYWORD_IDS.includes(value.keywordId)) return false;
  switch (value.keywordId) {
    case 'freeze': return Number.isInteger(value.durationTurns) && value.durationTurns > 0;
    case 'weaken': return value.durationPhase === 'battleEnd' || typeof value.durationTurns === 'number' &&
      Number.isInteger(value.durationTurns) && value.durationTurns > 0;
    case 'burn': return Number.isInteger(value.damage) && value.damage > 0 && Number.isInteger(value.ticks) && value.ticks > 0 &&
      (value.tickAt === 'turnStart' || value.tickAt === 'turnEnd');
    case 'execute': return Number.isInteger(value.amount) && value.amount > 0;
    case 'return_to_deck': return value.destination === 'mainDeckTop' || value.destination === 'mainDeckBottom' || value.destination === 'shuffle';
    case 'blast':
    case 'send_to_heaven':
    case 'send_to_hell':
    case 'return_to_hand': return true;
  }
}

export type KeywordStatus =
  | { readonly id: string; readonly keywordId: 'freeze' | 'weaken'; readonly sourceLinkId: string;
      readonly effectId: string; readonly player: PlayerId; readonly sourceId?: CardInstanceId;
      readonly sourceVisibility: 'public' | PlayerId; readonly targetVisibility: 'public' | PlayerId;
      readonly targetCardId: CardInstanceId; readonly targetZoneEntrySequence: number; readonly createdAtGlobalTurn: number;
      readonly expiresAtGlobalTurn?: number; readonly expiresAtPhase?: 'battleEnd' }
  | { readonly id: string; readonly keywordId: 'burn'; readonly sourceLinkId: string; readonly effectId: string;
      readonly sourceId?: CardInstanceId; readonly sourceVisibility: 'public' | PlayerId; readonly targetVisibility: 'public' | PlayerId;
      readonly player: PlayerId;
      readonly damage: number; readonly remainingTicks: number; readonly tickAt: 'turnStart' | 'turnEnd';
      readonly nextTickGlobalTurn: number };

export type KeywordEventType = 'keyword_resolve_started' | 'keyword_target_hit' | 'keyword_applied' | 'keyword_failed' |
  'keyword_status_created' | 'keyword_expired' | 'keyword_zone_moved' | 'keyword_damage_dealt';
export interface KeywordEventBase {
  readonly type: KeywordEventType;
  readonly sequence: number;
  readonly keywordId: KeywordId;
  readonly linkId: string;
  readonly effectId: string;
  readonly player: PlayerId;
  readonly sourceId?: CardInstanceId;
  readonly sourceVisibility: 'public' | PlayerId;
  readonly targetCardId?: CardInstanceId;
  readonly targetVisibility?: 'public' | PlayerId;
  readonly statusId?: string;
  readonly amount?: number;
  readonly fromZone?: Zone;
  readonly toZone?: Zone;
  readonly failure?: 'target-missing' | 'target-invalid' | 'condition-not-met' | 'move-failed' |
    'activation-negated' | 'effect-negated';
  readonly presentation: KeywordPresentation;
}
export type KeywordEvent = KeywordEventBase;

export type RuleOperationId = 'destroy' | 'release' | 'sacrifice' | 'special_summon' | 'negate_activation' |
  'negate_effect' | 'search' | 'grab' | 'no_grab';
export interface RuleOperationEvent {
  readonly type: 'ruleOperation';
  readonly sequence: number;
  readonly operationId: RuleOperationId;
  readonly player: PlayerId;
  readonly effectId?: string;
  readonly linkId?: string;
  readonly cardId?: CardInstanceId;
  readonly identityVisibility?: 'public' | PlayerId;
}

export function isKeywordStatusActive(state: import('./state.js').GameState, cardId: CardInstanceId,
  keywordId?: 'freeze' | 'weaken'): boolean {
  const card = state.cards[cardId];
  return !!card && (card.location.zone === 'normal' || card.location.zone === 'frontline') &&
    (state.keywordStatuses ?? []).some((status) => status.keywordId !== 'burn' && status.targetCardId === cardId &&
      status.targetZoneEntrySequence === card.zoneEntrySequence &&
      (status.expiresAtGlobalTurn === undefined || status.expiresAtGlobalTurn > state.globalTurn) &&
      (status.expiresAtPhase !== 'battleEnd' || state.phase === 'battle') &&
      (!keywordId || status.keywordId === keywordId));
}
