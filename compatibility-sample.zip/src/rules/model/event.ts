import type { MoveEvent } from '../engine/move-card.js';
import type { CardInstanceId, PlayerId } from './ids.js';
import type { CardInstance, Phase } from './state.js';
import type { KeywordEvent, RuleOperationEvent } from './keyword.js';

export type IdentityVisibility = 'public' | PlayerId;

/** Snapshot a card's identity audience at the instant an event is emitted. */
export function cardIdentityVisibility(card: CardInstance | undefined, fallback: PlayerId): IdentityVisibility {
  if (!card) return fallback;
  const zone = card.location.zone;
  return zone === 'heaven' || zone === 'hell' ||
    (zone === 'normal' || zone === 'frontline' || zone === 'spellCounter') && card.face === 'up'
    ? 'public' : card.location.player;
}

export interface PhaseChangedEvent {
  readonly type: 'phaseChanged';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly from: Phase;
  readonly to: Phase;
  readonly globalTurn: number;
}

export interface TpChangedEvent {
  readonly type: 'tpChanged';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly from: number;
  readonly to: number;
  readonly reason: 'turnRefresh' | 'effectCost' | 'ruleSummonCost';
}

export interface LifePaidEvent {
  readonly type: 'lifePaid';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly amount: number;
  readonly reason: 'effectCost';
}

export interface LifeRecoveredEvent {
  readonly type: 'lifeRecovered';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly amount: number;
  readonly reason: 'summonSkill';
}

export interface SummonSkillUsedEvent {
  readonly type: 'summonSkillUsed';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly skillId: string;
  readonly ability: 'heal' | 'execute' | 'reinforcement';
}

export interface MonsterSummonedEvent {
  readonly type: 'monsterSummoned';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly method: 'ruleMain' | 'effectMain' | 'ruleTerminal' | 'effectTerminal' | 'revival';
  /** Number of monsters released for this regular summon; zero for special summons. */
  readonly tributeCount?: number;
  /** Exact field materials sent to Heaven for this summon, used by material triggers. */
  readonly tributeMaterialIds?: readonly CardInstanceId[];
  readonly identityVisibility: 'public';
}

export interface TerminalSummonDeclaredEvent {
  readonly type: 'terminalSummonDeclared';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly materialIds: readonly CardInstanceId[];
  readonly identityVisibility: 'public';
}

export interface TerminalSummonNegatedEvent {
  readonly type: 'terminalSummonNegated';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly identityVisibility: 'public';
}

export interface TerminalSummonAbortedEvent {
  readonly type: 'terminalSummonAborted';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly cardId: CardInstanceId;
  readonly reason: 'NO_FRONTLINE_SLOT' | 'TARGET_UNAVAILABLE';
  readonly identityVisibility: 'public';
}

export interface GameEndedEvent {
  readonly type: 'gameEnded';
  readonly sequence: number;
  readonly winner: PlayerId | null;
  readonly reason: string;
}

export interface AttackDeclaredEvent {
  readonly type: 'attackDeclared';
  readonly sequence: number;
  readonly battleId: string;
  readonly player: PlayerId;
  readonly attackerId: CardInstanceId;
  readonly target: import('./state.js').BattleTarget;
  readonly identityVisibility: 'public';
}

export interface LifeDamagedEvent {
  readonly type: 'lifeDamaged';
  readonly sequence: number;
  readonly player: PlayerId;
  readonly amount: number;
  readonly source: 'battle' | 'effect';
  readonly battleId?: string;
  readonly battleSubtype?: 'mageSpellAttack';
}

export interface BattleResolvedEvent {
  readonly type: 'battleResolved';
  readonly sequence: number;
  readonly battleId: string;
  readonly player: PlayerId;
  readonly attackerId: CardInstanceId;
  readonly target: import('./state.js').BattleTarget;
  readonly outcome: 'directDamage' | 'destroyedDefender' | 'destroyedAttacker' | 'noDamage' | 'cancelled';
  readonly attackerVisibility: IdentityVisibility;
  readonly targetVisibility?: IdentityVisibility;
  readonly damage?: { readonly original: number; readonly rewardExchange: number; readonly otherReduction: number; readonly final: number;
    readonly rewardKind?: 'draw' | 'defense' };
}

export interface EffectActivatedEvent {
  readonly type: 'effectActivated';
  readonly sequence: number;
  readonly linkId: string;
  readonly effectId: string;
  readonly player: PlayerId;
  readonly sourceId: string;
  readonly sourceKind: 'card' | 'skill';
  readonly sourceVisibility: IdentityVisibility;
  readonly selectionMode: 'grab' | 'noGrab' | 'none';
}

export interface EffectNegationEvent {
  readonly type: 'activationNegated' | 'effectNegated';
  readonly sequence: number;
  readonly linkId: string;
  readonly effectId: string;
  readonly player: PlayerId;
  readonly sourceKind: 'card' | 'skill';
  readonly sourceVisibility: IdentityVisibility;
}

export interface EffectResolvedEvent {
  readonly type: 'effectResolved';
  readonly sequence: number;
  readonly linkId: string;
  readonly effectId: string;
  readonly player: PlayerId;
  readonly outcome: 'applied' | 'noResult' | 'activationNegated' | 'effectNegated';
  readonly sourceKind: 'card' | 'skill';
  readonly sourceVisibility: IdentityVisibility;
}

export type GameEvent = MoveEvent | PhaseChangedEvent | TpChangedEvent | LifePaidEvent | LifeRecoveredEvent | SummonSkillUsedEvent | MonsterSummonedEvent |
  TerminalSummonDeclaredEvent | TerminalSummonNegatedEvent | TerminalSummonAbortedEvent |
  AttackDeclaredEvent | LifeDamagedEvent | BattleResolvedEvent | KeywordEvent | RuleOperationEvent |
  EffectActivatedEvent | EffectNegationEvent | EffectResolvedEvent | GameEndedEvent;
