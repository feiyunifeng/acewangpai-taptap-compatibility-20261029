export type PlayerId = 'p1' | 'p2';
export type CardId = string;
export type CardInstanceId = string;
export type SkillId = string;
export type SkillCopyId = string;

export const PLAYER_IDS: readonly PlayerId[] = ['p1', 'p2'];

export function otherPlayer(player: PlayerId): PlayerId {
  return player === 'p1' ? 'p2' : 'p1';
}
