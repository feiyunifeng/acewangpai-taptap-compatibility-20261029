import type { Command } from './command.js';
import type { PlayerId } from './ids.js';
import type { GameState } from './state.js';

/** Public slot reference: it never embeds the hidden card's instance or definition ID. */
export function hiddenFieldTargetRef(state: GameState, observer: PlayerId, id: string): string {
  const card = state.cards[id];
  if (!card || card.location.player === observer || card.location.zone !== 'spellCounter' ||
    card.location.slot === undefined || card.face !== 'down') return id;
  return `hidden-field:${card.location.player}:${card.location.slot}:${card.zoneEntrySequence}:${state.window.id}`;
}

function resolveRef(state: GameState, observer: PlayerId, ref: string): string | null {
  if (ref.startsWith('hidden-field:')) {
    const match = /^hidden-field:(p1|p2):(\d+):(\d+):(\d+)$/.exec(ref);
    if (!match || match[1] === observer || Number(match[4]) !== state.window.id) return null;
    const owner = match[1] as PlayerId;
    const id = state.players[owner].zones.spellCounter[Number(match[2])];
    const card = id && state.cards[id];
    return card && card.face === 'down' && card.zoneEntrySequence === Number(match[3]) ? card.id : null;
  }
  const card = state.cards[ref];
  if (card && card.location.player !== observer && card.location.zone === 'spellCounter' && card.face === 'down') return null;
  return ref;
}

/** Resolve only public slot references at the command boundary, rejecting stale ones. */
export function resolveHiddenTargetCommand(state: GameState, command: Command): Command | null {
  const resolve = (ids: readonly string[] | undefined): readonly string[] | null | undefined => {
    if (!ids) return undefined;
    const values = ids.map((id) => resolveRef(state, command.player, id));
    return values.some((id) => id === null) ? null : values as string[];
  };
  if (command.type === 'activateEffect') {
    const ids = resolve(command.targetIds);
    return ids === null ? null : { ...command, ...(ids ? { targetIds: ids } : {}) };
  }
  if (command.type === 'chooseResolutionCard') {
    const id = resolveRef(state, command.player, command.cardId);
    return id === null ? null : { ...command, cardId: id };
  }
  if (command.type === 'chooseTriggers' && command.choices) {
    const choices = command.choices.map((choice) => {
      const ids = resolve(choice.targetIds);
      return ids === null ? null : { ...choice, ...(ids ? { targetIds: ids } : {}) };
    });
    return choices.some((choice) => choice === null) ? null : { ...command, choices: choices as NonNullable<typeof command.choices> };
  }
  return command;
}
