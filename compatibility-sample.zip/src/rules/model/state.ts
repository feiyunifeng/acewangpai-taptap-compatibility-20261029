import type { CardId, CardInstanceId, PlayerId, SkillCopyId, SkillId } from './ids.js';
import type { RngState } from '../mechanics/rng.js';
import type { RulesConfig } from './config.js';
import type { ChainLink } from './chain.js';
import type { EffectCardFilter, ResolutionSelection, TriggerCandidate } from './effect.js';
import type { TriggerChoice } from './command.js';
import type { KeywordStatus } from './keyword.js';

export type Zone = 'mainDeck' | 'extraDeck' | 'hand' | 'normal' | 'frontline' | 'spellCounter' | 'heaven' | 'hell';
export type Phase = 'start' | 'draw' | 'main1' | 'battle' | 'main2' | 'end';

export interface CardLocation {
  readonly player: PlayerId;
  readonly zone: Zone;
  readonly slot?: number;
}

export interface CardInstance {
  readonly id: CardInstanceId;
  readonly cardId: CardId;
  readonly owner: PlayerId;
  readonly controller: PlayerId;
  readonly location: CardLocation;
  /** Sequence of the move that most recently entered this player/zone. */
  readonly zoneEntrySequence: number;
  readonly face: 'up' | 'down';
  readonly setOnTurn: number | null;
  readonly properlySummoned: boolean;
  readonly modifiers: readonly { readonly id: string; readonly atk?: number; readonly def?: number; readonly level?: number;
    readonly expiresAtTurn?: number }[];
  /** Persistent instance state applied whenever this monster leaves the field. */
  readonly leaveFieldReplacement?: { readonly id: string; readonly destination: 'ownerMainDeck' };
  readonly flags: readonly string[];
  /** Until the global turn advances, this summoned monster cannot activate effects. */
  readonly effectsDisabledUntilTurn?: number;
  /** Current-turn protection against opposing monster-effect destruction. */
  readonly protectedFromOpponentMonsterEffectUntilTurn?: number;
  readonly effectDestructionProtectionUsedTurn?: number;
}

export interface PlayerZones {
  readonly mainDeck: readonly CardInstanceId[];
  readonly extraDeck: readonly CardInstanceId[];
  readonly hand: readonly CardInstanceId[];
  readonly normal: readonly (CardInstanceId | null)[];
  readonly frontline: readonly (CardInstanceId | null)[];
  readonly spellCounter: readonly (CardInstanceId | null)[];
  readonly heaven: readonly CardInstanceId[];
  readonly hell: readonly CardInstanceId[];
}

export interface PlayerState {
  readonly life: number;
  /** Public, non-transferable effect activation resource. */
  readonly tp: number;
  readonly zones: PlayerZones;
  readonly skillCopies: readonly SkillCopyId[];
}

export interface SkillCopy {
  readonly id: SkillCopyId;
  readonly skillId: SkillId;
  readonly owner: PlayerId;
  readonly used: boolean;
}

export interface TurnCounters {
  readonly turn: number;
  readonly terminalSummonsUsed: number;
  readonly skillsUsed: number;
  readonly activatedNames: readonly string[];
  /** Encoded `name + effect index` activations for this player and global turn. */
  readonly activatedEffects: readonly string[];
  /** Card instances that have activated an effect at least once this global turn. */
  readonly activatedCardIds: readonly CardInstanceId[];
  readonly attacksDeclared: Readonly<Record<CardInstanceId, number>>;
}

export interface GameResult {
  readonly winner: PlayerId | null;
  readonly reason: string;
}

export interface PendingBattleReward {
  readonly kind: 'draw' | 'defense';
  readonly expiresAtTurn: number;
}

export interface FieldMark {
  readonly kind: 'attack' | 'defense';
  readonly amount: number;
}

export interface PendingWindow {
  readonly kind: 'turnStart' | 'open' | 'response' | 'choice' | 'resolution';
  readonly priorityPlayer: PlayerId;
  readonly id: number;
}

export interface PendingSummon {
  readonly player: PlayerId;
  readonly terminalId: CardInstanceId;
  readonly zone?: 'normal' | 'frontline';
  readonly slot: number;
    readonly materialIds?: readonly CardInstanceId[];
}

export interface PendingResolution {
  readonly player: PlayerId;
  readonly links: readonly ChainLink[];
  readonly linkIndex: number;
  readonly summonNegated: boolean;
  readonly stepIndex: number;
  readonly context: Readonly<Record<string, readonly ResolutionSelection[]>>;
  readonly successes: Readonly<Record<string, boolean>>;
  readonly key: string;
  readonly candidates: readonly CardInstanceId[];
  readonly filter: EffectCardFilter;
  readonly alsoFilterWhenFaceUp?: { readonly cardId: string; readonly filter: EffectCardFilter };
  readonly minimum: number;
  readonly maximum: number;
  readonly destinations?: readonly ('hand' | 'spellCounter')[];
  readonly resumeCurrentStep?: boolean;
  readonly selected: readonly ResolutionSelection[];
  readonly applied: boolean;
}

export type BattleTarget =
  | { readonly kind: 'monster'; readonly cardId: CardInstanceId }
  | { readonly kind: 'player'; readonly player: PlayerId };

export type BattleStep = 'attackDeclaration' | 'damageBefore' | 'damageCalculation' | 'battleEnd' | 'retarget';

export interface PendingBattle {
  readonly id: string;
  readonly player: PlayerId;
  readonly attackerId: CardInstanceId;
  readonly attackerZone: 'normal' | 'frontline';
  readonly attackerZoneEntrySequence: number;
  readonly target: BattleTarget;
  readonly targetSnapshot?: { readonly player: PlayerId; readonly zone: 'normal' | 'frontline'; readonly zoneEntrySequence: number };
  readonly stage: BattleStep;
  readonly resumeStage?: Exclude<BattleStep, 'retarget'>;
  readonly attackNegated?: boolean;
}

export interface GameState {
  readonly rulesVersion: string;
  readonly config: RulesConfig;
  readonly catalogVersion: string;
  readonly seed: number;
  readonly rng: RngState;
  readonly firstPlayer: PlayerId;
  readonly secondPlayer: PlayerId;
  readonly turnPlayer: PlayerId;
  readonly globalTurn: number;
  readonly phase: Phase;
  readonly players: Readonly<Record<PlayerId, PlayerState>>;
  readonly cards: Readonly<Record<CardInstanceId, CardInstance>>;
  /** Per-player named numbered effects that have been consumed across this match. */
  readonly matchEffectActivations?: Readonly<Record<PlayerId, readonly string[]>>;
  /** Last global-turn activation for effects with multi-turn cooldowns. */
  readonly effectCooldowns?: Readonly<Record<PlayerId, Readonly<Record<string, number>>>>;
  /** Restricts other main-deck monster effects for this player's current global turn. */
  readonly mainMonsterEffectLocks?: Readonly<Partial<Record<PlayerId, { readonly globalTurn: number; readonly exceptCardId: CardInstanceId }>>>;
  /** A once-per-global-turn optional destruction replacement used by the controlling player. */
  readonly destructionReplacementUsed?: Readonly<Partial<Record<PlayerId, number>>>;
  readonly skills: Readonly<Record<SkillCopyId, SkillCopy>>;
  readonly counters: Readonly<Record<PlayerId, TurnCounters>>;
  readonly window: PendingWindow;
  readonly pendingSummon?: PendingSummon | null;
  readonly pendingBattle?: PendingBattle | null;
  readonly pendingResolution?: PendingResolution;
  readonly chain: readonly ChainLink[];
  readonly responsePasses?: number;
  /** Open-window priority handoffs: 1 = opponent may act, 2 = both passed and the empty cycle closed. */
  readonly openPriorityPasses?: 0 | 1 | 2;
  readonly pendingTriggers: readonly TriggerCandidate[];
  readonly triggerSelections?: Partial<Record<PlayerId, readonly TriggerChoice[]>>;
  /** Highest event sequence already inspected for trigger candidates. */
  readonly triggerObservedThrough?: number;
  readonly eventSequence: number;
  readonly result: GameResult | null;
  readonly battleRewards?: Readonly<Partial<Record<PlayerId, PendingBattleReward>>>;
  readonly fieldMarks?: Readonly<Partial<Record<PlayerId, Readonly<Record<number, FieldMark>>>>>;
  /** Serializable field state; statuses are keyed to card zone-entry identity where applicable. */
  readonly keywordStatuses?: readonly KeywordStatus[];
}
