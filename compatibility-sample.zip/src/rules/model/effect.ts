import type { CardInstanceId, PlayerId, SkillCopyId } from './ids.js';
import type { ArchetypeId } from './archetype.js';
import type { Zone } from './state.js';
import type { KeywordOperation } from './keyword.js';

export type EffectSpeed = 1 | 2 | 3;
export type EffectMode = 'active' | 'response' | 'trigger' | 'continuous';
export type EffectHandlerId = 'noop' | 'sendTargetsToHeaven' | 'destroyTargets' |
  'negateActivation' | 'negateEffect' | 'negateSummon' | 'effectSummonTerminal' | 'continuousAtkBoost' | 'executeProgram' |
  'activateContinuousSpell' | 'negateAttack' | 'protectTarget' | 'armBattleReward' | 'placeFieldMark';

export interface EffectCardFilter {
  readonly zones: readonly Zone[];
  readonly side: 'self' | 'opponent' | 'any';
  readonly cardIds?: readonly string[];
  readonly kinds?: readonly ('monster' | 'spell' | 'counter')[];
  readonly decks?: readonly ('main' | 'extra')[];
  readonly archetypeId?: ArchetypeId;
  readonly profession?: string;
  readonly face?: 'up' | 'down' | 'any';
  readonly maxLevel?: number;
  readonly minLevel?: number;
  readonly maxAtk?: number;
  readonly maxDef?: number;
  readonly maxAtkOrDef?: number;
  readonly maxPrintedAtk?: number;
  /** Restricts selection to card instances whose effect activated during this global turn. */
  readonly activatedThisTurn?: boolean;
  readonly requiresAtk?: boolean;
  readonly requiresDef?: boolean;
  readonly spellModes?: readonly ('normal' | 'quick' | 'continuous')[];
  /** Current effective ATK must exceed the effect source's current effective ATK. */
  readonly atkGreaterThanSource?: boolean;
  readonly excludeSource?: boolean;
  /** Restrict to monsters without printed effects. */
  readonly noEffects?: boolean;
  /** Terminal monsters must have been properly summoned before revival. */
  readonly properlySummonedIfTerminal?: boolean;
}

export interface ResolutionSelection {
  readonly cardId: CardInstanceId;
  readonly destination?: 'hand' | 'spellCounter';
}

export type EffectProgramStepBase =
  | { readonly kind: 'selectCards'; readonly key: string; readonly filter: EffectCardFilter;
      readonly min: number; readonly max: number | 'all'; readonly destinations?: readonly ('hand' | 'spellCounter')[];
      readonly topDeckCount?: number;
      readonly skipIfEmpty?: boolean; readonly requiresSuccessKey?: string;
      readonly requiresFieldFilter?: EffectCardFilter;
      readonly alsoFilterWhenFaceUp?: { readonly cardId: string; readonly filter: EffectCardFilter } }
  /** Deterministically gathers all matching cards during resolution; it never opens a choice or snapshots targets at activation. */
  | { readonly kind: 'resolveSelect'; readonly key: string; readonly filter: EffectCardFilter; readonly max?: number | 'all' }
  | { readonly kind: 'moveTopCard'; readonly from: 'mainDeck'; readonly to: 'heaven' | 'hell'; readonly player?: 'self' | 'opponent' }
  | { readonly kind: 'summonSelected'; readonly key: string; readonly from: 'mainDeck' | 'heaven' | 'hell' | readonly ('mainDeck' | 'heaven' | 'hell')[]; readonly to: 'normal' | 'frontline' | 'normalOrFrontline';
      readonly effectsDisabledUntilTurn?: boolean; readonly successKey?: string }
  | { readonly kind: 'negateMonsterUntilLeaves'; readonly key: string }
  | { readonly kind: 'sendResponseSourceToHeaven' }
  | { readonly kind: 'negatePendingAttack'; readonly requiresSuccessKey?: string }
  | { readonly kind: 'protectSelectedFromOpponentMonsterEffectDestruction'; readonly key: string }
  | { readonly kind: 'summonSelf'; readonly from: Zone | readonly Zone[]; readonly to: 'normal' | 'frontline';
      readonly effectsNegated?: boolean; readonly leaveFieldReplacement?: boolean; readonly requiresFaceUpCardId?: string;
      readonly successKey: string }
  | ({ readonly kind: 'moveSelected'; readonly key: string; readonly to: 'heaven' | 'hell' | 'hand' | 'handOrExtraDeck' | 'spellCounter';
      readonly reason: 'send' | 'release' | 'discard' | 'effect' | 'deploy' | 'return'; readonly ownerDestination?: boolean;
      readonly shuffleAfter?: boolean; readonly successKey?: string; readonly requiresSuccessKey?: string } &
      ({ readonly to: 'heaven' } | { readonly reason: 'send' | 'release' | 'effect' | 'deploy' | 'return' }))
  | { readonly kind: 'destroySelected'; readonly key: string; readonly requiresSuccessKey?: string;
      readonly replacement?: { readonly key: string; readonly protectedArchetypeId: ArchetypeId; readonly resourceArchetypeId: ArchetypeId } }
  | { readonly kind: 'releaseSelected'; readonly key: string; readonly requiresSuccessKey?: string }
  | { readonly kind: 'modifyLevel'; readonly target: 'source' | 'selected'; readonly key?: string;
      readonly amount: number; readonly amountPerSelected?: number; readonly successKey?: string; readonly requiresSuccessKey?: string }
  | { readonly kind: 'modifyAttack'; readonly target: 'source'; readonly amount: number;
      readonly amountPerOwnHellCard?: { readonly archetypeId: ArchetypeId }; readonly successKey?: string }
  | { readonly kind: 'modifyStats'; readonly target: 'source' | 'selected'; readonly key?: string;
      readonly atk?: number; readonly def?: number; readonly duration: 'turn' | 'opponentTurnEnd'; readonly successKey?: string }
  | { readonly kind: 'drawCards'; readonly count: number }
  | { readonly kind: 'reorderMainDeck'; readonly key: string; readonly count: number; readonly topCount: number }
  | { readonly kind: 'shuffleDeck'; readonly player: 'self' };

export type EffectProgramStep = EffectProgramStepBase | { readonly kind: 'keyword'; readonly operation: KeywordOperation };

export interface EffectRequirement {
  readonly filter: EffectCardFilter;
  readonly minimum: number;
}

export interface EffectChoicePrompt {
  readonly stepIndex: number;
  readonly context: Readonly<Record<string, readonly ResolutionSelection[]>>;
  readonly successes: Readonly<Record<string, boolean>>;
  readonly key: string;
  readonly candidates: readonly CardInstanceId[];
  readonly filter: EffectCardFilter;
  /** A second legal filter enabled only while the named support card remains face-up. */
  readonly alsoFilterWhenFaceUp?: { readonly cardId: string; readonly filter: EffectCardFilter };
  readonly minimum: number;
  readonly maximum: number;
  readonly applied: boolean;
  readonly destinations?: readonly ('hand' | 'spellCounter')[];
  readonly player?: PlayerId;
  readonly resumeCurrentStep?: boolean;
}

/** Trusted catalog data; commands may name an ID but cannot supply these permissions. */
export interface EffectDefinition {
  readonly id: string;
  readonly source: 'card' | 'skill';
  /** Printed numbered effect; omitted legacy definitions are treated as index 1. */
  readonly effectIndex?: 1 | 2 | 3;
  readonly speed: EffectSpeed;
  readonly mode: EffectMode;
  readonly allowedZones: readonly Zone[];
  readonly handlerId: EffectHandlerId;
  readonly conditionId?: 'ownTurn' | 'opponentTurn' | 'ownBattlePhase' | 'battlePhase';
  /** Requires one selection from each independent activation-time target group. */
  readonly targetGroups?: readonly { readonly zones: readonly Zone[]; readonly min: number; readonly max: number;
    readonly filter?: EffectCardFilter }[];
  readonly respondsTo?: 'card' | 'skill' | 'any';
  readonly timing?: 'summonNegation' | 'attackDeclaration' | 'damageBefore' | 'damageCalculation' | 'battleEnd';
  readonly cost?: { readonly zone: Zone; readonly mustBeSource?: boolean; readonly excludeSource?: boolean;
    readonly alsoZones?: readonly Zone[]; readonly filter?: { readonly archetypeId?: ArchetypeId; readonly profession?: string } } &
    ({ readonly kind: 'discard'; readonly destination?: 'heaven' } |
      { readonly kind: 'release' | 'send'; readonly destination?: 'heaven' | 'hell' });
  readonly lifeCost?: { readonly kind: 'currentFraction'; readonly numerator: number; readonly denominator: number } |
    { readonly kind: 'fixed'; readonly amount: number };
  readonly resourceCost?: { readonly zone: 'heaven' | 'hell'; readonly destination: 'mainDeckBottom' | 'hell';
    readonly filter?: { readonly archetypeId?: ArchetypeId } };
  readonly targets?: { readonly zones: readonly Zone[]; readonly min: number; readonly max: number;
    readonly filter?: EffectCardFilter; readonly excludeSource?: boolean };
  readonly materialPermission?: { readonly zones: readonly Zone[]; readonly allowOpponent: boolean };
  readonly oncePerName?: 'shared' | 'unlimited';
  /** Minimum number of global player turns between activations of this printed effect. */
  readonly cooldownTurns?: number;
  readonly oncePerGame?: boolean;
  readonly locksOtherMainMonsterEffects?: boolean;
  readonly triggerEvent?: string;
  readonly triggerSource?: 'self' | 'any';
  readonly triggerMethods?: readonly ('ruleMain' | 'effectMain' | 'ruleTerminal' | 'effectTerminal' | 'revival')[];
  /** Explicitly records whether this effect locks a target at activation; omitted values are inferred. */
  readonly selectionMode?: 'grab' | 'noGrab' | 'none';
  readonly activationRequirementGroups?: readonly (readonly EffectRequirement[])[];
  readonly responseRequirement?: { readonly kind: 'opponentGrabbedCard'; readonly cardId: string } |
    { readonly kind: 'opponentAttack' } | { readonly kind: 'opponentNormalSpellActivation' } |
    { readonly kind: 'opponentCardEffect' | 'opponentMonsterEffect' | 'opponentSpellEffect' } |
    { readonly kind: 'opponentDirectAttack' } | { readonly kind: 'opponentSourceMonsterMaxLevel'; readonly maxLevel: number } |
    { readonly kind: 'opponentTargetedOwnMonsterForDestruction' } |
    { readonly kind: 'opponentTargetedOwnFieldForDestruction' } | { readonly kind: 'opponentTargetedOwnField' } |
    { readonly kind: 'opponentEffectDestroysAtLeast'; readonly count: number } | { readonly kind: 'opponentDeckSearch' } |
    { readonly kind: 'opponentTargetedOwnArchetypeMonster'; readonly archetypeId: ArchetypeId } |
    { readonly kind: 'opponentRespondedToOwnArchetype'; readonly archetypeId: ArchetypeId };
  readonly responseTarget?: 'opponentEffectSource' | 'opponentAttackSource' | 'opponentGrabbedOwnField';
  readonly triggerMove?: { readonly from: readonly Zone[]; readonly to: Zone;
    readonly actor: 'opponent' | 'self' | 'opponentOrBattle' | 'any'; readonly reasons?: readonly ('effect' | 'send' | 'destroy')[] };
  readonly triggerFromSet?: boolean;
  readonly triggerRequirement?: 'opponentMonsterSummoned' | 'selfTributeSummoned' | 'selfTributeMaterial';
  readonly triggerSummonedArchetypeId?: ArchetypeId;
  readonly triggerTarget?: 'eventCard';
  readonly destroysNegatedSource?: boolean;
  readonly program?: readonly EffectProgramStep[];
  readonly continuousStats?: { readonly archetypeId?: ArchetypeId; readonly deck?: 'main' | 'extra'; readonly selfOnly?: boolean;
    readonly targetSide?: 'self' | 'opponent';
    readonly excludeSource?: boolean; readonly requiresOtherFriendlyMonster?: boolean;
    readonly requiresOpponentMoreMonsters?: boolean; readonly atk?: number; readonly def?: number;
    readonly directAttackDamage?: number; readonly battleAtkBonusWhenPrintedAtkBelowDef?: number;
    readonly scaleByArchetypeFieldCount?: { readonly archetypeId: ArchetypeId; readonly amountPerCard: number };
    readonly scaleByHeavenMonsters?: { readonly archetypeId: ArchetypeId; readonly amountPerCard: number } };
  readonly continuousDamageReduction?: number;
  readonly continuousBattleAtkModifier?: { readonly amount: number; readonly whenOpponentAttacksFriendlyMonster: boolean };
  readonly battleReward?: 'draw' | 'defense';
  readonly fieldMark?: { readonly stat: 'atk' | 'def'; readonly amount: number };
  readonly continuousProtection?: { readonly cardId: string; readonly self: boolean; readonly sameColumnFriendlyCards?: boolean;
    readonly requiresFaceUpCardId?: string };
  readonly continuousSelfEffectDestructionProtectionOncePerTurn?: boolean;
  readonly destructionReplacement?: { readonly protectedArchetypeId: ArchetypeId; readonly resourceArchetypeId: ArchetypeId;
    readonly resourceZone: 'heaven' };
  readonly mandatory?: boolean;
  readonly value?: number;
}

export type EffectSource =
  | { readonly kind: 'card'; readonly instanceId: CardInstanceId }
  | { readonly kind: 'skill'; readonly copyId: SkillCopyId };

export interface TriggerCandidate {
  readonly id: string;
  readonly player: PlayerId;
  readonly mandatory: boolean;
  readonly eventSequence: number;
  readonly sourceId: CardInstanceId | SkillCopyId;
  readonly effectId: string;
  /** Captured when the event occurs; later movement does not erase this trigger. */
  readonly sourceLocation?: { readonly player: PlayerId; readonly zone: Zone; readonly zoneEntrySequence: number };
  readonly eventCardId?: string;
}
