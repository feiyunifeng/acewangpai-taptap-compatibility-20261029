export const ARCHETYPE_IDS = ['star_constellation', 'ruin_echo'] as const;
export type ArchetypeId = typeof ARCHETYPE_IDS[number];

export interface ArchetypeDefinition {
  readonly id: ArchetypeId;
  readonly displayNameZh: string;
  readonly cardNamePrefix: string;
  /** Prefixes accepted only for legacy card pools retained for compatibility. */
  readonly legacyCardNamePrefixes?: readonly string[];
}

/** Canonical printed name fields. Runtime rules use IDs; card data uses this registry to keep names consistent. */
export const ARCHETYPE_REGISTRY: Readonly<Record<ArchetypeId, ArchetypeDefinition>> = {
  star_constellation: { id: 'star_constellation', displayNameZh: '星枢机团', cardNamePrefix: '星枢机团·',
    legacyCardNamePrefixes: ['星枢·'] },
  ruin_echo: { id: 'ruin_echo', displayNameZh: '潮痕渡界', cardNamePrefix: '潮痕·' },
};

export function cardNameWithArchetype(archetypeId: ArchetypeId, title: string): string {
  return `${ARCHETYPE_REGISTRY[archetypeId].cardNamePrefix}${title}`;
}

export interface ArchetypeNamedCard {
  readonly id: string;
  readonly name: string;
  readonly archetypeIds?: readonly ArchetypeId[];
}

/** Reports mismatches between a visible name field and the rule-facing archetype IDs. */
export function validateArchetypeNameFields(cards: readonly ArchetypeNamedCard[]): readonly string[] {
  const errors: string[] = [];
  for (const card of cards) {
    const printedIds = ARCHETYPE_IDS.filter((id) => {
      const definition = ARCHETYPE_REGISTRY[id];
      return [definition.cardNamePrefix, ...(definition.legacyCardNamePrefixes ?? [])]
        .some((prefix) => card.name.startsWith(prefix));
    });
    const assignedIds = card.archetypeIds ?? [];
    for (const id of printedIds) if (!assignedIds.includes(id)) errors.push(`${card.id}: name field ${id} has no archetype ID`);
    for (const id of assignedIds) if (!printedIds.includes(id)) errors.push(`${card.id}: archetype ID ${id} is missing from its name`);
  }
  return errors;
}
