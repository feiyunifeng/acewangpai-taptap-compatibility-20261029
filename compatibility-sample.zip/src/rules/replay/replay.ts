import type { CardCatalog } from '../model/card.js';
import type { Command } from '../model/command.js';
import type { GameEvent } from '../model/event.js';
import type { GameState } from '../model/state.js';
import type { CreateGameInput } from '../engine/create-game.js';
import { createGame } from '../engine/create-game.js';
import { applyCommand } from '../engine/submit-command.js';
import { stateHash } from './state-hash.js';

export interface MatchRecord {
  readonly rulesVersion: string;
  readonly catalogVersion: string;
  readonly catalogHash: string;
  readonly rngAlgorithm: string;
  readonly initial: CreateGameInput;
  readonly commands: readonly Command[];
  readonly finalStateHash?: string;
}

export interface ReplayResult {
  readonly ok: boolean;
  readonly state?: GameState;
  readonly events: readonly GameEvent[];
  readonly error?: 'RULES_VERSION_MISMATCH' | 'CATALOG_VERSION_MISMATCH' | 'CATALOG_CONTENT_MISMATCH' |
    'RNG_VERSION_MISMATCH' | 'INVALID_COMMAND' | 'FINAL_STATE_MISMATCH';
  readonly failedCommandIndex?: number;
}

export function catalogHash(catalog: CardCatalog): string {
  return stateHash(catalog);
}

export function createMatchRecord(initial: CreateGameInput, rulesVersion: string, catalog: CardCatalog): MatchRecord {
  return {
    rulesVersion, catalogVersion: catalog.version, catalogHash: catalogHash(catalog),
    rngAlgorithm: 'lcg32-v1', initial: { ...initial, catalog }, commands: [],
  };
}

export function appendAcceptedCommand(record: MatchRecord, command: Command, state: GameState): MatchRecord {
  return { ...record, commands: [...record.commands, command], finalStateHash: stateHash(state) };
}

export function replayMatch(record: MatchRecord, rulesVersion: string, catalog: CardCatalog): ReplayResult {
  if (record.rulesVersion !== rulesVersion) return { ok: false, events: [], error: 'RULES_VERSION_MISMATCH' };
  if (record.catalogVersion !== catalog.version || record.initial.catalog.version !== catalog.version) {
    return { ok: false, events: [], error: 'CATALOG_VERSION_MISMATCH' };
  }
  if (record.catalogHash !== catalogHash(catalog)) return { ok: false, events: [], error: 'CATALOG_CONTENT_MISMATCH' };
  if (record.rngAlgorithm !== 'lcg32-v1') return { ok: false, events: [], error: 'RNG_VERSION_MISMATCH' };
  let state: GameState;
  try {
    state = createGame({ ...record.initial, catalog });
  } catch {
    return { ok: false, events: [], error: 'INVALID_COMMAND' };
  }
  if (state.rng.algorithm !== record.rngAlgorithm) return { ok: false, events: [], error: 'RNG_VERSION_MISMATCH' };
  const events: GameEvent[] = [];
  for (let index = 0; index < record.commands.length; index += 1) {
    const result = applyCommand(state, record.commands[index]!, catalog);
    if (!result.ok) return { ok: false, events: [], error: 'INVALID_COMMAND', failedCommandIndex: index };
    state = result.state;
    events.push(...result.events);
  }
  if (record.finalStateHash && record.finalStateHash !== stateHash(state)) {
    return { ok: false, events: [], error: 'FINAL_STATE_MISMATCH' };
  }
  return { ok: true, state, events };
}
