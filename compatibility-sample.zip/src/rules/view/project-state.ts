import type { PlayerId } from '../model/ids.js';
import type { CardCatalog } from '../model/card.js';
import type { BattleTarget, CardInstance, GameState, Phase, Zone } from '../model/state.js';
import { getCurrentDirectAttackDamage, getCurrentMonsterStat } from '../mechanics/effects.js';
import { tpAllowance } from '../mechanics/tp.js';
import { hiddenFieldTargetRef } from '../model/hidden-field-target.js';

export interface VisibleCard {
  readonly id: string;
  readonly cardId: string;
  readonly owner: PlayerId;
  readonly controller: PlayerId;
  readonly face: 'up' | 'down';
  readonly location: { readonly player: PlayerId; readonly zone: Zone; readonly slot?: number };
  readonly currentStats?: { readonly atk?: number; readonly def?: number; readonly directAttackDamage?: number };
  readonly statusMarkers?: readonly ('freeze' | 'weaken')[];
}

export interface HiddenCard {
  readonly face: 'down';
  readonly location: { readonly player: PlayerId; readonly zone: 'normal' | 'frontline' | 'spellCounter'; readonly slot: number };
  readonly selectionId?: string;
}

export interface ViewPlayer {
  readonly life: number;
  readonly maxLife: number;
  readonly tp: number;
  readonly tpCap: number;
  readonly handCount: number;
  readonly extraDeckCount: number;
  readonly mainDeckCount: number;
  readonly hand?: readonly VisibleCard[];
  readonly extraDeck?: readonly VisibleCard[];
  readonly normal: readonly (VisibleCard | HiddenCard | null)[];
  readonly frontline: readonly (VisibleCard | HiddenCard | null)[];
  readonly spellCounter: readonly (VisibleCard | HiddenCard | null)[];
  readonly heaven: readonly VisibleCard[];
  readonly hell: readonly VisibleCard[];
  readonly skills: readonly { readonly skillId: string; readonly used: boolean; readonly id?: string }[];
  readonly remainingSkillCount: number;
  readonly normalFieldMarks?: readonly { readonly slot: number; readonly kind: 'attack' | 'defense'; readonly amount: number }[];
  readonly pendingBattleReward?: 'draw' | 'defense';
}

export interface ViewState {
  readonly rulesVersion: string;
  readonly catalogVersion: string;
  readonly firstPlayer: PlayerId;
  readonly turnPlayer: PlayerId;
  readonly globalTurn: number;
  readonly phase: Phase;
  readonly window: { readonly kind: GameState['window']['kind']; readonly priorityPlayer: PlayerId; readonly id: number };
  readonly players: Readonly<Record<PlayerId, ViewPlayer>>;
  readonly pendingSummon: { readonly player: PlayerId; readonly terminalId: string; readonly zone?: 'normal' | 'frontline'; readonly slot: number } | null;
  readonly pendingBattle: { readonly id: string; readonly player: PlayerId; readonly attackerId?: string;
    readonly target: BattleTarget | { readonly kind: 'monster' }; readonly stage: string } | null;
  readonly chain: readonly { readonly id: string; readonly player: PlayerId; readonly effectId?: string;
    readonly speed: number; readonly sourceKind?: 'card' | 'skill'; readonly sourceId?: string }[];
  readonly pendingTriggers: readonly { readonly id: string; readonly effectId: string; readonly mandatory: boolean;
    readonly sourceId: string; readonly sourceKind: 'card' | 'skill'; readonly sourceCardId?: string; readonly sourceSkillId?: string }[];
  readonly pendingResolution: { readonly player: PlayerId; readonly candidates?: readonly string[];
    readonly selected?: readonly { readonly cardId: string; readonly destination?: 'hand' | 'spellCounter' }[];
    readonly candidateCards?: readonly { readonly id: string; readonly cardId: string }[];
    readonly selectedCards?: readonly { readonly id: string; readonly cardId: string; readonly destination?: 'hand' | 'spellCounter' }[];
    readonly minimum?: number; readonly maximum?: number; readonly destinations?: readonly ('hand' | 'spellCounter')[] } | null;
  readonly result: { readonly winner: PlayerId | null; readonly reason: string } | null;
}

function cardView(state: GameState, card: CardInstance, catalog?: CardCatalog): VisibleCard {
  const definition = catalog && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  const withCurrentStats = (key: 'atk' | 'def'): number | undefined => !definition || !catalog ? undefined
    : getCurrentMonsterStat(state, card.id, key, catalog);
  const mageDamage = definition?.directAttackDamage === undefined || !catalog
    ? undefined : getCurrentDirectAttackDamage(state, card.id, catalog);
  const currentStats = definition ? {
    ...(withCurrentStats('atk') !== undefined ? { atk: withCurrentStats('atk') } : {}),
    ...(withCurrentStats('def') !== undefined ? { def: withCurrentStats('def') } : {}),
    ...(mageDamage !== undefined ? { directAttackDamage: mageDamage } : {}),
  } : {};
  const statusMarkers = (state.keywordStatuses ?? []).flatMap((status) =>
    status.keywordId !== 'burn' && status.targetCardId === card.id &&
    status.targetZoneEntrySequence === card.zoneEntrySequence &&
    (status.expiresAtGlobalTurn === undefined || status.expiresAtGlobalTurn > state.globalTurn) &&
    (status.expiresAtPhase !== 'battleEnd' || state.phase === 'battle')
      ? [status.keywordId] : []);
  return { id: card.id, cardId: card.cardId, owner: card.owner, controller: card.controller,
    face: card.face, location: { player: card.location.player, zone: card.location.zone,
      ...(card.location.slot === undefined ? {} : { slot: card.location.slot }) },
    ...(Object.keys(currentStats).length ? { currentStats } : {}),
    ...(statusMarkers.length ? { statusMarkers } : {}) };
}

function canSeeCurrentCard(card: CardInstance | undefined, observer: PlayerId): boolean {
  if (!card) return false;
  if (card.location.zone === 'heaven' || card.location.zone === 'hell') return true;
  if (card.location.zone === 'mainDeck') return false;
  if (card.location.zone === 'hand' || card.location.zone === 'extraDeck') return card.location.player === observer;
  return card.face === 'up' || card.location.player === observer;
}

function fieldView(state: GameState, observer: PlayerId, ids: readonly (string | null)[], catalog?: CardCatalog): readonly (VisibleCard | HiddenCard | null)[] {
  return ids.map((id) => {
    if (id === null) return null;
    const card = state.cards[id]!;
    if (canSeeCurrentCard(card, observer)) return cardView(state, card, catalog);
    return { face: 'down', location: { player: card.location.player,
      zone: card.location.zone as HiddenCard['location']['zone'], slot: card.location.slot! },
      ...(card.location.zone === 'spellCounter' ? { selectionId: hiddenFieldTargetRef(state, observer, card.id) } : {}) };
  });
}

function playerView(state: GameState, observer: PlayerId, player: PlayerId, catalog?: CardCatalog): ViewPlayer {
  const { life, tp, zones, skillCopies } = state.players[player];
  const own = observer === player;
  const tpCap = tpAllowance(state.globalTurn);
  const used = skillCopies.map((id) => state.skills[id]!).filter((copy) => copy.used);
  return {
    life, maxLife: state.config.initialLife, tp, tpCap,
    handCount: zones.hand.length, extraDeckCount: zones.extraDeck.length, mainDeckCount: zones.mainDeck.length,
    ...(own ? { hand: zones.hand.map((id) => cardView(state, state.cards[id]!, catalog)),
      extraDeck: zones.extraDeck.map((id) => cardView(state, state.cards[id]!, catalog)) } : {}),
    normal: fieldView(state, observer, zones.normal, catalog),
    frontline: fieldView(state, observer, zones.frontline, catalog),
    spellCounter: fieldView(state, observer, zones.spellCounter, catalog),
    heaven: zones.heaven.map((id) => cardView(state, state.cards[id]!, catalog)),
    hell: zones.hell.map((id) => cardView(state, state.cards[id]!, catalog)),
    skills: own ? skillCopies.map((id) => ({ id, skillId: state.skills[id]!.skillId, used: state.skills[id]!.used }))
      : used.map((copy) => ({ skillId: copy.skillId, used: true })),
    remainingSkillCount: skillCopies.length - used.length,
    normalFieldMarks: Object.entries(state.fieldMarks?.[player] ?? {}).map(([slot, mark]) => ({
      slot: Number(slot), kind: mark.kind, amount: mark.amount,
    })),
    ...(state.battleRewards?.[player] ? { pendingBattleReward: state.battleRewards[player]!.kind } : {}),
  };
}

/** Only explicitly listed fields cross the full-state boundary. */
export function projectState(state: GameState, observer: PlayerId, catalog?: CardCatalog): ViewState {
  return {
    rulesVersion: state.rulesVersion, catalogVersion: state.catalogVersion,
    firstPlayer: state.firstPlayer, turnPlayer: state.turnPlayer, globalTurn: state.globalTurn,
    phase: state.phase, window: { kind: state.window.kind, priorityPlayer: state.window.priorityPlayer, id: state.window.id },
    players: { p1: playerView(state, observer, 'p1', catalog), p2: playerView(state, observer, 'p2', catalog) },
    pendingSummon: state.pendingSummon ? { player: state.pendingSummon.player,
      terminalId: state.pendingSummon.terminalId, ...(state.pendingSummon.zone ? { zone: state.pendingSummon.zone } : {}),
      slot: state.pendingSummon.slot } : null,
    pendingBattle: state.pendingBattle ? { id: state.pendingBattle.id, player: state.pendingBattle.player,
      ...(canSeeCurrentCard(state.cards[state.pendingBattle.attackerId], observer)
        ? { attackerId: state.pendingBattle.attackerId } : {}),
      target: state.pendingBattle.target.kind === 'monster'
        ? { kind: 'monster', ...(canSeeCurrentCard(state.cards[state.pendingBattle.target.cardId], observer)
          ? { cardId: state.pendingBattle.target.cardId } : {}) }
        : { kind: 'player', player: state.pendingBattle.target.player }, stage: state.pendingBattle.stage } : null,
    chain: state.chain.map((link) => ({ id: link.id, player: link.player,
      speed: link.speed, ...(link.sourceVisibility === 'public' || link.sourceVisibility === observer
        ? { effectId: link.effectId, sourceKind: link.source.kind,
          ...(link.source.kind === 'card' ? { sourceId: link.source.instanceId } : {}) } : {}) })),
    pendingTriggers: state.pendingTriggers.filter((item) => item.player === observer).map((item) => {
      const sourceIsSkill = Object.hasOwn(state.skills, item.sourceId);
      const sourceCard = sourceIsSkill ? undefined : state.cards[item.sourceId];
      const sourceSkill = sourceIsSkill ? state.skills[item.sourceId] : undefined;
      return { id: item.id, effectId: item.effectId, mandatory: item.mandatory, sourceId: item.sourceId,
        sourceKind: sourceIsSkill ? 'skill' as const : 'card' as const,
        ...(sourceCard ? { sourceCardId: sourceCard.cardId } : {}),
        ...(sourceSkill ? { sourceSkillId: sourceSkill.skillId } : {}) };
    }),
    pendingResolution: state.pendingResolution ? { player: state.pendingResolution.player,
      ...(state.pendingResolution.player === observer ? {
        candidates: state.pendingResolution.candidates.map((id) => hiddenFieldTargetRef(state, observer, id)),
        selected: state.pendingResolution.selected.map((selection) => ({ ...selection,
          cardId: hiddenFieldTargetRef(state, observer, selection.cardId) })),
        candidateCards: state.pendingResolution.candidates.flatMap((id) => {
          const card = state.cards[id];
          return card ? [{ id: hiddenFieldTargetRef(state, observer, id),
            cardId: hiddenFieldTargetRef(state, observer, id) === id ? card.cardId : '' }] : [];
        }),
        selectedCards: state.pendingResolution.selected.flatMap((selection) => {
          const card = state.cards[selection.cardId];
          return card ? [{ id: hiddenFieldTargetRef(state, observer, selection.cardId),
            cardId: hiddenFieldTargetRef(state, observer, selection.cardId) === selection.cardId ? card.cardId : '',
            ...(selection.destination ? { destination: selection.destination } : {}) }] : [];
        }),
        minimum: state.pendingResolution.minimum,
        maximum: state.pendingResolution.maximum,
        ...(state.pendingResolution.destinations ? { destinations: state.pendingResolution.destinations } : {}),
      } : {}) } : null,
    result: state.result ? { winner: state.result.winner, reason: state.result.reason } : null,
  };
}
