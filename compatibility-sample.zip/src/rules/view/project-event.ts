import type { RuleError, RuleErrorCode } from '../model/command.js';
import type { GameEvent, IdentityVisibility } from '../model/event.js';
import type { PlayerId } from '../model/ids.js';

export interface PublicRuleError { readonly code: RuleErrorCode }
export type PublicEvent = Readonly<Record<string, unknown>> & { readonly type: GameEvent['type']; readonly sequence: number };

export function projectError(error: RuleError): PublicRuleError {
  return { code: error.code };
}

function canSee(visibility: IdentityVisibility, observer: PlayerId): boolean {
  return visibility === 'public' || visibility === observer;
}

/** Every branch reconstructs a public payload; no internal event is copied wholesale. */
export function projectEvent(event: GameEvent, observer: PlayerId): PublicEvent | null {
  switch (event.type) {
    case 'cardMoved': return {
      type: event.type, sequence: event.sequence, actor: event.actor, reason: event.reason,
      from: { player: event.from.player, zone: event.from.zone, ...(event.from.slot === undefined ? {} : { slot: event.from.slot }) },
      to: { player: event.to.player, zone: event.to.zone, ...(event.to.slot === undefined ? {} : { slot: event.to.slot }) },
      ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId } : {}),
    };
    case 'cardFaceChanged': return {
      type: event.type, sequence: event.sequence, actor: event.actor, reason: event.reason,
      location: { player: event.location.player, zone: event.location.zone,
        ...(event.location.slot === undefined ? {} : { slot: event.location.slot }) },
      fromFace: event.fromFace, toFace: event.toFace,
      ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId } : {}),
    };
    case 'phaseChanged': return { type: event.type, sequence: event.sequence, player: event.player,
      from: event.from, to: event.to, globalTurn: event.globalTurn };
    case 'tpChanged': return { type: event.type, sequence: event.sequence, player: event.player,
      from: event.from, to: event.to, reason: event.reason };
    case 'lifePaid': return { type: event.type, sequence: event.sequence, player: event.player,
      amount: event.amount, reason: event.reason };
    case 'lifeRecovered': return { type: event.type, sequence: event.sequence, player: event.player,
      amount: event.amount, reason: event.reason };
    case 'summonSkillUsed': return { type: event.type, sequence: event.sequence, player: event.player,
      skillId: event.skillId, ability: event.ability };
    case 'monsterSummoned': return { type: event.type, sequence: event.sequence, player: event.player,
      method: event.method, ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId } : {}) };
    case 'terminalSummonDeclared': return { type: event.type, sequence: event.sequence, player: event.player,
      ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId, materialIds: [...event.materialIds] } : {}) };
    case 'terminalSummonNegated': return { type: event.type, sequence: event.sequence, player: event.player,
      ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId } : {}) };
    case 'terminalSummonAborted': return { type: event.type, sequence: event.sequence, player: event.player,
      reason: event.reason, ...(canSee(event.identityVisibility, observer) ? { cardId: event.cardId } : {}) };
    case 'attackDeclared': return { type: event.type, sequence: event.sequence, battleId: event.battleId,
      player: event.player, ...(canSee(event.identityVisibility, observer) ? {
        attackerId: event.attackerId, target: event.target.kind === 'monster'
          ? { kind: 'monster', cardId: event.target.cardId } : { kind: 'player', player: event.target.player },
      } : {}) };
    case 'battleResolved': return { type: event.type, sequence: event.sequence, battleId: event.battleId,
      player: event.player, outcome: event.outcome,
      ...(event.damage ? { damage: event.damage } : {}),
      ...(canSee(event.attackerVisibility, observer) ? { attackerId: event.attackerId } : {}),
      target: event.target.kind === 'monster'
        ? { kind: 'monster', ...(event.targetVisibility && canSee(event.targetVisibility, observer)
          ? { cardId: event.target.cardId } : {}) }
        : { kind: 'player', player: event.target.player } };
    case 'lifeDamaged': return { type: event.type, sequence: event.sequence, player: event.player,
      amount: event.amount, source: event.source, ...(event.battleId ? { battleId: event.battleId } : {}),
      ...(event.battleSubtype ? { battleSubtype: event.battleSubtype } : {}) };
    case 'effectActivated': return { type: event.type, sequence: event.sequence, linkId: event.linkId,
      player: event.player, ...(canSee(event.sourceVisibility, observer) ? { effectId: event.effectId,
        sourceKind: event.sourceKind, selectionMode: event.selectionMode,
        ...(event.sourceKind === 'card' ? { sourceId: event.sourceId } : {}) } : {}) };
    case 'activationNegated':
    case 'effectNegated': return { type: event.type, sequence: event.sequence, linkId: event.linkId,
      player: event.player, ...(canSee(event.sourceVisibility, observer) ? { effectId: event.effectId,
        sourceKind: event.sourceKind } : {}) };
    case 'effectResolved': return { type: event.type, sequence: event.sequence, linkId: event.linkId,
      player: event.player, outcome: event.outcome, ...(canSee(event.sourceVisibility, observer)
        ? { effectId: event.effectId, sourceKind: event.sourceKind } : {}) };
    case 'keyword_resolve_started':
    case 'keyword_target_hit':
    case 'keyword_applied':
    case 'keyword_failed':
    case 'keyword_status_created':
    case 'keyword_expired':
    case 'keyword_zone_moved':
    case 'keyword_damage_dealt': return { type: event.type, sequence: event.sequence, keywordId: event.keywordId,
      linkId: event.linkId, player: event.player, presentation: { ...event.presentation },
      ...(canSee(event.sourceVisibility, observer) ? { effectId: event.effectId,
        ...(event.sourceId ? { sourceId: event.sourceId } : {}) } : {}),
      ...(event.targetCardId && event.targetVisibility && canSee(event.targetVisibility, observer)
        ? { targetCardId: event.targetCardId } : {}),
      ...(event.statusId && (!event.targetVisibility || canSee(event.targetVisibility, observer)) ? { statusId: event.statusId } : {}),
      ...(event.amount !== undefined ? { amount: event.amount } : {}),
      ...(event.fromZone ? { fromZone: event.fromZone } : {}), ...(event.toZone ? { toZone: event.toZone } : {}),
      ...(event.failure ? { failure: event.failure } : {}) };
    case 'ruleOperation': return { type: event.type, sequence: event.sequence, operationId: event.operationId,
      player: event.player, ...(event.identityVisibility && !canSee(event.identityVisibility, observer) ? {} : {
        ...(event.effectId ? { effectId: event.effectId } : {}), ...(event.cardId ? { cardId: event.cardId } : {}),
      }), ...(event.linkId ? { linkId: event.linkId } : {}) };
    case 'gameEnded': return { type: event.type, sequence: event.sequence, winner: event.winner,
      reason: event.reason };
  }
}
