import type { CardCatalog } from '../model/card.js';
import type { CommandResult } from '../engine/submit-command.js';
import type { DeclareAttackCommand, ChooseBattleTargetCommand, RuleErrorCode } from '../model/command.js';
import { cardIdentityVisibility, type AttackDeclaredEvent, type BattleResolvedEvent, type GameEndedEvent,
  type GameEvent, type LifeDamagedEvent } from '../model/event.js';
import { otherPlayer, type PlayerId } from '../model/ids.js';
import { isKeywordStatusActive } from '../model/keyword.js';
import type { BattleTarget, GameState, PendingBattle, BattleStep } from '../model/state.js';
import { currentTurnCounters } from './counters.js';
import { getBattleDamageReduction, getContinuousBattleAtkModifier, getCurrentDirectAttackDamage,
  getCurrentMonsterStat } from './effects.js';
import { resultForLifeTotals } from './victory.js';
import { moveCard } from '../engine/move-card.js';
import { canDeclareBasicAttack } from '../engine/phase-machine.js';

export type AttackTarget = BattleTarget;

function accepted(state: GameState, events: readonly GameEvent[] = []): CommandResult {
  return { ok: true, state, events };
}

type BattleTriggerRecorder = (state: GameState, events: readonly GameEvent[]) => GameState;

const noBattleTriggerRecording: BattleTriggerRecorder = (state) => state;

function rejected(state: GameState, code: RuleErrorCode): CommandResult {
  return { ok: false, state, error: { code } };
}

function isTank(definition: { readonly profession?: string } | undefined): boolean {
  return definition?.profession === 'tank' || definition?.profession === '坦克';
}

function activeMonsterIds(state: GameState, player: PlayerId): readonly string[] {
  return [...state.players[player].zones.frontline, ...state.players[player].zones.normal]
    .filter((id): id is string => id !== null)
    .filter((id) => {
      const card = state.cards[id];
      return card !== undefined && card.face === 'up' && card.location.player === player &&
        (card.location.zone === 'frontline' || card.location.zone === 'normal');
    });
}

function monsterTarget(id: string): AttackTarget {
  return { kind: 'monster', cardId: id };
}

/** Tank terminals protect the field from ordinary attacks from either monster zone. */
export function getAttackTargets(state: GameState, attackerId: string, catalog: CardCatalog): readonly AttackTarget[] {
  if (catalog.version !== state.catalogVersion) return [];
  const attacker = Object.hasOwn(state.cards, attackerId) ? state.cards[attackerId] : undefined;
  if (!attacker || attacker.controller !== state.turnPlayer || attacker.face !== 'up' ||
    (attacker.location.zone !== 'normal' && attacker.location.zone !== 'frontline')) return [];
  const defender = otherPlayer(attacker.controller);
  const definition = Object.hasOwn(catalog.cards, attacker.cardId) ? catalog.cards[attacker.cardId] : undefined;
  const isMage = definition?.id === attacker.cardId &&
    (definition.profession === 'mage' || definition.profession === '法师');
  const mageDamage = isMage &&
    Number.isInteger(definition.directAttackDamage) && (definition.directAttackDamage ?? 0) > 0
    ? definition.directAttackDamage : undefined;
  if (isMage) return mageDamage === undefined ? [] : [{ kind: 'player', player: defender }];
  if (!definition || definition.id !== attacker.cardId || definition.atk === undefined) return [];
  const enemies = activeMonsterIds(state, defender);
  const frontline = enemies.filter((id) => state.cards[id]!.location.zone === 'frontline');
  const tanks = enemies.filter((id) => {
    const card = state.cards[id]!;
    const targetDefinition = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
    return targetDefinition?.id === card.cardId && targetDefinition.deck === 'extra' && isTank(targetDefinition);
  });
  let ordinaryTargets: AttackTarget[];
  if (tanks.length > 0) ordinaryTargets = tanks.map(monsterTarget);
  else {
    const terminals = frontline.filter((id) => {
      const card = state.cards[id]!;
      const item = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
      return item?.id === card.cardId && item.deck === 'extra';
    });
    if (terminals.length > 0) ordinaryTargets = terminals.map(monsterTarget);
    else {
      const frontlineMain = frontline.filter((id) => {
        const card = state.cards[id]!;
        const item = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
        return item?.id === card.cardId && item.deck === 'main';
      });
      if (frontlineMain.length > 0) ordinaryTargets = frontlineMain.map(monsterTarget);
      else {
        const normal = enemies.filter((id) => state.cards[id]!.location.zone === 'normal');
        ordinaryTargets = normal.length > 0 ? normal.map(monsterTarget) : [{ kind: 'player', player: defender }];
      }
    }
  }
  return ordinaryTargets.filter((target) => {
    if (target.kind !== 'monster') return true;
    const targetDefinition = catalog.cards[state.cards[target.cardId]!.cardId];
    if (targetDefinition?.def !== undefined) return true;
    // A configured extra-deck Mage remains a legal attack target; the confirmed incoming
    // damage rule destroys it and uses the attacker's final effective ATK at damage calculation.
    return targetDefinition?.deck === 'extra' &&
      (targetDefinition.profession === 'mage' || targetDefinition.profession === '法师') &&
      targetDefinition.def === undefined && Number.isInteger(targetDefinition.directAttackDamage) &&
      (targetDefinition.directAttackDamage ?? 0) > 0;
  });
}

function targetEqual(a: BattleTarget, b: BattleTarget): boolean {
  return a.kind === b.kind && (a.kind === 'monster'
    ? b.kind === 'monster' && a.cardId === b.cardId
    : b.kind === 'player' && a.player === b.player);
}

function targetIsLegal(state: GameState, battle: PendingBattle, catalog: CardCatalog): boolean {
  if (battle.target.kind === 'monster') {
    const target = Object.hasOwn(state.cards, battle.target.cardId) ? state.cards[battle.target.cardId] : undefined;
    const snapshot = battle.targetSnapshot;
    if (!target || !snapshot || target.location.player !== snapshot.player || target.location.zone !== snapshot.zone ||
      target.zoneEntrySequence !== snapshot.zoneEntrySequence) return false;
  }
  return getAttackTargets(state, battle.attackerId, catalog).some((target) => targetEqual(target, battle.target));
}

function snapshotTarget(state: GameState, target: BattleTarget): PendingBattle['targetSnapshot'] {
  if (target.kind !== 'monster') return undefined;
  const card = Object.hasOwn(state.cards, target.cardId) ? state.cards[target.cardId] : undefined;
  if (!card || (card.location.zone !== 'normal' && card.location.zone !== 'frontline')) return undefined;
  return { player: card.location.player, zone: card.location.zone, zoneEntrySequence: card.zoneEntrySequence };
}

function attackerIsValid(state: GameState, battle: PendingBattle): boolean {
  const attacker = Object.hasOwn(state.cards, battle.attackerId) ? state.cards[battle.attackerId] : undefined;
  return !!attacker && attacker.controller === battle.player && attacker.face === 'up' &&
    attacker.location.player === battle.player && attacker.location.zone === battle.attackerZone &&
    attacker.zoneEntrySequence === battle.attackerZoneEntrySequence && !attacker.flags.includes('cannotAttack') &&
    !isKeywordStatusActive(state, attacker.id, 'freeze');
}

function cancelBattle(state: GameState, battle: PendingBattle): CommandResult {
  const event: BattleResolvedEvent = { type: 'battleResolved', sequence: state.eventSequence + 1,
    battleId: battle.id, player: battle.player, attackerId: battle.attackerId,
    target: battle.target, outcome: 'cancelled',
    attackerVisibility: cardIdentityVisibility(state.cards[battle.attackerId], battle.player),
    ...(battle.target.kind === 'monster' ? {
      targetVisibility: cardIdentityVisibility(state.cards[battle.target.cardId], otherPlayer(battle.player)),
    } : {}) };
  return accepted({ ...state, pendingBattle: null, responsePasses: 0,
    window: { kind: 'open', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
    eventSequence: event.sequence }, [event]);
}

/** Re-check the original attack after every response chain; target loss grants a new target choice. */
export function reconcileBattle(state: GameState, catalog: CardCatalog): CommandResult {
  const battle = state.pendingBattle;
  if (!battle || battle.stage === 'battleEnd' || battle.stage === 'retarget') return accepted(state);
  if (battle.attackNegated) return cancelBattle(state, battle);
  if (!attackerIsValid(state, battle)) return cancelBattle(state, battle);
  if (!targetIsLegal(state, battle, catalog)) return accepted({ ...state,
    pendingBattle: { ...battle, stage: 'retarget', resumeStage: battle.stage }, responsePasses: 0,
    window: { kind: 'choice', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
  });
  return accepted(state);
}

export function declareAttack(state: GameState, command: DeclareAttackCommand, catalog: CardCatalog): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (!canDeclareBasicAttack(state, command.player, command.attackerId) || state.pendingBattle) return rejected(state, 'INVALID_ATTACK');
  const attacker = Object.hasOwn(state.cards, command.attackerId) ? state.cards[command.attackerId] : undefined;
  if (!attacker) return rejected(state, 'INVALID_ATTACK');
  if (!getAttackTargets(state, command.attackerId, catalog).some((target) => targetEqual(target, command.target))) {
    return rejected(state, 'INVALID_ATTACK_TARGET');
  }
  const id = `battle:${state.eventSequence + 1}`;
  const event: AttackDeclaredEvent = { type: 'attackDeclared', sequence: state.eventSequence + 1,
    battleId: id, player: command.player, attackerId: command.attackerId, target: command.target,
    identityVisibility: 'public' };
  const targetSnapshot = snapshotTarget(state, command.target);
  const counters = currentTurnCounters(state, command.player);
  const next: GameState = { ...state, pendingBattle: { id, player: command.player,
    attackerId: attacker.id, attackerZone: attacker.location.zone as 'normal' | 'frontline',
    attackerZoneEntrySequence: attacker.zoneEntrySequence, target: command.target,
    ...(targetSnapshot ? { targetSnapshot } : {}), stage: 'attackDeclaration' },
    counters: { ...state.counters, [command.player]: { ...counters,
      attacksDeclared: { ...counters.attacksDeclared, [attacker.id]: (counters.attacksDeclared[attacker.id] ?? 0) + 1 },
    } }, responsePasses: 0, eventSequence: event.sequence,
    window: { kind: 'response', priorityPlayer: otherPlayer(command.player), id: state.window.id + 1 },
  };
  return accepted(next, [event]);
}

export function chooseBattleTarget(state: GameState, command: ChooseBattleTargetCommand,
  catalog: CardCatalog): CommandResult {
  const battle = state.pendingBattle;
  if (!battle || battle.stage !== 'retarget' || state.window.kind !== 'choice' ||
    state.window.priorityPlayer !== command.player || command.player !== battle.player) return rejected(state, 'INVALID_ATTACK_TARGET');
  if (command.target === null) return cancelBattle(state, battle);
  const target = command.target;
  const candidates = getAttackTargets(state, battle.attackerId, catalog);
  if (!candidates.some((candidate) => targetEqual(candidate, target))) return rejected(state, 'INVALID_ATTACK_TARGET');
  const targetSnapshot = snapshotTarget(state, target);
  const next: GameState = { ...state, pendingBattle: { ...battle, target,
    ...(targetSnapshot ? { targetSnapshot } : { targetSnapshot: undefined }),
    stage: battle.resumeStage ?? 'attackDeclaration', resumeStage: undefined }, responsePasses: 0,
    window: { kind: 'response', priorityPlayer: otherPlayer(battle.player), id: state.window.id + 1 },
  };
  return accepted(next);
}

function stat(state: GameState, id: string, key: 'atk' | 'def', catalog: CardCatalog): number | null {
  return getCurrentMonsterStat(state, id, key, catalog, true) ?? null;
}

function settledResult(state: GameState): { readonly state: GameState; readonly events: readonly GameEvent[] } {
  const result = resultForLifeTotals({ p1: state.players.p1.life, p2: state.players.p2.life });
  if (!result) return { state, events: [] };
  const event: GameEndedEvent = { type: 'gameEnded', sequence: state.eventSequence + 1,
    winner: result.winner, reason: result.reason };
  return { state: { ...state, result, eventSequence: event.sequence, pendingBattle: null,
    window: { kind: 'open', priorityPlayer: state.turnPlayer, id: state.window.id + 1 } }, events: [event] };
}

/** Resolves the current combat after its declaration/before-damage/calculation windows pass. */
export function resolveBattle(state: GameState, catalog: CardCatalog,
  recordTriggers: BattleTriggerRecorder = noBattleTriggerRecording): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  const battle = state.pendingBattle;
  if (!battle || battle.stage !== 'damageCalculation') return rejected(state, 'INVALID_ATTACK');
  const reconciled = reconcileBattle(state, catalog);
  if (!reconciled.ok || reconciled.state.pendingBattle?.stage !== 'damageCalculation') return reconciled;
  let next = reconciled.state;
  const current = next.pendingBattle!;
  if (current.attackNegated) return cancelBattle(next, current);
  const events: GameEvent[] = [];
  let outcome: BattleResolvedEvent['outcome'] = 'noDamage';
  let battleDamage: BattleResolvedEvent['damage'];
  const attacker = next.cards[current.attackerId]!;
  if (current.target.kind === 'player') {
    const definition = catalog.cards[attacker.cardId];
    const mageSpellAttack = (definition?.profession === 'mage' || definition?.profession === '法师') &&
      Number.isInteger(definition?.directAttackDamage) && (definition?.directAttackDamage ?? 0) > 0;
    const amount = mageSpellAttack
      ? getCurrentDirectAttackDamage(next, attacker.id, catalog)
      : stat(next, attacker.id, 'atk', catalog);
    if (amount == null) return rejected(state, 'UNRESOLVED_RULE');
    next = { ...next, players: { ...next.players, [current.target.player]: {
      ...next.players[current.target.player], life: next.players[current.target.player].life - amount,
    } } };
    const damage: LifeDamagedEvent = { type: 'lifeDamaged', sequence: next.eventSequence + 1,
      player: current.target.player, amount, source: 'battle', battleId: current.id,
      ...(mageSpellAttack ? { battleSubtype: 'mageSpellAttack' as const } : {}) };
    next = { ...next, eventSequence: damage.sequence };
    events.push(damage);
    next = recordTriggers(next, [damage]);
    outcome = 'directDamage';
  } else {
    const defender = next.cards[current.target.cardId];
    if (!defender) return reconcileBattle(next, catalog);
    const defenderDefinition = Object.hasOwn(catalog.cards, defender.cardId) ? catalog.cards[defender.cardId] : undefined;
    const attack = stat(next, attacker.id, 'atk', catalog);
    if (attack === null) return rejected(state, 'UNRESOLVED_RULE');
    const attackedExtraMage = defenderDefinition?.id === defender.cardId && defenderDefinition.deck === 'extra' &&
      (defenderDefinition.profession === 'mage' || defenderDefinition.profession === '法师');
    if (attackedExtraMage) {
      next = { ...next, players: { ...next.players, [defender.controller]: {
        ...next.players[defender.controller], life: next.players[defender.controller].life - attack,
      } } };
      const damage: LifeDamagedEvent = { type: 'lifeDamaged', sequence: next.eventSequence + 1,
        player: defender.controller, amount: attack, source: 'battle', battleId: current.id };
      next = { ...next, eventSequence: damage.sequence };
      events.push(damage);
      next = recordTriggers(next, [damage]);
      const moved = moveCard(next, { cardId: defender.id, actor: current.player, reason: 'destroy', destructionCause: 'battle', catalog });
      if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
      next = moved.state;
      events.push(...moved.events);
      outcome = 'destroyedDefender';
    } else {
      const defense = stat(next, defender.id, 'def', catalog);
      if (defense === null) return rejected(state, 'UNRESOLVED_RULE');
      if (attack > defense) {
        const rawAmount = attack - defense;
        const pendingReward = next.battleRewards?.[current.player];
        const rewardQualifies = pendingReward && pendingReward.expiresAtTurn >= next.globalTurn &&
          defender.controller !== current.player && rawAmount >= 500;
        const rewardExchange = rewardQualifies ? 500 : 0;
        const otherReduction = getBattleDamageReduction(next, defender.controller, defender.id, catalog);
        const amount = Math.max(0, rawAmount - rewardExchange - otherReduction);
        next = { ...next, players: { ...next.players, [defender.controller]: {
          ...next.players[defender.controller], life: next.players[defender.controller].life - amount,
        } } };
        const damage: LifeDamagedEvent = { type: 'lifeDamaged', sequence: next.eventSequence + 1,
          player: defender.controller, amount, source: 'battle', battleId: current.id };
        next = { ...next, eventSequence: damage.sequence };
        events.push(damage);
        next = recordTriggers(next, [damage]);
        const moved = moveCard(next, { cardId: defender.id, actor: current.player, reason: 'destroy', destructionCause: 'battle', catalog });
        if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
        next = moved.state;
        events.push(...moved.events);
        outcome = 'destroyedDefender';
        if (rewardQualifies && pendingReward) {
          const rewards = { ...next.battleRewards };
          delete rewards[current.player];
          next = { ...next, battleRewards: rewards };
          if (pendingReward.kind === 'draw') {
            const top = next.players[current.player].zones.mainDeck[0];
            if (top) {
              const drawn = moveCard(next, { cardId: top, actor: current.player, reason: 'draw', catalog,
                destination: { player: current.player, zone: 'hand' } });
              if (drawn.status === 'moved') {
                next = recordTriggers(drawn.state, drawn.events);
                events.push(...drawn.events);
              }
            } else {
              const ended: GameEndedEvent = { type: 'gameEnded', sequence: next.eventSequence + 1,
                winner: otherPlayer(current.player), reason: 'emptyDraw' };
              next = { ...next, result: { winner: ended.winner, reason: ended.reason }, eventSequence: ended.sequence };
              events.push(ended);
            }
          } else {
            const survivingAttacker = next.cards[attacker.id];
            if (survivingAttacker && (survivingAttacker.location.zone === 'normal' || survivingAttacker.location.zone === 'frontline')) {
              next = { ...next, cards: { ...next.cards, [attacker.id]: { ...survivingAttacker,
                modifiers: [...survivingAttacker.modifiers, { id: `battleReward:${current.id}`, def: 600,
                  expiresAtTurn: next.globalTurn + 1 }] } } };
            }
          }
        }
        battleDamage = { original: rawAmount, rewardExchange, otherReduction, final: amount,
          ...(rewardQualifies && pendingReward ? { rewardKind: pendingReward.kind } : {}) };
      } else if (attack < defense) {
        const moved = moveCard(next, { cardId: attacker.id, actor: current.player, reason: 'destroy', destructionCause: 'battle', catalog });
        if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
        next = moved.state;
        events.push(...moved.events);
        next = recordTriggers(next, moved.events);
        outcome = 'destroyedAttacker';
      }
    }
  }
  const battleEvent: BattleResolvedEvent = { type: 'battleResolved', sequence: next.eventSequence + 1,
    battleId: current.id, player: current.player, attackerId: current.attackerId,
    target: current.target, outcome,
    attackerVisibility: cardIdentityVisibility(next.cards[current.attackerId], current.player),
    ...(current.target.kind === 'monster' ? {
      targetVisibility: cardIdentityVisibility(next.cards[current.target.cardId], otherPlayer(current.player)),
    } : {}), ...(battleDamage ? { damage: battleDamage } : {}) };
  next = { ...next, eventSequence: battleEvent.sequence,
    pendingBattle: { ...current, stage: 'battleEnd', resumeStage: undefined }, responsePasses: 0,
    window: { kind: 'response', priorityPlayer: otherPlayer(current.player), id: next.window.id + 1 },
  };
  events.push(battleEvent);
  const settled = settledResult(next);
  return accepted(settled.state, [...events, ...settled.events]);
}

function advanceStage(state: GameState, catalog: CardCatalog,
  recordTriggers: BattleTriggerRecorder = noBattleTriggerRecording): CommandResult {
  const battle = state.pendingBattle;
  if (!battle) return rejected(state, 'INVALID_RESPONSE');
  if (battle.stage === 'retarget') return rejected(state, 'INVALID_RESPONSE');
  if (battle.stage === 'battleEnd') return accepted({ ...state, pendingBattle: null, responsePasses: 0,
    window: { kind: 'open', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
  });
  const nextStage: Record<Exclude<BattleStep, 'retarget'>, Exclude<BattleStep, 'retarget'>> = {
    attackDeclaration: 'damageBefore', damageBefore: 'damageCalculation',
    damageCalculation: 'damageCalculation', battleEnd: 'battleEnd',
  };
  if (battle.stage === 'damageCalculation') return resolveBattle(state, catalog, recordTriggers);
  const nextBattle: PendingBattle = { ...battle, stage: nextStage[battle.stage] };
  const prepared = reconcileBattle({ ...state, pendingBattle: nextBattle, responsePasses: 0,
    window: { kind: 'response', priorityPlayer: otherPlayer(battle.player), id: state.window.id + 1 },
  }, catalog);
  return prepared;
}

/** A settled response chain has already consumed both players' passes for its current battle window. */
export function resumeBattleAfterChain(state: GameState, catalog: CardCatalog,
  recordTriggers: BattleTriggerRecorder = noBattleTriggerRecording): CommandResult {
  if (!state.pendingBattle || state.pendingSummon || state.chain.length > 0 || state.pendingTriggers.length > 0 ||
    state.window.kind !== 'response') return rejected(state, 'INVALID_RESPONSE');
  return advanceStage(state, catalog, recordTriggers);
}

export function passBattlePriority(state: GameState, player: PlayerId, catalog: CardCatalog,
  recordTriggers: BattleTriggerRecorder = noBattleTriggerRecording): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (!state.pendingBattle || state.window.kind !== 'response' || state.window.priorityPlayer !== player ||
    state.chain.length !== 0 || state.pendingTriggers.length !== 0 || state.pendingSummon) return rejected(state, 'INVALID_RESPONSE');
  if ((state.responsePasses ?? 0) === 0) return accepted({ ...state, responsePasses: 1,
    window: { ...state.window, priorityPlayer: otherPlayer(player), id: state.window.id + 1 },
  });
  return advanceStage({ ...state, responsePasses: 0 }, catalog, recordTriggers);
}

export function applyEffectDamage(state: GameState, player: PlayerId, amount: number, catalog: CardCatalog): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (state.result !== null) return rejected(state, 'GAME_OVER');
  if ((player !== 'p1' && player !== 'p2') || !Number.isFinite(amount) || amount < 0) return rejected(state, 'INVALID_TARGET');
  const next: GameState = { ...state, players: { ...state.players, [player]: {
    ...state.players[player], life: state.players[player].life - amount,
  } } };
  const damage: LifeDamagedEvent = { type: 'lifeDamaged', sequence: state.eventSequence + 1,
    player, amount, source: 'effect' };
  const withEvent = { ...next, eventSequence: damage.sequence };
  const settled = settledResult(withEvent);
  return accepted(settled.state, [damage, ...settled.events]);
}
