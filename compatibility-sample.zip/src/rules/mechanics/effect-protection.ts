import type { CardCatalog } from '../model/card.js';
import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { GameState } from '../model/state.js';

/** Consume a face-up card's once-per-global-turn protection against opposing card effects. */
export function consumeEffectDestructionProtection(state: GameState, cardId: CardInstanceId,
  actor: PlayerId, catalog: CardCatalog): GameState | null {
  const card = state.cards[cardId];
  if (!card || card.controller === actor || card.face !== 'up' ||
    !['normal', 'frontline'].includes(card.location.zone) || card.flags.includes('effectsNegated') ||
    card.effectDestructionProtectionUsedTurn === state.globalTurn) return null;
  const definition = catalog.cards[card.cardId];
  const protectedNow = definition?.effectIds?.some((id) => {
    const effect = catalog.effects?.[id];
    return effect?.mode === 'continuous' && effect.continuousSelfEffectDestructionProtectionOncePerTurn &&
      effect.allowedZones.includes(card.location.zone);
  });
  if (!protectedNow) return null;
  return { ...state, cards: { ...state.cards, [cardId]: { ...card, effectDestructionProtectionUsedTurn: state.globalTurn } } };
}
