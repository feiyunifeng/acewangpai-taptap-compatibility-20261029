import type { CardCatalog, CardDefinition } from '../model/card.js';
import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { GameState } from '../model/state.js';
import type { RuleCheck } from './summoning.js';
import { ruleSummonTpCost } from './tp.js';

export function requiredMainSummonTributes(level: number): number {
  return level >= 9 ? 2 : level >= 5 ? 1 : 0;
}

function isFieldMaterial(state: GameState, player: PlayerId, id: CardInstanceId, catalog: CardCatalog): boolean {
  const card = Object.hasOwn(state.cards, id) ? state.cards[id] : undefined;
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId || definition.kind !== 'monster' || card.owner !== player ||
    card.controller !== player || card.location.player !== player || card.face !== 'up' ||
    (card.location.zone !== 'normal' && card.location.zone !== 'frontline')) return false;
  const zone = state.players[player].zones[card.location.zone];
  return Number.isInteger(card.location.slot) && zone[card.location.slot!] === id;
}

export function checkMainSummonMaterials(state: GameState, player: PlayerId, definition: CardDefinition,
  materialIds: readonly CardInstanceId[], catalog: CardCatalog): RuleCheck {
  const required = requiredMainSummonTributes(definition.level);
  const tpCost = ruleSummonTpCost(definition.level);
  if (tpCost === null || state.players[player].tp < tpCost) return { ok: false, error: { code: 'INSUFFICIENT_TP' } };
  if (materialIds.length !== required || new Set(materialIds).size !== materialIds.length ||
    materialIds.some((id) => !isFieldMaterial(state, player, id, catalog))) {
    return { ok: false, error: { code: 'INVALID_MATERIAL' } };
  }
  return { ok: true };
}

export function mainSummonMaterialSets(state: GameState, player: PlayerId, cardId: CardInstanceId,
  catalog: CardCatalog): readonly (readonly CardInstanceId[])[] {
  const card = Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId || definition.kind !== 'monster' || definition.deck !== 'main' || definition.noRuleSummon) return [];
  const tpCost = ruleSummonTpCost(definition.level);
  if (tpCost === null || state.players[player].tp < tpCost) return [];
  const count = requiredMainSummonTributes(definition.level);
  const available = [...state.players[player].zones.normal, ...state.players[player].zones.frontline]
    .filter((id): id is CardInstanceId => id !== null && isFieldMaterial(state, player, id, catalog));
  const results: CardInstanceId[][] = [];
  const choose = (start: number, picked: CardInstanceId[]) => {
    if (picked.length === count) { results.push([...picked]); return; }
    for (let index = start; index <= available.length - (count - picked.length); index++) {
      picked.push(available[index]!);
      choose(index + 1, picked);
      picked.pop();
    }
  };
  choose(0, []);
  return results;
}
