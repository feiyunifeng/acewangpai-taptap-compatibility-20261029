import type { CardCatalog } from '../model/card.js';
import type { RuleErrorCode } from '../model/command.js';
import type { PlayerId, SkillCopyId } from '../model/ids.js';
import type { GameState, SkillCopy } from '../model/state.js';
import { currentTurnCounters } from './counters.js';

export function skillCopyForActivation(state: GameState, catalog: CardCatalog, player: PlayerId, copyId: SkillCopyId):
  { readonly copy: SkillCopy; readonly name: string; readonly speed: 2 | 3 } |
  { readonly error: RuleErrorCode } {
  const copy = Object.hasOwn(state.skills, copyId) ? state.skills[copyId] : undefined;
  if (!copy || copy.owner !== player || !state.players[player].skillCopies.includes(copyId)) return { error: 'INVALID_EFFECT_SOURCE' };
  const definition = Object.hasOwn(catalog.skills, copy.skillId) ? catalog.skills[copy.skillId] : undefined;
  if (!definition || definition.id !== copy.skillId) return { error: 'INVALID_EFFECT_SOURCE' };
  if (copy.used) return { error: 'SKILL_USED' };
  if (currentTurnCounters(state, player).skillsUsed >= state.config.skillsPerTurn) return { error: 'SKILL_LIMIT_REACHED' };
  return { copy, name: definition.name, speed: definition.name === '识破' ? 3 : definition.speed ?? 2 };
}

export function consumeSkillCopy(state: GameState, player: PlayerId, copyId: SkillCopyId): GameState {
  const counters = currentTurnCounters(state, player);
  return { ...state,
    skills: { ...state.skills, [copyId]: { ...state.skills[copyId]!, used: true } },
    counters: { ...state.counters, [player]: { ...counters, skillsUsed: counters.skillsUsed + 1 } },
  };
}
