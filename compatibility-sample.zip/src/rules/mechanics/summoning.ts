import type { CardCatalog, CardDefinition } from '../model/card.js';
import type { RuleErrorCode } from '../model/command.js';
import type { GameEvent, MonsterSummonedEvent, TerminalSummonAbortedEvent, TerminalSummonDeclaredEvent, TerminalSummonNegatedEvent } from '../model/event.js';
import type { RuleOperationEvent } from '../model/keyword.js';
import { otherPlayer, type CardInstanceId, type PlayerId } from '../model/ids.js';
import type { CardInstance, GameState } from '../model/state.js';
import { moveCard } from '../engine/move-card.js';
import { isOpenMainWindow } from '../engine/phase-machine.js';
import { isFieldZone } from './zones.js';
import { canonicalIds } from '../model/selection.js';
import { getCurrentLevel } from './levels.js';
import { payRuleSummonTp, ruleSummonTpCost } from './tp.js';

export interface RuleSummonRequest {
  readonly terminalId: CardInstanceId;
  readonly materialIds: readonly CardInstanceId[];
  readonly zone?: 'normal' | 'frontline';
  readonly slot?: number;
}

export interface EffectSummonRequest extends RuleSummonRequest {
  readonly player: PlayerId;
  /** Exact selected non-default materials authorized by a validated effect, never by a client command. */
  readonly authorizedMaterialIds?: readonly CardInstanceId[];
  /** Chain resolution calls this only for an active effect; explicit negation is a no-op. */
  readonly status?: 'active' | 'activationNegated' | 'effectNegated';
}

export type RuleCheck = { readonly ok: true } | { readonly ok: false; readonly error: { readonly code: RuleErrorCode } };
export type SummonResult =
  | { readonly status: 'summoned' | 'declared' | 'negated' | 'aborted'; readonly state: GameState; readonly events: readonly GameEvent[] }
  | { readonly status: 'failed'; readonly state: GameState; readonly events: readonly []; readonly error: { readonly code: RuleErrorCode } };

/** Trusted engine hook, invoked at each intermediate event state. */
export type SummonEventObserver = (state: GameState, events: readonly GameEvent[]) => GameState;

function fail(state: GameState, code: RuleErrorCode): SummonResult {
  return { status: 'failed', state, events: [], error: { code } };
}

function definition(catalog: CardCatalog, card: CardInstance): CardDefinition | undefined {
  const result = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  return result?.id === card.cardId ? result : undefined;
}

function sourceContains(state: GameState, card: CardInstance): boolean {
  const { player, zone, slot } = card.location;
  const cards = state.players[player]?.zones[zone];
  if (!cards) return false;
  if (isFieldZone(zone)) return Number.isInteger(slot) && slot! >= 0 && slot! < cards.length && cards[slot!] === card.id;
  return slot === undefined && cards.includes(card.id);
}

function validExtraTarget(state: GameState, player: PlayerId, terminalId: CardInstanceId, catalog: CardCatalog):
  { readonly card: CardInstance; readonly definition: CardDefinition } | null {
  const card = Object.hasOwn(state.cards, terminalId) ? state.cards[terminalId] : undefined;
  const target = card ? definition(catalog, card) : undefined;
  return card && target && target.kind === 'monster' && target.deck === 'extra' &&
    Number.isFinite(target.level) && target.level! > 0 && card.owner === player &&
    card.location.player === player && card.location.zone === 'extraDeck' &&
    state.players[player].zones.extraDeck.includes(card.id) ? { card, definition: target } : null;
}

function validMaterialCondition(target: CardDefinition, materialDefinitions: readonly CardDefinition[]): boolean {
  if (target.materialCount !== undefined && (!Number.isInteger(target.materialCount) ||
    target.materialCount < 1 || materialDefinitions.length !== target.materialCount)) return false;
  if (target.materialRequirements?.some((requirement) => {
    const count = materialDefinitions.filter((material) =>
      (requirement.archetypeId === undefined || material.archetypeIds?.includes(requirement.archetypeId)) &&
      (requirement.profession === undefined || material.profession === requirement.profession) &&
      (requirement.deck === undefined || material.deck === requirement.deck) &&
      (requirement.cardId === undefined || material.id === requirement.cardId) &&
      (requirement.cardIds === undefined || requirement.cardIds.includes(material.id)) &&
      (requirement.noEffects === undefined || requirement.noEffects === !(material.effectIds?.length)) &&
      (requirement.minimumLevel === undefined || (material.level ?? 0) >= requirement.minimumLevel) &&
      (requirement.maximumLevel === undefined || (material.level ?? 0) <= requirement.maximumLevel)).length;
    return !Number.isInteger(requirement.minimumCount) || requirement.minimumCount < 1 || count < requirement.minimumCount;
  })) return false;
  switch (target.materialConditionId) {
    case undefined: return true;
    case 'sameArchetype': return !!target.archetypeIds?.some((archetypeId) => materialDefinitions.every((item) =>
      item.archetypeIds?.includes(archetypeId)));
    case 'sameProfession': return target.profession !== undefined && materialDefinitions.every((item) => item.profession === target.profession);
    case 'atLeastTwo': return materialDefinitions.length >= 2;
    default: return false;
  }
}

function summonSlot(state: GameState, player: PlayerId, request: RuleSummonRequest): number | null {
  const slots = state.players[player].zones[request.zone ?? 'frontline'];
  const materialSet = new Set(request.materialIds);
  if ((request.zone ?? 'frontline') === 'normal' &&
    state.players[player].zones.frontline.some((id) => id === null || materialSet.has(id))) return null;
  if (request.slot !== undefined) {
    if (!Number.isInteger(request.slot) || request.slot < 0 || request.slot >= slots.length) return null;
    const occupant = slots[request.slot];
    return occupant === null || (occupant !== undefined && materialSet.has(occupant)) ? request.slot : null;
  }
  const index = slots.findIndex((id) => id === null || materialSet.has(id));
  return index < 0 ? null : index;
}

function checkSummon(state: GameState, player: PlayerId, request: RuleSummonRequest, catalog: CardCatalog,
  authorizedMaterialIds: readonly CardInstanceId[] = []): RuleCheck {
  if (catalog.version !== state.catalogVersion) return { ok: false, error: { code: 'CATALOG_MISMATCH' } };
  if (state.result !== null || state.pendingSummon) return { ok: false, error: { code: 'INVALID_SUMMON' } };
  const target = validExtraTarget(state, player, request.terminalId, catalog)?.definition;
  if (!target) return { ok: false, error: { code: 'INVALID_SUMMON' } };
  if (request.materialIds.length === 0 || new Set(request.materialIds).size !== request.materialIds.length) {
    return { ok: false, error: { code: 'INVALID_MATERIAL' } };
  }
  const authorized = new Set(authorizedMaterialIds);
  if (authorized.size !== authorizedMaterialIds.length || authorizedMaterialIds.some((id) => !request.materialIds.includes(id))) {
    return { ok: false, error: { code: 'INVALID_MATERIAL' } };
  }
  const materialDefinitions: CardDefinition[] = [];
  for (const id of request.materialIds) {
    const card = Object.hasOwn(state.cards, id) ? state.cards[id] : undefined;
    const source = card ? definition(catalog, card) : undefined;
    const defaultSource = card && card.controller === player && card.location.player === player && card.face === 'up' &&
      (card.location.zone === 'normal' || card.location.zone === 'frontline');
    const currentLevel = getCurrentLevel(state, id, catalog);
    if (!card || !source || source.kind !== 'monster' || !Number.isFinite(source.level) || source.level! <= 0 || currentLevel === null ||
      id === request.terminalId || !sourceContains(state, card) || (!defaultSource && !authorized.has(id))) {
      return { ok: false, error: { code: 'INVALID_MATERIAL' } };
    }
    materialDefinitions.push(source);
  }
  if (!validMaterialCondition(target, materialDefinitions)) {
    return { ok: false, error: { code: 'INVALID_MATERIAL' } };
  }
  if (summonSlot(state, player, request) === null) return { ok: false, error: { code: 'ZONE_FULL' } };
  return { ok: true };
}

export function canRuleSummonTerminal(state: GameState, player: PlayerId, request: RuleSummonRequest, catalog: CardCatalog): RuleCheck {
  if (!isOpenMainWindow(state, player)) return { ok: false, error: { code: 'NOT_OPEN_WINDOW' } };
  const target = validExtraTarget(state, player, request.terminalId, catalog)?.definition;
  const cost = target ? ruleSummonTpCost(target.level) : null;
  if (cost === null || state.players[player].tp < cost) return { ok: false, error: { code: 'INSUFFICIENT_TP' } };
  return checkSummon(state, player, request, catalog);
}

/** For effect activation checks; chain timing and other legal effect parts are checked by the effect engine. */
export function canEffectSummonTerminal(state: GameState, request: EffectSummonRequest, catalog: CardCatalog): RuleCheck {
  return checkSummon(state, request.player, request, catalog, request.authorizedMaterialIds);
}

function sacrificeMaterials(state: GameState, player: PlayerId, materialIds: readonly CardInstanceId[], catalog: CardCatalog,
  observe?: SummonEventObserver):
  { readonly state: GameState; readonly events: readonly GameEvent[] } | null {
  let next = state;
  const events: GameEvent[] = [];
  for (const cardId of materialIds) {
    if (next.cards[cardId]?.location.zone === 'heaven') continue;
    const moved = moveCard(next, { cardId, actor: player, reason: 'sacrifice', catalog });
    if (moved.status !== 'moved') return null;
    next = observe ? observe(moved.state, moved.events) : moved.state;
    events.push(...moved.events);
  }
  return { state: next, events };
}

export function declareRuleSummon(state: GameState, player: PlayerId, incoming: RuleSummonRequest, catalog: CardCatalog,
  observe?: SummonEventObserver): SummonResult {
  const request = { ...incoming, materialIds: canonicalIds(incoming.materialIds) };
  const check = canRuleSummonTerminal(state, player, request, catalog);
  if (!check.ok) return fail(state, check.error.code);
  const slot = summonSlot(state, player, request)!;
  const target = validExtraTarget(state, player, request.terminalId, catalog)!.definition;
  const payment = payRuleSummonTp(state, player, ruleSummonTpCost(target.level)!);
  if (!payment) return fail(state, 'INSUFFICIENT_TP');
  const declared: TerminalSummonDeclaredEvent = {
    type: 'terminalSummonDeclared', sequence: payment.state.eventSequence + 1,
    player, cardId: request.terminalId, materialIds: [...request.materialIds],
    identityVisibility: 'public',
  };
  const spent = { ...payment.state, eventSequence: declared.sequence };
  const paidObserved = observe ? observe(payment.state, payment.events) : payment.state;
  const observed = observe ? observe({ ...paidObserved, eventSequence: declared.sequence }, [declared]) : spent;
  const sacrificed = sacrificeMaterials(observed, player, request.materialIds, catalog, observe);
  if (!sacrificed) return fail(state, 'MOVE_FAILED');
  return { status: 'declared', state: { ...sacrificed.state,
    pendingSummon: { player, terminalId: request.terminalId, zone: request.zone ?? 'frontline', slot,
      materialIds: [...request.materialIds] },
    window: { kind: 'response', priorityPlayer: otherPlayer(player), id: state.window.id + 1 },
  }, events: [...payment.events, declared, ...sacrificed.events] };
}

function summonToField(state: GameState, player: PlayerId, terminalId: CardInstanceId, zone: 'normal' | 'frontline', slot: number,
  catalog: CardCatalog, method: MonsterSummonedEvent['method'], observe?: SummonEventObserver,
  tributeMaterialIds: readonly CardInstanceId[] = []): SummonResult {
  const moved = moveCard(state, { cardId: terminalId, actor: player, reason: 'effect', catalog,
    ...(zone === 'normal' ? { allowExtraMonsterNormal: true } : {}), destination: { player, zone, slot } });
  if (moved.status !== 'moved') return fail(state, 'MOVE_FAILED');
  const afterMove = observe ? observe(moved.state, moved.events) : moved.state;
  const summonOperation: RuleOperationEvent | undefined = method === 'ruleMain' || method === 'ruleTerminal' ? undefined : {
    type: 'ruleOperation', sequence: afterMove.eventSequence + 1, operationId: 'special_summon', player,
    cardId: terminalId, identityVisibility: 'public',
  };
  const beforeSummonEvent = summonOperation
    ? observe ? observe({ ...afterMove, eventSequence: summonOperation.sequence }, [summonOperation])
      : { ...afterMove, eventSequence: summonOperation.sequence }
    : afterMove;
  const event: MonsterSummonedEvent = {
    type: 'monsterSummoned', sequence: beforeSummonEvent.eventSequence + 1,
    player, cardId: terminalId, method,
    ...(tributeMaterialIds.length ? { tributeCount: tributeMaterialIds.length, tributeMaterialIds: [...tributeMaterialIds] } : {}),
    identityVisibility: 'public',
  };
  const summoned: GameState = { ...beforeSummonEvent,
    cards: { ...beforeSummonEvent.cards, [terminalId]: { ...beforeSummonEvent.cards[terminalId]!,
      properlySummoned: method === 'revival' ? beforeSummonEvent.cards[terminalId]!.properlySummoned : true } },
    eventSequence: event.sequence,
  };
  return { status: 'summoned', state: observe ? observe(summoned, [event]) : summoned,
    events: [...moved.events, ...(summonOperation ? [summonOperation] : []), event] };
}

/** The response engine supplies the negation verdict; passing the window supplies false. */
export function resolveRuleSummon(state: GameState, negated: boolean, catalog: CardCatalog,
  observe?: SummonEventObserver): SummonResult {
  const pending = state.pendingSummon;
  if (!pending || state.window.kind !== 'response' || state.chain.length !== 0 ||
    catalog.version !== state.catalogVersion) {
    return fail(state, catalog.version !== state.catalogVersion ? 'CATALOG_MISMATCH' : 'INVALID_RESPONSE');
  }
  const close = (next: GameState): GameState => ({ ...next, pendingSummon: null,
    window: { kind: 'open', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
  });
  const abort = (reason: TerminalSummonAbortedEvent['reason']): SummonResult => {
    const event: TerminalSummonAbortedEvent = {
      type: 'terminalSummonAborted', sequence: state.eventSequence + 1,
      player: pending.player, cardId: pending.terminalId, reason,
      identityVisibility: 'public',
    };
    return { status: 'aborted', state: close({ ...state, eventSequence: event.sequence }), events: [event] };
  };
  if (!validExtraTarget(state, pending.player, pending.terminalId, catalog)) return abort('TARGET_UNAVAILABLE');
  if (negated) {
    const event: TerminalSummonNegatedEvent = {
      type: 'terminalSummonNegated', sequence: state.eventSequence + 1,
      player: pending.player, cardId: pending.terminalId,
      identityVisibility: 'public',
    };
    return { status: 'negated', state: close({ ...state, eventSequence: event.sequence }), events: [event] };
  }
  const zone = pending.zone ?? 'frontline';
  const slots = state.players[pending.player].zones[zone];
  const slot = slots[pending.slot] === null ? pending.slot : slots.indexOf(null);
  if (slot < 0) return abort('NO_FRONTLINE_SLOT');
  const placed = summonToField(state, pending.player, pending.terminalId, zone, slot, catalog, 'ruleTerminal', observe,
    pending.materialIds ?? []);
  if (placed.status !== 'summoned') return abort('NO_FRONTLINE_SLOT');
  return { ...placed, state: close(placed.state) };
}

/** Called during chain resolution; all resource and placement changes commit together. */
export function completeEffectSummon(state: GameState, incoming: EffectSummonRequest, catalog: CardCatalog,
  observe?: SummonEventObserver): SummonResult {
  const request = { ...incoming, materialIds: canonicalIds(incoming.materialIds),
    ...(incoming.authorizedMaterialIds ? { authorizedMaterialIds: canonicalIds(incoming.authorizedMaterialIds) } : {}) };
  if (catalog.version !== state.catalogVersion) return fail(state, 'CATALOG_MISMATCH');
  if (request.status === 'activationNegated' || request.status === 'effectNegated') return fail(state, 'INVALID_SUMMON');
  const check = canEffectSummonTerminal(state, request, catalog);
  if (!check.ok) return fail(state, check.error.code);
  const slot = summonSlot(state, request.player, request)!;
  const sacrificed = sacrificeMaterials(state, request.player, request.materialIds, catalog, observe);
  if (!sacrificed) return fail(state, 'MOVE_FAILED');
  const zone = request.zone ?? 'frontline';
  const placed = summonToField(sacrificed.state, request.player, request.terminalId, zone, slot, catalog, 'effectTerminal', observe,
    request.materialIds);
  if (placed.status !== 'summoned') return fail(state, 'MOVE_FAILED');
  return { ...placed, events: [...sacrificed.events, ...placed.events] };
}

export function canReviveTerminal(state: GameState, instanceId: CardInstanceId, catalog: CardCatalog): RuleCheck {
  if (catalog.version !== state.catalogVersion) return { ok: false, error: { code: 'CATALOG_MISMATCH' } };
  const card = Object.hasOwn(state.cards, instanceId) ? state.cards[instanceId] : undefined;
  const source = card ? definition(catalog, card) : undefined;
  if (!card || !source || source.kind !== 'monster' || source.deck !== 'extra' ||
    card.location.zone !== 'heaven' || card.location.player !== card.owner ||
    !state.players[card.owner].zones.heaven.includes(instanceId) || !card.properlySummoned ||
    state.result !== null) return { ok: false, error: { code: 'INVALID_SUMMON' } };
  if (state.players[card.owner].zones.frontline.every((id) => id !== null)) {
    return { ok: false, error: { code: 'ZONE_FULL' } };
  }
  return { ok: true };
}

export function reviveTerminal(state: GameState, instanceId: CardInstanceId, catalog: CardCatalog): SummonResult {
  const check = canReviveTerminal(state, instanceId, catalog);
  if (!check.ok) return fail(state, check.error.code);
  const player = state.cards[instanceId]!.owner;
  const slot = state.players[player].zones.frontline.indexOf(null);
  return summonToField(state, player, instanceId, 'frontline', slot, catalog, 'revival');
}
