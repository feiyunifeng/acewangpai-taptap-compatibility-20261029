import type { RulesConfig } from '../model/config.js';
import type { Zone } from '../model/state.js';

export type FieldZone = 'normal' | 'frontline' | 'spellCounter';

export function isFieldZone(zone: Zone): zone is FieldZone {
  return zone === 'normal' || zone === 'frontline' || zone === 'spellCounter';
}

export function fieldCapacity(config: RulesConfig, zone: FieldZone): number {
  switch (zone) {
    case 'normal': return config.normalMonsterSlots;
    case 'frontline': return config.frontlineSlots;
    case 'spellCounter': return config.spellCounterSlots;
  }
}
