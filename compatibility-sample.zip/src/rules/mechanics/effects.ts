import type { CardCatalog } from '../model/card.js';
import type { ChainLink } from '../model/chain.js';
import type { EffectCardFilter, EffectChoicePrompt, EffectDefinition, EffectProgramStep, ResolutionSelection } from '../model/effect.js';
import type { GameEvent } from '../model/event.js';
import type { RuleOperationEvent, RuleOperationId } from '../model/keyword.js';
import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { CardInstance, GameState } from '../model/state.js';
import { isKeywordStatusActive, isValidKeywordOperation } from '../model/keyword.js';
import { moveCard } from '../engine/move-card.js';
import { completeEffectSummon, type SummonEventObserver } from './summoning.js';
import { addLevelModifier } from './levels.js';
import { otherPlayer } from '../model/ids.js';
import { shuffle } from './rng.js';
import { executeKeywordOperation } from './keyword-runtime.js';
import { hasActivatedCardEffectThisTurn } from './counters.js';
import { consumeEffectDestructionProtection } from './effect-protection.js';

export function effectFromCatalog(catalog: CardCatalog, effectId: string): EffectDefinition | undefined {
  const effects = catalog.effects;
  const effect = effects && Object.hasOwn(effects, effectId) ? effects[effectId] : undefined;
  if (effect?.id !== effectId) return undefined;
  const keys = new Set(effect.targets || effect.targetGroups?.length ? ['target'] : []);
  for (const step of effect.program ?? []) {
    if (step.kind === 'selectCards' || step.kind === 'resolveSelect') keys.add(step.key);
    if (step.kind === 'keyword' && (!isValidKeywordOperation(step.operation) || !keys.has(step.operation.key))) return undefined;
  }
  return effect;
}

/** A caller must first establish that this definition belongs to the source card or skill. */
export function deriveAuthorizedMaterials(state: GameState, player: PlayerId, materialIds: readonly CardInstanceId[],
  effect: EffectDefinition): readonly CardInstanceId[] | null {
  const authorized: CardInstanceId[] = [];
  for (const id of materialIds) {
    const card = Object.hasOwn(state.cards, id) ? state.cards[id] : undefined;
    if (!card) return null;
    const defaultSource = card.controller === player && card.location.player === player && card.face === 'up' &&
      (card.location.zone === 'normal' || card.location.zone === 'frontline');
    if (defaultSource) continue;
    const permission = effect.materialPermission;
    if (!permission || !permission.zones.includes(card.location.zone) ||
      (card.controller !== player && !permission.allowOpponent)) return null;
    authorized.push(id);
  }
  return authorized;
}

function validTargets(state: GameState, link: ChainLink, effect: EffectDefinition, catalog: CardCatalog): readonly CardInstanceId[] {
  if (!effect.targets && !effect.targetGroups?.length) return [];
  return link.targetSnapshots.filter((snapshot) => {
    const card = Object.hasOwn(state.cards, snapshot.id) ? state.cards[snapshot.id] : undefined;
    if (!card || card.location.player !== snapshot.player || card.location.zone !== snapshot.zone ||
      card.zoneEntrySequence !== snapshot.zoneEntrySequence) return false;
    const group = effect.targetGroups?.find((item) => item.zones.includes(card.location.zone) && (!item.filter ||
      matchingEffectCards(state, link.player, item.filter, catalog,
        link.source.kind === 'card' ? link.source.instanceId : undefined).includes(card.id)));
    return effect.targetGroups?.length ? !!group :
      effect.targets!.zones.includes(card.location.zone) &&
      (!effect.targets!.filter || matchingEffectCards(state, link.player, effect.targets!.filter, catalog,
        link.source.kind === 'card' ? link.source.instanceId : undefined).includes(card.id));
  }).map((snapshot) => snapshot.id);
}

function replacementFor(state: GameState, targetId: CardInstanceId, attacker: PlayerId,
  catalog: CardCatalog): { readonly player: PlayerId; readonly archetypeId: import('../model/archetype.js').ArchetypeId } | undefined {
  const target = state.cards[targetId];
  const targetDefinition = target && catalog.cards[target.cardId];
  if (!target || !targetDefinition || !targetDefinition.archetypeIds?.length ||
    !['normal', 'frontline', 'spellCounter'].includes(target.location.zone) || target.controller === attacker ||
    state.destructionReplacementUsed?.[target.controller] === state.globalTurn) return undefined;
  for (const id of [...state.players[target.controller].zones.normal, ...state.players[target.controller].zones.frontline,
    ...state.players[target.controller].zones.spellCounter]) {
    if (!id) continue;
    const shield = state.cards[id];
    const shieldDefinition = shield && catalog.cards[shield.cardId];
    if (!shield || !shieldDefinition || shield.face !== 'up' || shield.controller !== target.controller ||
      shield.flags.includes('effectsNegated')) continue;
    for (const effectId of shieldDefinition.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      const replacement = effect?.destructionReplacement;
      if (effect?.mode === 'continuous' && effect.allowedZones.includes(shield.location.zone) && replacement &&
        targetDefinition.archetypeIds.includes(replacement.protectedArchetypeId) &&
        state.players[target.controller].zones[replacement.resourceZone].some((resourceId) => resourceId &&
          catalog.cards[state.cards[resourceId]!.cardId]?.archetypeIds?.includes(replacement.resourceArchetypeId))) {
        return { player: target.controller, archetypeId: replacement.resourceArchetypeId };
      }
    }
  }
  return undefined;
}

function isOpponentMonsterEffect(state: GameState, link: ChainLink, catalog: CardCatalog,
  targetId: CardInstanceId): boolean {
  if (link.source.kind !== 'card') return false;
  const source = state.cards[link.source.instanceId];
  const sourceDefinition = source && catalog.cards[source.cardId];
  const target = state.cards[targetId];
  return sourceDefinition?.kind === 'monster' && !!target && target.controller !== link.player;
}

export interface EffectApplication {
  readonly state: GameState;
  readonly events: readonly GameEvent[];
  readonly applied: boolean;
  readonly negation?: 'activation' | 'effect' | 'summon';
  readonly choice?: EffectChoicePrompt;
}

function cardMatchesFilter(state: GameState, player: PlayerId, filter: EffectCardFilter,
  catalog: CardCatalog, cardId: CardInstanceId, sourceId?: CardInstanceId): boolean {
  const card = Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId || !filter.zones.includes(card.location.zone) ||
    filter.cardIds && !filter.cardIds.includes(card.cardId) ||
    filter.kinds && !filter.kinds.includes(definition.kind) || filter.decks && !filter.decks.includes(definition.deck) ||
    filter.archetypeId !== undefined && !definition.archetypeIds?.includes(filter.archetypeId) ||
    filter.noEffects === true && (definition.effectIds?.length ?? 0) > 0 ||
    filter.properlySummonedIfTerminal === true && definition.deck === 'extra' && !card.properlySummoned ||
    filter.excludeSource === true && sourceId === cardId ||
    filter.activatedThisTurn === true && !hasActivatedCardEffectThisTurn(state, card.id) ||
    filter.maxLevel !== undefined && definition.level > filter.maxLevel ||
    filter.minLevel !== undefined && definition.level < filter.minLevel ||
    filter.maxAtk !== undefined && (getCurrentMonsterStat(state, card.id, 'atk', catalog) === undefined ||
      getCurrentMonsterStat(state, card.id, 'atk', catalog)! > filter.maxAtk) ||
    filter.maxDef !== undefined && (getCurrentMonsterStat(state, card.id, 'def', catalog) === undefined ||
      getCurrentMonsterStat(state, card.id, 'def', catalog)! > filter.maxDef) ||
    filter.maxAtkOrDef !== undefined && !(['atk', 'def'] as const).some((stat) => {
      const value = getCurrentMonsterStat(state, card.id, stat, catalog);
      return value !== undefined && value <= filter.maxAtkOrDef!;
    }) ||
    filter.maxPrintedAtk !== undefined && (definition.atk === undefined || definition.atk > filter.maxPrintedAtk) ||
    filter.requiresAtk && definition.atk === undefined || filter.requiresDef && definition.def === undefined ||
    filter.spellModes && (!definition.spellMode || !filter.spellModes.includes(definition.spellMode)) ||
    filter.atkGreaterThanSource && (sourceId === undefined ||
      getCurrentMonsterStat(state, card.id, 'atk', catalog) === undefined ||
      getCurrentMonsterStat(state, sourceId, 'atk', catalog) === undefined ||
      getCurrentMonsterStat(state, card.id, 'atk', catalog)! <= getCurrentMonsterStat(state, sourceId, 'atk', catalog)!) ||
    filter.profession !== undefined && definition.profession !== filter.profession ||
    filter.face === 'up' && card.face !== 'up' || filter.face === 'down' && card.face !== 'down') return false;
  const cardPlayer = card.location.zone === 'normal' || card.location.zone === 'frontline' || card.location.zone === 'spellCounter'
    ? card.controller : card.owner;
  return filter.side === 'any' || cardPlayer === (filter.side === 'self' ? player : otherPlayer(player));
}

export function matchingEffectCards(state: GameState, player: PlayerId, filter: EffectCardFilter,
  catalog: CardCatalog, sourceId?: CardInstanceId): readonly CardInstanceId[] {
  const result: CardInstanceId[] = [];
  for (const owner of ['p1', 'p2'] as const) for (const zone of filter.zones) {
    for (const id of state.players[owner].zones[zone]) {
      if (id !== null && cardMatchesFilter(state, player, filter, catalog, id, sourceId)) result.push(id);
    }
  }
  return result;
}

function canSummonSelected(state: GameState, player: PlayerId, step: Extract<EffectProgramStep, { kind: 'summonSelected' }>,
  catalog: CardCatalog, id: CardInstanceId): boolean {
  const card = state.cards[id];
  const definition = card && catalog.cards[card.cardId];
  const origins = typeof step.from === 'string' ? [step.from] : step.from;
  if (!card || card.owner !== player || card.location.player !== player || !origins.includes(card.location.zone as 'mainDeck' | 'heaven' | 'hell') ||
    !definition || definition.kind !== 'monster' || definition.deck === 'extra' &&
    (!card.properlySummoned || !['heaven', 'hell'].includes(card.location.zone))) return false;
  const zones = step.to === 'normalOrFrontline' ? ['normal', 'frontline'] as const : [step.to] as const;
  return zones.some((zone) => (definition.deck === 'extra' || zone === 'normal') && state.players[player].zones[zone].includes(null));
}

export function meetsEffectActivationRequirements(state: GameState, player: PlayerId,
  effect: EffectDefinition, catalog: CardCatalog, sourceId?: CardInstanceId): boolean {
  const groups = effect.activationRequirementGroups;
  if (groups?.length && !groups.some((group) => group.every((requirement) =>
    matchingEffectCards(state, player, requirement.filter, catalog, sourceId).length >= requirement.minimum))) return false;
  const summonSelected = effect.program?.find((step) => step.kind === 'summonSelected');
  if (summonSelected) {
    if (summonSelected.to === 'normalOrFrontline'
      ? state.players[player].zones.normal.every((id) => id !== null) && state.players[player].zones.frontline.every((id) => id !== null)
      : state.players[player].zones[summonSelected.to].every((id) => id !== null)) return false;
    const selectionStep = effect.program?.find((step) => step.kind === 'selectCards' && step.key === summonSelected.key);
    const hasResolutionCandidate = selectionStep?.kind === 'selectCards'
      ? matchingEffectCards(state, player, selectionStep.filter, catalog, sourceId)
        .some((id) => canSummonSelected(state, player, summonSelected, catalog, id))
      : summonSelected.key === 'target' && effect.targets !== undefined && (() => {
        const eligible = new Set(effect.targets!.zones.flatMap((zone) => {
          const filter = effect.targets!.filter
            ? { ...effect.targets!.filter, zones: [zone] }
            : { zones: [zone], side: 'self' as const };
          return matchingEffectCards(state, player, filter, catalog, sourceId);
        }));
        return [...eligible].filter((id) => canSummonSelected(state, player, summonSelected, catalog, id)).length >= effect.targets!.min;
      })();
    if (!hasResolutionCandidate) return false;
  }
  return true;
}

function runProgram(state: GameState, link: ChainLink, effect: EffectDefinition, catalog: CardCatalog,
  observe?: SummonEventObserver, resume?: { readonly stepIndex: number;
    readonly context: Readonly<Record<string, readonly ResolutionSelection[]>>;
    readonly successes: Readonly<Record<string, boolean>>; readonly applied?: boolean }): EffectApplication {
  if (link.source.kind !== 'card' || !effect.program) return { state, events: [], applied: false };
  const sourceId = link.source.instanceId;
  let next = state;
  const events: GameEvent[] = [];
  let applied = resume?.applied ?? false;
  const context: Record<string, readonly ResolutionSelection[]> = { ...(resume?.context ?? {}) };
  if (link.targetSnapshots.length > 0 && !Object.hasOwn(context, 'target')) {
    context.target = validTargets(state, link, effect, catalog).map((cardId) => ({ cardId }));
  }
  const successes: Record<string, boolean> = { ...(resume?.successes ?? {}) };
  const start = resume?.stepIndex ?? 0;

  const observeMove = (movedState: GameState, movedEvents: readonly GameEvent[]): GameState =>
    observe ? observe(movedState, movedEvents) : movedState;
  const recordRuleOperation = (operationId: RuleOperationId, cardId?: CardInstanceId,
    identityVisibility: 'public' | PlayerId = link.sourceVisibility): void => {
    const operation: RuleOperationEvent = { type: 'ruleOperation', sequence: next.eventSequence + 1,
      operationId, player: link.player, effectId: effect.id, linkId: link.id,
      ...(cardId ? { cardId, identityVisibility } : {}) };
    next = observe ? observe({ ...next, eventSequence: operation.sequence }, [operation])
      : { ...next, eventSequence: operation.sequence };
    events.push(operation);
  };

  for (let index = start; index < effect.program.length; index++) {
    if (next.result) break;
    const step: EffectProgramStep = effect.program[index]!;
    if ('requiresSuccessKey' in step && step.requiresSuccessKey && !successes[step.requiresSuccessKey]) {
      continue;
    }
    if (step.kind === 'selectCards') {
      if (Object.hasOwn(context, step.key)) continue;
      if (step.requiresFieldFilter && matchingEffectCards(next, link.player, step.requiresFieldFilter, catalog, sourceId).length === 0) {
        context[step.key] = [];
        continue;
      }
      const extra = step.alsoFilterWhenFaceUp && [...next.players[link.player].zones.spellCounter,
        ...next.players[link.player].zones.normal, ...next.players[link.player].zones.frontline]
        .some((id) => id && next.cards[id]?.cardId === step.alsoFilterWhenFaceUp!.cardId &&
          next.cards[id]?.face === 'up' && !next.cards[id]?.flags.includes('effectsNegated'))
        ? matchingEffectCards(next, link.player, step.alsoFilterWhenFaceUp.filter, catalog, sourceId) : [];
      const filtered = step.topDeckCount === undefined ? matchingEffectCards(next, link.player, step.filter, catalog, sourceId)
        : next.players[link.player].zones.mainDeck.slice(0, step.topDeckCount).filter((id) =>
          cardMatchesFilter(next, link.player, step.filter, catalog, id, sourceId));
      const nextSummon = effect.program.slice(index + 1).find((candidate): candidate is Extract<EffectProgramStep, { kind: 'summonSelected' }> =>
        candidate.kind === 'summonSelected' && candidate.key === step.key);
      const candidates = [...new Set([...filtered, ...extra])].filter((id) => !nextSummon || canSummonSelected(next, link.player, nextSummon, catalog, id));
      const destinations = step.destinations?.filter((destination) => destination !== 'spellCounter' ||
        next.players[link.player].zones.spellCounter.some((id) => id === null));
      if (candidates.length === 0 && step.skipIfEmpty) {
        context[step.key] = [];
        continue;
      }
      if (step.destinations && !destinations?.length) {
        context[step.key] = [];
        continue;
      }
      if (candidates.length === 0 && step.min === 0) {
        context[step.key] = [];
        continue;
      }
      if (candidates.length < step.min) {
        context[step.key] = [];
        continue;
      }
      return { state: next, events, applied, choice: {
        stepIndex: index, context, successes, key: step.key, candidates, filter: step.filter,
        ...(step.alsoFilterWhenFaceUp ? { alsoFilterWhenFaceUp: step.alsoFilterWhenFaceUp } : {}),
        minimum: step.min, maximum: step.max === 'all' ? candidates.length : Math.min(step.max, candidates.length), applied,
        ...(destinations ? { destinations } : {}),
      } };
    }
    if (step.kind === 'resolveSelect') {
      const matching = matchingEffectCards(next, link.player, step.filter, catalog, sourceId);
      context[step.key] = (step.max === undefined || step.max === 'all' ? matching : matching.slice(0, step.max))
        .map((cardId) => ({ cardId }));
      continue;
    }
    let stepSucceeded = false;
    if (step.kind === 'moveTopCard') {
      const owner: PlayerId = step.player === 'opponent' ? otherPlayer(link.player) : link.player;
      const top = next.players[owner].zones[step.from][0];
      if (top) {
        const moved = moveCard(next, { cardId: top, actor: link.player, reason: 'send', catalog,
          destination: { player: owner, zone: step.to } });
        if (moved.status === 'moved') {
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          stepSucceeded = moved.state.cards[top]?.location.zone === step.to;
        }
      }
    } else if (step.kind === 'summonSelected') {
      const selected = context[step.key] ?? [];
      const sourceZones = typeof step.from === 'string' ? [step.from] : step.from;
      for (const { cardId } of selected) {
        const card = next.cards[cardId];
        const definition = card && catalog.cards[card.cardId];
        if (!card || card.owner !== link.player || !sourceZones.includes(card.location.zone as 'mainDeck' | 'heaven' | 'hell') ||
          !definition || definition.kind !== 'monster' || definition.deck === 'extra' &&
          (!card.properlySummoned || !['heaven', 'hell'].includes(card.location.zone))) continue;
        const zone = step.to === 'normalOrFrontline'
          ? next.players[link.player].zones.normal.includes(null) ? 'normal' : 'frontline' : step.to;
        if (definition.deck === 'main' && zone !== 'normal') continue;
        const slot = next.players[link.player].zones[zone].indexOf(null);
        if (slot < 0) break;
        const moved = moveCard(next, { cardId, actor: link.player, reason: 'effect', catalog,
          destination: { player: link.player, zone, slot }, allowExtraMonsterNormal: definition.deck === 'extra' && zone === 'normal' });
        if (moved.status !== 'moved') continue;
        next = observeMove(moved.state, moved.events);
        events.push(...moved.events);
        if (step.effectsDisabledUntilTurn) next = { ...next, cards: { ...next.cards,
          [cardId]: { ...next.cards[cardId]!, effectsDisabledUntilTurn: next.globalTurn } } };
        recordRuleOperation('special_summon', cardId, 'public');
        const summoned: import('../model/event.js').MonsterSummonedEvent = { type: 'monsterSummoned',
          sequence: next.eventSequence + 1, player: link.player, cardId,
          method: card.location.zone === 'mainDeck' ? 'effectMain' : 'revival', identityVisibility: 'public' };
        next = observeMove({ ...next, eventSequence: summoned.sequence }, [summoned]);
        events.push(summoned);
        stepSucceeded = true;
      }
      if (step.successKey) successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'sendResponseSourceToHeaven') {
      const snapshot = link.responseSourceSnapshot;
      const target = snapshot && next.cards[snapshot.id];
      const valid = target && snapshot && target.location.player === snapshot.player && target.location.zone === snapshot.zone &&
        target.zoneEntrySequence === snapshot.zoneEntrySequence && catalog.cards[target.cardId]?.kind === 'monster';
      const operation = executeKeywordOperation(next, link, effect.id, { keywordId: 'send_to_heaven', key: 'responseSource' },
        valid ? [{ cardId: target.id }] : [], catalog, (movedState) => movedState,
        (current, targetId, currentCatalog, sourcePlayer) => isProtectedFromMonsterEffectDestruction(current, targetId, currentCatalog, sourcePlayer),
        (current, targetId, stat, currentCatalog) => stat === 'directAttackDamage'
          ? getCurrentDirectAttackDamage(current, targetId, currentCatalog) : getCurrentMonsterStat(current, targetId, stat, currentCatalog));
      next = observe ? observe(operation.state, operation.events) : operation.state;
      events.push(...operation.events);
      stepSucceeded = operation.applied;
    } else if (step.kind === 'negateMonsterUntilLeaves') {
      for (const { cardId } of context[step.key] ?? []) {
        const card = next.cards[cardId];
        if (!card || !['normal', 'frontline'].includes(card.location.zone) || card.face !== 'up' ||
          catalog.cards[card.cardId]?.kind !== 'monster') continue;
        if (!card.flags.includes('effectsNegated')) next = { ...next, cards: { ...next.cards,
          [cardId]: { ...card, flags: [...card.flags, 'effectsNegated'] } } };
        stepSucceeded = true;
      }
    } else if (step.kind === 'negatePendingAttack') {
      if (next.pendingBattle && next.pendingBattle.player !== link.player &&
        (!step.requiresSuccessKey || successes[step.requiresSuccessKey]) &&
        next.pendingBattle.stage === 'attackDeclaration') {
        next = { ...next, pendingBattle: { ...next.pendingBattle, attackNegated: true } };
        stepSucceeded = true;
      }
    } else if (step.kind === 'protectSelectedFromOpponentMonsterEffectDestruction') {
      for (const { cardId } of context[step.key] ?? []) {
        const target = next.cards[cardId];
        if (!target || !['normal', 'frontline'].includes(target.location.zone) || target.controller !== link.player) continue;
        next = { ...next, cards: { ...next.cards, [cardId]: {
          ...target, protectedFromOpponentMonsterEffectUntilTurn: next.globalTurn,
        } } };
        stepSucceeded = true;
      }
    } else if (step.kind === 'summonSelf') {
      const source = next.cards[sourceId];
      const sourceDefinition = source && Object.hasOwn(catalog.cards, source.cardId) ? catalog.cards[source.cardId] : undefined;
      const sourceZones = typeof step.from === 'string' ? [step.from] : step.from;
      const canSummon = source && sourceZones.includes(source.location.zone) && source.owner === link.player &&
        !(sourceDefinition?.noOtherEffectSummonFromHand && source.location.zone === 'hand' &&
          !sourceDefinition.effectIds?.includes(effect.id)) &&
        (!step.requiresFaceUpCardId || [...next.players[link.player].zones.normal, ...next.players[link.player].zones.frontline,
          ...next.players[link.player].zones.spellCounter].some((id) => id && next.cards[id]?.cardId === step.requiresFaceUpCardId &&
            next.cards[id]?.face === 'up' && !next.cards[id]?.flags.includes('effectsNegated')));
      const slot = canSummon ? next.players[link.player].zones[step.to].indexOf(null) : -1;
      if (source && slot >= 0) {
        const moved = moveCard(next, { cardId: sourceId, actor: link.player, reason: 'effect', catalog,
          destination: { player: link.player, zone: step.to, slot } });
        if (moved.status === 'moved') {
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          const summoned = next.cards[sourceId]!;
          next = { ...next, cards: { ...next.cards, [sourceId]: { ...summoned,
            flags: step.effectsNegated && !summoned.flags.includes('effectsNegated')
              ? [...summoned.flags, 'effectsNegated'] : summoned.flags,
            ...(step.leaveFieldReplacement ? { leaveFieldReplacement: {
              id: `leaveField:${sourceId}:${link.id}`, destination: 'ownerMainDeck' as const,
            } } : {}),
          } } };
          const event: import('../model/event.js').MonsterSummonedEvent = {
            type: 'monsterSummoned', sequence: next.eventSequence + 2, player: link.player, cardId: sourceId,
            method: sourceZones.includes('hand') && source.location.zone === 'hand' ? 'effectMain' : 'revival', identityVisibility: 'public',
          };
          recordRuleOperation('special_summon', sourceId, 'public');
          next = observeMove({ ...next, eventSequence: event.sequence }, [event]);
          events.push(event);
          stepSucceeded = true;
        }
      }
      successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'moveSelected' || step.kind === 'destroySelected' || step.kind === 'releaseSelected') {
      const selections: readonly ResolutionSelection[] = context[step.key] ?? [];
      const successfullyMoved: ResolutionSelection[] = [];
      if (!('requiresSuccessKey' in step) || !step.requiresSuccessKey || successes[step.requiresSuccessKey]) {
        for (const selection of selections) {
          const target: CardInstance | undefined = next.cards[selection.cardId];
          if (!target) continue;
          if (step.kind === 'destroySelected' && isOpponentMonsterEffect(next, link, catalog, target.id)) {
            const replacement = replacementFor(next, target.id, link.player, catalog);
            const replacementKey = `destroyReplacement:${effect.id}:${target.id}`;
            if (replacement && !Object.hasOwn(context, replacementKey)) {
              return { state: next, events, applied, choice: {
                stepIndex: index, context, successes, key: replacementKey,
                candidates: next.players[replacement.player].zones.heaven.filter((id): id is CardInstanceId =>
                  id !== null && (catalog.cards[next.cards[id]!.cardId]?.archetypeIds?.includes(replacement.archetypeId) ?? false)),
                filter: { zones: ['heaven'], side: 'self', archetypeId: replacement.archetypeId }, minimum: 0, maximum: 1,
                applied, player: replacement.player, resumeCurrentStep: true,
              } };
            }
            const replacementPayment = replacement && context[replacementKey]?.[0]?.cardId;
            if (replacementPayment) {
              const resource = next.cards[replacementPayment];
              if (resource && resource.location.zone === 'heaven' && resource.owner === replacement!.player &&
                resource.location.player === replacement!.player &&
                catalog.cards[resource.cardId]?.archetypeIds?.includes(replacement!.archetypeId)) {
                const moved = moveCard(next, { cardId: resource.id, actor: replacement!.player, reason: 'send', catalog,
                  destination: { player: replacement!.player, zone: 'hell' } });
                if (moved.status === 'moved' && moved.state.cards[resource.id]?.location.zone === 'hell') {
                  next = observeMove(moved.state, moved.events);
                  events.push(...moved.events);
                  next = { ...next, destructionReplacementUsed: { ...next.destructionReplacementUsed,
                    [replacement!.player]: next.globalTurn } };
                  stepSucceeded = true;
                  continue;
                }
              }
            }
            if (replacement && Object.hasOwn(context, replacementKey) && !replacementPayment) {
              next = { ...next, destructionReplacementUsed: { ...next.destructionReplacementUsed,
                [replacement.player]: next.globalTurn } };
            }
          }
          if (step.kind === 'destroySelected' && target.protectedFromOpponentMonsterEffectUntilTurn !== undefined &&
            target.protectedFromOpponentMonsterEffectUntilTurn >= next.globalTurn && target.controller !== link.player &&
            isOpponentMonsterEffect(next, link, catalog, target.id)) continue;
          if (step.kind === 'destroySelected' && target.flags.includes(`protectedFromEffect:${link.id}`)) continue;
          if (step.kind === 'destroySelected' && link.source.kind === 'card') {
            const source = next.cards[sourceId];
            const definition = source && Object.hasOwn(catalog.cards, source.cardId) ? catalog.cards[source.cardId] : undefined;
            if (definition?.kind === 'monster' && isProtectedFromMonsterEffectDestruction(next, target.id, catalog, link.player)) continue;
          }
          if (step.kind === 'destroySelected' && link.source.kind === 'card') {
            const protectedState = consumeEffectDestructionProtection(next, target.id, link.player, catalog);
            if (protectedState) { next = protectedState; continue; }
          }
          const requestedTo = step.kind === 'destroySelected' ? 'hell'
            : step.kind === 'releaseSelected' ? 'heaven' : selection.destination ?? step.to;
          const to = requestedTo === 'handOrExtraDeck'
            ? catalog.cards[target.cardId]?.deck === 'extra' ? 'extraDeck' : 'hand' : requestedTo;
          const reason = step.kind === 'destroySelected' ? 'destroy' : step.kind === 'releaseSelected' ? 'release' : step.reason;
          const visible = target.location.zone === 'heaven' || target.location.zone === 'hell' ||
            ['normal', 'frontline', 'spellCounter'].includes(target.location.zone) && target.face === 'up'
            ? 'public' as const : target.location.player;
          if (step.kind === 'moveSelected' && target.location.zone === 'mainDeck' && to === 'hand') {
            recordRuleOperation('search', target.id, visible);
          }
          const spellSlot = to === 'spellCounter' ? next.players[link.player].zones.spellCounter.indexOf(null) : -1;
          if (to === 'spellCounter' && spellSlot < 0) continue;
          const moved = moveCard(next, { cardId: target.id, actor: link.player, reason, catalog,
            ...(to === 'hand' || to === 'extraDeck' || to === 'heaven' || to === 'hell' ? {
              destination: { player: to === 'hand' && !('ownerDestination' in step && step.ownerDestination) ? link.player : target.owner, zone: to },
            } : { destination: { player: link.player, zone: 'spellCounter', slot: spellSlot }, face: 'down' as const }) });
          if (moved.status !== 'moved') continue;
          const reachedRequestedZone = moved.state.cards[target.id]?.location.zone === to;
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          stepSucceeded ||= step.kind === 'releaseSelected' || reachedRequestedZone;
          if (step.kind !== 'moveSelected' || reachedRequestedZone) successfullyMoved.push(selection);
        }
      }
      if (step.kind === 'moveSelected') {
        context[step.key] = successfullyMoved;
        if (successfullyMoved.length > 0 && step.shuffleAfter) {
          const shuffled = shuffle(next.players[link.player].zones.mainDeck, next.rng);
          next = { ...next, rng: shuffled.rng, players: { ...next.players,
            [link.player]: { ...next.players[link.player], zones: { ...next.players[link.player].zones, mainDeck: shuffled.items } },
          } };
        }
      }
      if ('successKey' in step && step.successKey) successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'modifyLevel') {
      const targets = step.target === 'source' ? [{ cardId: sourceId }] : context[step.key ?? ''] ?? [];
      const amount = step.amount + (step.amountPerSelected ?? 0) * (step.key ? context[step.key]?.length ?? 0 : targets.length);
      for (const target of targets) next = addLevelModifier(next, target.cardId, amount, next.globalTurn,
        `level:${link.id}:${index}:${target.cardId}`);
      stepSucceeded = targets.length > 0 && amount !== 0;
      if (step.successKey) successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'modifyAttack') {
      const source = next.cards[sourceId];
      const definition = source && Object.hasOwn(catalog.cards, source.cardId) ? catalog.cards[source.cardId] : undefined;
      if (source && definition) {
        const count = step.amountPerOwnHellCard
          ? next.players[source.controller].zones.hell.filter((id) => id &&
            catalog.cards[next.cards[id]!.cardId]?.archetypeIds?.includes(step.amountPerOwnHellCard!.archetypeId)).length
          : 1;
        const amount = step.amount * count;
        if (amount !== 0) next = { ...next, cards: { ...next.cards, [sourceId]: { ...source,
          modifiers: [...source.modifiers, { id: `atk:${link.id}:${index}`, atk: amount, expiresAtTurn: next.globalTurn }],
        } } };
        stepSucceeded = true;
      }
      if (step.successKey) successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'modifyStats') {
      const selections = step.target === 'source' ? [{ cardId: sourceId }] : context[step.key ?? ''] ?? [];
      for (const selection of selections) {
        const card = next.cards[selection.cardId];
        if (!card || (card.location.zone !== 'normal' && card.location.zone !== 'frontline')) continue;
        const def = catalog.cards[card.cardId];
        const modifiers = { id: `stats:${link.id}:${index}:${selection.cardId}`,
          ...(step.atk === undefined || def?.atk === undefined ? {} : { atk: step.atk }),
          ...(step.def === undefined || def?.def === undefined ? {} : { def: step.def }),
          expiresAtTurn: next.globalTurn + (step.duration === 'opponentTurnEnd' ? 1 : 0),
        };
        if (modifiers.atk !== undefined || modifiers.def !== undefined) {
          next = { ...next, cards: { ...next.cards, [card.id]: { ...card,
            modifiers: [...card.modifiers, modifiers] } } };
          stepSucceeded = true;
        }
      }
      if (step.successKey) successes[step.successKey] = stepSucceeded;
    } else if (step.kind === 'drawCards') {
      for (let draw = 0; draw < step.count; draw++) {
        const top = next.players[link.player].zones.mainDeck[0];
        if (!top) {
          const ended: import('../model/event.js').GameEndedEvent = { type: 'gameEnded', sequence: next.eventSequence + 1,
            winner: otherPlayer(link.player), reason: 'emptyDraw' };
          next = { ...next, result: { winner: ended.winner, reason: ended.reason }, eventSequence: ended.sequence };
          events.push(ended);
          break;
        }
        const moved = moveCard(next, { cardId: top, actor: link.player, reason: 'draw', catalog,
          destination: { player: link.player, zone: 'hand' } });
        if (moved.status !== 'moved') continue;
        next = observeMove(moved.state, moved.events);
        events.push(...moved.events);
        stepSucceeded = true;
      }
    } else if (step.kind === 'reorderMainDeck') {
      const selected = context[step.key] ?? [];
      const selectedIds = selected.map((item) => item.cardId);
      const deck = next.players[link.player].zones.mainDeck;
      const selectedSet = new Set(selectedIds);
      if (selectedIds.length === step.count && step.topCount <= step.count &&
        selectedIds.every((id) => deck.includes(id))) {
        const rest = deck.filter((id) => !selectedSet.has(id));
        const top = selectedIds.slice(0, step.topCount);
        const bottom = selectedIds.slice(step.topCount);
        next = { ...next, players: { ...next.players, [link.player]: { ...next.players[link.player],
          zones: { ...next.players[link.player].zones, mainDeck: [...top, ...rest, ...bottom] } } } };
        stepSucceeded = true;
      }
    } else if (step.kind === 'shuffleDeck') {
      const shuffled = shuffle(next.players[link.player].zones.mainDeck, next.rng);
      next = { ...next, rng: shuffled.rng, players: { ...next.players,
        [link.player]: { ...next.players[link.player], zones: { ...next.players[link.player].zones, mainDeck: shuffled.items } },
      } };
      stepSucceeded = true;
    } else if (step.kind === 'keyword') {
      const operation = executeKeywordOperation(next, link, effect.id, step.operation,
        context[step.operation.key] ?? [], catalog, (movedState) => movedState,
        (current, targetId, currentCatalog, sourcePlayer) =>
          isProtectedFromMonsterEffectDestruction(current, targetId, currentCatalog, sourcePlayer),
        (current, targetId, stat, currentCatalog) => stat === 'directAttackDamage'
          ? getCurrentDirectAttackDamage(current, targetId, currentCatalog)
          : getCurrentMonsterStat(current, targetId, stat, currentCatalog));
      next = observe ? observe(operation.state, operation.events) : operation.state;
      events.push(...operation.events);
      stepSucceeded = operation.applied;
    }
    applied ||= stepSucceeded;
  }
  return { state: next, events, applied };
}

/** Named handlers only. Definitions are data; they never execute user-supplied code. */
export function applyNamedEffect(state: GameState, link: ChainLink, effect: EffectDefinition, catalog: CardCatalog,
  observe?: SummonEventObserver, resume?: { readonly stepIndex: number;
    readonly context: Readonly<Record<string, readonly ResolutionSelection[]>>;
    readonly successes: Readonly<Record<string, boolean>>; readonly applied?: boolean }): EffectApplication {
  switch (effect.handlerId) {
    case 'noop': return { state, events: [], applied: true };
    case 'activateContinuousSpell': return { state, events: [], applied: true };
    case 'continuousAtkBoost': {
      if (link.source.kind !== 'card') return { state, events: [], applied: false };
      const card = state.cards[link.source.instanceId];
      if (!card || card.location.zone !== 'spellCounter' || card.face !== 'up') return { state, events: [], applied: false };
      const flag = `continuousActive:${effect.id}`;
      return { state: { ...state, cards: { ...state.cards, [card.id]: {
        ...card, flags: card.flags.includes(flag) ? card.flags : [...card.flags, flag],
      } } }, events: [], applied: true };
    }
    case 'negateActivation': return { state, events: [], applied: true, negation: 'activation' };
    case 'negateEffect': return { state, events: [], applied: true, negation: 'effect' };
    case 'negateSummon': return { state, events: [], applied: true, negation: 'summon' };
    case 'negateAttack': {
      if (!state.pendingBattle || state.pendingBattle.player === link.player) return { state, events: [], applied: false };
      return { state: { ...state, pendingBattle: { ...state.pendingBattle, attackNegated: true } }, events: [], applied: true };
    }
    case 'protectTarget': {
      if (!link.responseTo) return { state, events: [], applied: false };
      let next = state;
      let applied = false;
      for (const id of validTargets(state, link, effect, catalog)) {
        const target = next.cards[id];
        if (!target) continue;
        const flag = `protectedFromEffect:${link.responseTo}`;
        next = { ...next, cards: { ...next.cards, [id]: { ...target,
          flags: target.flags.includes(flag) ? target.flags : [...target.flags, flag] } } };
        applied = true;
      }
      return { state: next, events: [], applied };
    }
    case 'armBattleReward': {
      if (!effect.battleReward || state.battleRewards?.[link.player]) return { state, events: [], applied: false };
      return { state: { ...state, battleRewards: { ...state.battleRewards,
        [link.player]: { kind: effect.battleReward, expiresAtTurn: state.globalTurn } } }, events: [], applied: true };
    }
    case 'placeFieldMark': {
      const slot = link.fieldMarkSlot;
      if (!effect.fieldMark || slot === undefined || state.players[link.player].zones.normal[slot] !== null ||
        state.fieldMarks?.[link.player]?.[slot]) return { state, events: [], applied: false };
      return { state: { ...state, fieldMarks: { ...state.fieldMarks,
        [link.player]: { ...state.fieldMarks?.[link.player], [slot]: { kind: effect.fieldMark.stat === 'atk' ? 'attack' : 'defense',
          amount: effect.fieldMark.amount } } } }, events: [], applied: true };
    }
    case 'sendTargetsToHeaven':
    case 'destroyTargets': {
      let next = state;
      const events: GameEvent[] = [];
      const context = resume?.context ?? {};
      for (const id of validTargets(next, link, effect, catalog)) {
        const target = next.cards[id];
        if (!target) continue;
        if (effect.handlerId === 'destroyTargets' && target.flags.includes(`protectedFromEffect:${link.id}`)) continue;
        if (effect.handlerId === 'destroyTargets' && isOpponentMonsterEffect(next, link, catalog, id)) {
          const replacement = replacementFor(next, id, link.player, catalog);
          const replacementKey = `destroyReplacement:${effect.id}:${id}`;
          if (replacement && !Object.hasOwn(context, replacementKey)) return { state: next, events, applied: false, choice: {
            stepIndex: 0, context, successes: resume?.successes ?? {}, key: replacementKey,
            candidates: next.players[replacement.player].zones.heaven.filter((resourceId): resourceId is CardInstanceId =>
              resourceId !== null && (catalog.cards[next.cards[resourceId]!.cardId]?.archetypeIds?.includes(replacement.archetypeId) ?? false)),
            filter: { zones: ['heaven'], side: 'self', archetypeId: replacement.archetypeId }, minimum: 0, maximum: 1,
            applied: resume?.applied ?? false, player: replacement.player, resumeCurrentStep: true,
          } };
          const payment = replacement && context[replacementKey]?.[0]?.cardId;
          if (payment) {
            const resource = next.cards[payment];
            if (resource && resource.location.zone === 'heaven' && resource.owner === replacement!.player &&
              resource.location.player === replacement!.player &&
              catalog.cards[resource.cardId]?.archetypeIds?.includes(replacement!.archetypeId)) {
              const paid = moveCard(next, { cardId: resource.id, actor: replacement!.player, reason: 'send', catalog,
                destination: { player: replacement!.player, zone: 'hell' } });
              if (paid.status === 'moved' && paid.state.cards[resource.id]?.location.zone === 'hell') {
                next = observe ? observe(paid.state, paid.events) : paid.state;
                events.push(...paid.events);
                next = { ...next, destructionReplacementUsed: { ...next.destructionReplacementUsed,
                  [replacement!.player]: next.globalTurn } };
                continue;
              }
            }
          }
          if (replacement && Object.hasOwn(context, replacementKey) && !payment) {
            next = { ...next, destructionReplacementUsed: { ...next.destructionReplacementUsed,
              [replacement.player]: next.globalTurn } };
          }
          if (target.protectedFromOpponentMonsterEffectUntilTurn !== undefined &&
            target.protectedFromOpponentMonsterEffectUntilTurn >= next.globalTurn) continue;
        }
        if (effect.handlerId === 'destroyTargets' && isOpponentMonsterEffect(next, link, catalog, id) &&
          isProtectedFromMonsterEffectDestruction(next, id, catalog, link.player)) continue;
        if (effect.handlerId === 'destroyTargets' && link.source.kind === 'card') {
          const protectedState = consumeEffectDestructionProtection(next, id, link.player, catalog);
          if (protectedState) { next = protectedState; continue; }
        }
        const moved = moveCard(next, { cardId: id, actor: link.player,
          reason: effect.handlerId === 'destroyTargets' ? 'destroy' : 'send', catalog });
        if (moved.status !== 'moved') continue;
        next = observe ? observe(moved.state, moved.events) : moved.state;
        events.push(...moved.events);
      }
      return { state: next, events, applied: events.length > 0 };
    }
    case 'effectSummonTerminal': {
      if (!link.terminalId || !link.materialIds) return { state, events: [], applied: false };
      const authorizedMaterialIds = deriveAuthorizedMaterials(state, link.player, link.materialIds, effect);
      if (!authorizedMaterialIds) return { state, events: [], applied: false };
      const result = completeEffectSummon(state, { player: link.player, terminalId: link.terminalId,
        materialIds: link.materialIds, authorizedMaterialIds, zone: link.terminalZone, slot: link.terminalSlot }, catalog, observe);
      return result.status === 'summoned'
        ? { state: result.state, events: result.events, applied: true }
        : { state, events: [], applied: false };
    }
    case 'executeProgram': return runProgram(state, link, effect, catalog, observe, resume);
  }
}

/** Query current active sources rather than changing the printed card stat. */
export function getContinuousAtkBonus(state: GameState, player: PlayerId, catalog: CardCatalog): number {
  if (catalog.version !== state.catalogVersion) return 0;
  let bonus = 0;
  for (const id of [...state.players[player].zones.normal, ...state.players[player].zones.frontline,
    ...state.players[player].zones.spellCounter]) {
    if (!id) continue;
    const card = state.cards[id];
    if (!card || card.face !== 'up' || card.controller !== player || card.location.player !== player ||
      card.flags.includes('effectsNegated')) continue;
    const source = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
    if (!source || source.id !== card.cardId) continue;
    for (const effectId of source.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      if (effect?.handlerId === 'continuousAtkBoost' && effect.allowedZones.includes(card.location.zone) &&
        (effect.mode === 'continuous' || card.flags.includes(`continuousActive:${effect.id}`))) {
        bonus += effect.value ?? 0;
      }
    }
  }
  return bonus;
}

export function getContinuousStatBonus(state: GameState, cardId: CardInstanceId,
  stat: 'atk' | 'def' | 'directAttackDamage', catalog: CardCatalog, excludeBattleConditional = false): number {
  if (catalog.version !== state.catalogVersion) return 0;
  const target = state.cards[cardId];
  const targetDefinition = target && Object.hasOwn(catalog.cards, target.cardId) ? catalog.cards[target.cardId] : undefined;
  if (!target || !targetDefinition || !['normal', 'frontline'].includes(target.location.zone)) return 0;
  if ((stat === 'atk' || stat === 'def') && targetDefinition[stat] === undefined) return 0;
  let bonus = 0;
  const ownSources = [...state.players[target.controller].zones.normal, ...state.players[target.controller].zones.frontline,
    ...state.players[target.controller].zones.spellCounter];
  const opponentSources = [...state.players[otherPlayer(target.controller)].zones.normal,
    ...state.players[otherPlayer(target.controller)].zones.frontline, ...state.players[otherPlayer(target.controller)].zones.spellCounter];
  for (const sourceId of [...ownSources, ...opponentSources]) {
    if (!sourceId) continue;
    const source = state.cards[sourceId];
    const sourceDefinition = source && Object.hasOwn(catalog.cards, source.cardId) ? catalog.cards[source.cardId] : undefined;
    if (!source || !sourceDefinition || source.face !== 'up' ||
      source.flags.includes('effectsNegated')) continue;
    for (const effectId of sourceDefinition.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      const stats = effect?.continuousStats;
      const targetPlayer = stats?.targetSide === 'opponent' ? otherPlayer(source.controller) : source.controller;
      if (effect?.mode !== 'continuous' || !effect.allowedZones.includes(source.location.zone) || !stats ||
        target.controller !== targetPlayer ||
        stats.archetypeId !== undefined && !targetDefinition.archetypeIds?.includes(stats.archetypeId) ||
        stats.deck !== undefined && stats.deck !== targetDefinition.deck ||
        stats.selfOnly && source.id !== target.id || stats.excludeSource && source.id === target.id ||
        stats.requiresOtherFriendlyMonster && !state.players[target.controller].zones.normal.concat(state.players[target.controller].zones.frontline)
          .some((id) => id !== source.id && id !== null && state.cards[id]?.face === 'up') ||
        stats.requiresOpponentMoreMonsters && (state.players[otherPlayer(target.controller)].zones.normal.concat(state.players[otherPlayer(target.controller)].zones.frontline)
          .filter((id) => id !== null).length <= state.players[target.controller].zones.normal.concat(state.players[target.controller].zones.frontline)
          .filter((id) => id !== null).length)) continue;
      let amount = stats[stat] ?? 0;
      if (stats.scaleByArchetypeFieldCount) {
        const count = [...state.players[source.controller].zones.normal, ...state.players[source.controller].zones.frontline,
          ...state.players[source.controller].zones.spellCounter].filter((id) => id !== null &&
            state.cards[id]?.face === 'up' && state.cards[id]?.controller === source.controller &&
            catalog.cards[state.cards[id]!.cardId]?.archetypeIds?.includes(stats.scaleByArchetypeFieldCount!.archetypeId)).length;
        amount += stats.scaleByArchetypeFieldCount.amountPerCard * count;
      }
      if (stats.scaleByHeavenMonsters) {
        const count = state.players[source.controller].zones.heaven.filter((id) => {
          const definition = id ? catalog.cards[state.cards[id]?.cardId ?? ''] : undefined;
          return definition?.kind === 'monster' && definition.archetypeIds?.includes(stats.scaleByHeavenMonsters!.archetypeId);
        }).length;
        amount += stats.scaleByHeavenMonsters.amountPerCard * count;
      }
      if (stat === 'atk' && !excludeBattleConditional && stats.battleAtkBonusWhenPrintedAtkBelowDef && state.pendingBattle?.attackerId === target.id &&
        state.pendingBattle.stage === 'damageCalculation' && state.pendingBattle.target.kind === 'monster') {
        const defender = state.cards[state.pendingBattle.target.cardId];
        const defenderDefinition = defender && catalog.cards[defender.cardId];
        const def = defender && defenderDefinition?.def !== undefined
          ? defenderDefinition.def + defender.modifiers.reduce((sum, modifier) => sum + (modifier.def ?? 0), 0) +
            getContinuousStatBonus(state, defender.id, 'def', catalog) : null;
        const printedAtk = targetDefinition.atk;
        const baseAtk = printedAtk === undefined ? null : printedAtk + target.modifiers.reduce((sum, modifier) => sum + (modifier.atk ?? 0), 0) +
          getContinuousAtkBonus(state, target.controller, catalog) + getContinuousStatBonus(state, target.id, 'atk', catalog, true);
        if (def !== null && baseAtk !== null && def > baseAtk) amount += stats.battleAtkBonusWhenPrintedAtkBelowDef;
      }
      bonus += amount;
    }
  }
  return bonus;
}

/** Unified current ATK/DEF calculation. Weaken applies after printed, temporary, and continuous modifiers. */
export function getCurrentMonsterStat(state: GameState, cardId: CardInstanceId, stat: 'atk' | 'def',
  catalog: CardCatalog, includeBattleModifier = false): number | undefined {
  const card = state.cards[cardId];
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId || definition[stat] === undefined) return undefined;
  const onField = card.location.zone === 'normal' || card.location.zone === 'frontline';
  const amount = definition[stat]! + card.modifiers.reduce((sum, modifier) => sum + (modifier[stat] ?? 0), 0) +
    (onField ? getContinuousStatBonus(state, card.id, stat, catalog) + getContinuousAtkBonus(state, card.controller, catalog) : 0) +
    (includeBattleModifier && stat === 'atk' ? getContinuousBattleAtkModifier(state, card.id, catalog) : 0);
  return isKeywordStatusActive(state, card.id, 'weaken') ? 0 : Math.max(0, amount);
}

export function getCurrentDirectAttackDamage(state: GameState, cardId: CardInstanceId, catalog: CardCatalog): number | undefined {
  const card = state.cards[cardId];
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || definition?.directAttackDamage === undefined) return undefined;
  const onField = card.location.zone === 'normal' || card.location.zone === 'frontline';
  return Math.max(0, definition.directAttackDamage + card.modifiers.reduce((sum, modifier) => sum + (modifier.atk ?? 0), 0) +
    (onField ? getContinuousStatBonus(state, card.id, 'directAttackDamage', catalog) + getContinuousAtkBonus(state, card.controller, catalog) : 0));
}

export function getBattleDamageReduction(state: GameState, defendingPlayer: PlayerId, defenderId: CardInstanceId,
  catalog: CardCatalog): number {
  let reduction = 0;
  for (const sourceId of [...state.players[defendingPlayer].zones.normal, ...state.players[defendingPlayer].zones.frontline]) {
    if (!sourceId || sourceId === defenderId) continue;
    const source = state.cards[sourceId];
    if (!source || source.face !== 'up' || source.controller !== defendingPlayer || source.flags.includes('effectsNegated')) continue;
    const definition = catalog.cards[source.cardId];
    for (const effectId of definition?.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      if (effect?.mode === 'continuous' && effect.allowedZones.includes(source.location.zone)) {
        reduction += effect.continuousDamageReduction ?? 0;
      }
    }
  }
  return reduction;
}

export function getContinuousBattleAtkModifier(state: GameState, attackerId: CardInstanceId,
  catalog: CardCatalog): number {
  const battle = state.pendingBattle;
  if (!battle || battle.attackerId !== attackerId || battle.target.kind !== 'monster') return 0;
  const attacker = state.cards[attackerId];
  const defender = state.cards[battle.target.cardId];
  if (!attacker || !defender || defender.controller === attacker.controller) return 0;
  let amount = 0;
  for (const owner of ['p1', 'p2'] as const) for (const sourceId of [...state.players[owner].zones.normal,
    ...state.players[owner].zones.frontline, ...state.players[owner].zones.spellCounter]) {
    if (!sourceId) continue;
    const source = state.cards[sourceId];
    if (!source || source.face !== 'up' || source.controller !== defender.controller || source.flags.includes('effectsNegated')) continue;
    const definition = catalog.cards[source.cardId];
    for (const effectId of definition?.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      if (effect?.mode === 'continuous' && effect.allowedZones.includes(source.location.zone) &&
        effect.continuousBattleAtkModifier?.whenOpponentAttacksFriendlyMonster) {
        amount += effect.continuousBattleAtkModifier.amount;
      }
    }
  }
  return amount;
}

export function logicalColumn(state: GameState, cardId: CardInstanceId): 0 | 1 | 2 | null {
  const location = state.cards[cardId]?.location;
  if (!location || !Number.isInteger(location.slot)) return null;
  if (location.zone === 'normal' || location.zone === 'spellCounter') {
    return location.slot === 0 ? 0 : location.slot === 1 ? 1 : location.slot === 2 ? 2 : null;
  }
  if (location.zone === 'frontline') return location.slot === 0 ? 0 : location.slot === 1 ? 2 : null;
  return null;
}

export function isProtectedFromMonsterEffectDestruction(state: GameState, cardId: CardInstanceId,
  catalog: CardCatalog, sourcePlayer?: PlayerId): boolean {
  const target = state.cards[cardId];
  if (!target || !['normal', 'frontline', 'spellCounter'].includes(target.location.zone)) return false;
  if (sourcePlayer !== undefined && sourcePlayer !== target.controller &&
    target.protectedFromOpponentMonsterEffectUntilTurn !== undefined &&
    target.protectedFromOpponentMonsterEffectUntilTurn >= state.globalTurn) return true;
  const column = logicalColumn(state, cardId);
  for (const sourceId of [...state.players[target.controller].zones.normal, ...state.players[target.controller].zones.frontline,
    ...state.players[target.controller].zones.spellCounter]) {
    if (!sourceId) continue;
    const source = state.cards[sourceId];
    const definition = source && Object.hasOwn(catalog.cards, source.cardId) ? catalog.cards[source.cardId] : undefined;
    if (!source || !definition || source.face !== 'up' || source.controller !== target.controller ||
      source.flags.includes('effectsNegated')) continue;
    for (const effectId of definition.effectIds ?? []) {
      const effect = effectFromCatalog(catalog, effectId);
      const protection = effect?.continuousProtection;
      if (!effect || !protection || !effect.allowedZones.includes(source.location.zone)) continue;
      if (protection.self && source.cardId === protection.cardId && source.id === cardId) return true;
      if (!protection.sameColumnFriendlyCards || column === null || logicalColumn(state, sourceId) !== column) continue;
      if (protection.requiresFaceUpCardId && ![...state.players[target.controller].zones.normal,
        ...state.players[target.controller].zones.frontline, ...state.players[target.controller].zones.spellCounter]
        .some((id) => id && state.cards[id]?.cardId === protection.requiresFaceUpCardId && state.cards[id]?.face === 'up' &&
          !state.cards[id]?.flags.includes('effectsNegated'))) continue;
      return true;
    }
  }
  return false;
}
