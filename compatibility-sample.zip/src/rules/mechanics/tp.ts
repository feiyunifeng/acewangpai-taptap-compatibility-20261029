import type { CardCatalog } from '../model/card.js';
import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { EffectDefinition } from '../model/effect.js';
import type { GameEvent } from '../model/event.js';
import type { GameState } from '../model/state.js';
import { moveCard, willCardReachZone } from '../engine/move-card.js';

/** TP allowance follows global player turns, not either player's own-turn count. */
export function tpAllowance(globalTurn: number): number {
  if (!Number.isInteger(globalTurn) || globalTurn < 1) throw new RangeError('globalTurn must be a positive integer');
  return Math.min(40, 15 + Math.floor((globalTurn - 1) / 2) * 5);
}

/** Rule summons pay the monster's printed level; level modifiers never change this cost. */
export function ruleSummonTpCost(level: number): number | null {
  return Number.isInteger(level) && level > 0 ? level : null;
}

export function payRuleSummonTp(state: GameState, player: PlayerId, cost: number):
  { readonly state: GameState; readonly events: readonly GameEvent[] } | null {
  if (!Number.isInteger(cost) || cost <= 0 || state.players[player].tp < cost) return null;
  const current = state.players[player];
  const event = { type: 'tpChanged' as const, sequence: state.eventSequence + 1,
    player, from: current.tp, to: current.tp - cost, reason: 'ruleSummonCost' as const };
  return { state: { ...state, eventSequence: event.sequence,
    players: { ...state.players, [player]: { ...current, tp: event.to } } }, events: [event] };
}

export interface EffectPaymentPlan {
  readonly tp: number;
  readonly life: number;
  readonly costCardId?: CardInstanceId;
  readonly resourceCardId?: CardInstanceId;
  readonly resourceDestination?: 'mainDeckBottom' | 'hell';
}

export function canSelectEffectCostCard(state: GameState, player: PlayerId, effect: EffectDefinition,
  cardId: CardInstanceId | undefined, catalog: CardCatalog): boolean {
  const cost = effect.cost;
  const card = cardId && Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  if (!cost || !card || ![cost.zone, ...(cost.alsoZones ?? [])].includes(card.location.zone) ||
    (card.location.zone === 'normal' || card.location.zone === 'frontline'
      ? card.controller !== player || card.location.player !== player
      : card.owner !== player || card.location.player !== player)) return false;
  if (cost.destination !== undefined && !willCardReachZone(state, card.id, cost.destination)) return false;
  if (cost.filter) {
    const definition = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
    if (!definition || definition.id !== card.cardId ||
      cost.filter.archetypeId !== undefined && !definition.archetypeIds?.includes(cost.filter.archetypeId) ||
      cost.filter.profession !== undefined && definition.profession !== cost.filter.profession) return false;
  }
  return true;
}

export function effectTpCost(level: number): number | null {
  return Number.isInteger(level) && level > 0 ? level : null;
}

export function effectLifeCost(effect: EffectDefinition, life: number): number | null {
  const cost = effect.lifeCost;
  if (!cost) return 0;
  if (cost.kind === 'fixed') {
    return Number.isInteger(cost.amount) && cost.amount > 0 && Number.isFinite(life) && life - cost.amount >= 1
      ? cost.amount : null;
  }
  if (!Number.isInteger(cost.numerator) || cost.numerator <= 0 ||
      !Number.isInteger(cost.denominator) || cost.denominator <= 0 ||
      !Number.isFinite(life) || life <= 0) return null;
  const amount = Math.ceil(life * cost.numerator / cost.denominator);
  return amount > 0 && life - amount >= 1 ? amount : null;
}

/** Validate every activation payment before any part of the command can mutate state. */
export function validateEffectPayment(state: GameState, player: PlayerId, effect: EffectDefinition,
  level: number | null, costCardId: CardInstanceId | undefined, resourceCostCardId: CardInstanceId | undefined,
  catalog: CardCatalog): EffectPaymentPlan | null {
  const tp = level === null ? 0 : effectTpCost(level);
  const life = effectLifeCost(effect, state.players[player].life);
  if (tp === null || life === null || state.players[player].tp < tp) return null;
  if (!!effect.cost !== !!costCardId || !!effect.resourceCost !== !!resourceCostCardId) return null;
  if (costCardId && costCardId === resourceCostCardId) return null;
  if (effect.cost && !canSelectEffectCostCard(state, player, effect, costCardId, catalog)) return null;
  if (effect.resourceCost) {
    const resource = resourceCostCardId ? state.cards[resourceCostCardId] : undefined;
    const definition = resource && catalog.cards[resource.cardId];
    if (!resource || resource.location.zone !== effect.resourceCost.zone ||
      resource.owner !== player || resource.location.player !== player ||
      effect.resourceCost.filter?.archetypeId !== undefined &&
      !definition?.archetypeIds?.includes(effect.resourceCost.filter.archetypeId)) return null;
  }
  return { tp, life, ...(costCardId ? { costCardId } : {}), ...(resourceCostCardId ? {
    resourceCardId: resourceCostCardId, resourceDestination: effect.resourceCost!.destination,
  } : {}) };
}

/** Apply a previously validated effect payment and emit deterministic public cost events. */
export function payEffectCosts(state: GameState, player: PlayerId, plan: EffectPaymentPlan,
  catalog: CardCatalog): { readonly state: GameState; readonly events: readonly GameEvent[] } | null {
  let next = state;
  const events: GameEvent[] = [];
  if (plan.resourceCardId) {
    const resource = next.cards[plan.resourceCardId]!;
    const destination = plan.resourceDestination === 'hell'
      ? { player: resource.owner, zone: 'hell' as const }
      : { player, zone: 'mainDeck' as const, position: 'bottom' as const };
    const moved = moveCard(next, { cardId: plan.resourceCardId, actor: player,
      reason: plan.resourceDestination === 'hell' ? 'send' : 'return', catalog, destination });
    if (moved.status !== 'moved') return null;
    next = moved.state;
    events.push(...moved.events);
  }
  const current = next.players[player];
  let paidPlayer = current;
  if (plan.tp > 0) {
    const tpEvent = { type: 'tpChanged' as const, sequence: next.eventSequence + 1,
      player, from: current.tp, to: current.tp - plan.tp, reason: 'effectCost' as const };
    next = { ...next, eventSequence: tpEvent.sequence };
    paidPlayer = { ...paidPlayer, tp: tpEvent.to };
    events.push(tpEvent);
  }
  if (plan.life > 0) paidPlayer = { ...paidPlayer, life: paidPlayer.life - plan.life };
  if (paidPlayer !== current) next = { ...next, players: { ...next.players, [player]: paidPlayer } };
  if (plan.life > 0) {
    const lifeEvent = { type: 'lifePaid' as const, sequence: next.eventSequence + 1,
      player, amount: plan.life, reason: 'effectCost' as const };
    next = { ...next, eventSequence: lifeEvent.sequence };
    events.push(lifeEvent);
  }
  return { state: next, events };
}
