import type { CardCatalog } from '../model/card.js';
import type { ChainLink } from '../model/chain.js';
import type { KeywordEvent, KeywordId, KeywordOperation, KeywordStatus } from '../model/keyword.js';
import { KEYWORD_REGISTRY } from '../model/keyword.js';
import type { GameEvent } from '../model/event.js';
import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { GameState, Zone } from '../model/state.js';
import type { PhaseChangedEvent } from '../model/event.js';
import type { ResolutionSelection } from '../model/effect.js';
import type { EffectDefinition } from '../model/effect.js';
import { moveCard } from '../engine/move-card.js';
import { resultForLifeTotals } from './victory.js';
import { consumeEffectDestructionProtection } from './effect-protection.js';

export interface KeywordOperationResult {
  readonly state: GameState;
  readonly events: readonly GameEvent[];
  readonly applied: boolean;
}

export function failNegatedKeywordOperations(state: GameState, link: ChainLink, effect: EffectDefinition,
  failure: 'activation-negated' | 'effect-negated'): KeywordOperationResult {
  let next = state;
  const events: GameEvent[] = [];
  for (const step of effect.program ?? []) {
    if (step.kind !== 'keyword') continue;
    next = appendEvent(next, events, event(next, link, effect.id, step.operation.keywordId, 'keyword_failed', { failure }));
  }
  return { state: next, events, applied: false };
}

type MoveObserver = (state: GameState, events: readonly GameEvent[]) => GameState;
type DestructionGuard = (state: GameState, cardId: CardInstanceId, catalog: CardCatalog,
  sourcePlayer: PlayerId) => boolean;
type StatReader = (state: GameState, cardId: CardInstanceId, stat: 'atk' | 'def' | 'directAttackDamage', catalog: CardCatalog) => number | undefined;

function event(state: GameState, link: ChainLink, effectId: string, keywordId: KeywordId,
  type: KeywordEvent['type'], details: Omit<KeywordEvent, 'type' | 'sequence' | 'keywordId' | 'linkId' | 'effectId' |
    'player' | 'sourceId' | 'sourceVisibility' | 'presentation'> = {}): KeywordEvent {
  return { type, sequence: state.eventSequence + 1, keywordId, linkId: link.id, effectId, player: link.player,
    ...(link.source.kind === 'card' ? { sourceId: link.source.instanceId } : {}),
    sourceVisibility: link.sourceVisibility, presentation: KEYWORD_REGISTRY[keywordId].presentation, ...details };
}

function appendEvent(state: GameState, events: GameEvent[], nextEvent: GameEvent): GameState {
  events.push(nextEvent);
  return { ...state, eventSequence: nextEvent.sequence };
}

function emptyTarget(state: GameState, link: ChainLink, effectId: string, keywordId: KeywordId,
  events: GameEvent[]): KeywordOperationResult {
  const failed = event(state, link, effectId, keywordId, 'keyword_failed', { failure: 'target-missing' });
  const next = appendEvent(state, events, failed);
  return { state: next, events, applied: false };
}

export function executeKeywordOperation(state: GameState, link: ChainLink, effectId: string,
  operation: KeywordOperation, selected: readonly ResolutionSelection[], catalog: CardCatalog,
  observeMove: MoveObserver, isProtectedFromDestruction: DestructionGuard, readStat: StatReader): KeywordOperationResult {
  let next = state;
  const events: GameEvent[] = [];
  const started = event(next, link, effectId, operation.keywordId, 'keyword_resolve_started');
  next = appendEvent(next, events, started);
  if (selected.length === 0) return emptyTarget(next, link, effectId, operation.keywordId, events);
  let anyApplied = false;

  for (let index = 0; index < selected.length; index++) {
    const targetId = selected[index]!.cardId;
    let target = next.cards[targetId];
    if (!target) {
      const failed = event(next, link, effectId, operation.keywordId, 'keyword_failed', { failure: 'target-missing' });
      next = appendEvent(next, events, failed);
      continue;
    }
    const targetVisibility = target.location.zone === 'heaven' || target.location.zone === 'hell' ||
      ['normal', 'frontline', 'spellCounter'].includes(target.location.zone) && target.face === 'up'
      ? 'public' as const : target.location.player;
    next = appendEvent(next, events, event(next, link, effectId, operation.keywordId, 'keyword_target_hit', {
      targetCardId: targetId, targetVisibility,
    }));
    target = next.cards[targetId]!;
    let success = false;
    let failure: KeywordEvent['failure'] = 'target-invalid';

    if (operation.keywordId === 'freeze' || operation.keywordId === 'weaken') {
      const duration = operation.durationTurns;
      if ((target.location.zone === 'normal' || target.location.zone === 'frontline') && target.face === 'up' &&
        (operation.keywordId === 'weaken' && operation.durationPhase === 'battleEnd' || Number.isInteger(duration) && duration! > 0)) {
        const statusId = `keyword:${link.id}:${index}:${targetId}`;
        const status: KeywordStatus = { id: statusId, keywordId: operation.keywordId, sourceLinkId: link.id,
          effectId, player: link.player, ...(link.source.kind === 'card' ? { sourceId: link.source.instanceId } : {}),
          sourceVisibility: link.sourceVisibility, targetVisibility, targetCardId: targetId,
          targetZoneEntrySequence: target.zoneEntrySequence, createdAtGlobalTurn: next.globalTurn,
          ...(operation.keywordId === 'weaken' && operation.durationPhase === 'battleEnd'
            ? { expiresAtPhase: 'battleEnd' as const }
            : { expiresAtGlobalTurn: next.globalTurn + duration! }) };
        next = { ...next, keywordStatuses: [...(next.keywordStatuses ?? []), status] };
        const created = event(next, link, effectId, operation.keywordId, 'keyword_status_created', {
          targetCardId: targetId, targetVisibility, statusId,
        });
        next = appendEvent(next, events, created);
        success = true;
      }
    } else if (operation.keywordId === 'burn') {
      const isMonster = catalog.cards[target.cardId]?.kind === 'monster';
      const protectedByEffect = target.flags.includes(`protectedFromEffect:${link.id}`) ||
        link.source.kind === 'card' && catalog.cards[link.source.instanceId] &&
          catalog.cards[link.source.instanceId]!.kind === 'monster' && isProtectedFromDestruction(next, targetId, catalog, link.player);
      if (isMonster && (target.location.zone === 'normal' || target.location.zone === 'frontline') &&
        Number.isInteger(operation.damage) && operation.damage > 0 && Number.isInteger(operation.ticks) && operation.ticks > 0 &&
        !protectedByEffect) {
        const protectedState = link.source.kind === 'card'
          ? consumeEffectDestructionProtection(next, targetId, link.player, catalog) : null;
        if (protectedState) {
          next = protectedState;
          failure = 'condition-not-met';
        } else {
        const affectedPlayer = target.controller;
        const moved = moveCard(next, { cardId: targetId, actor: link.player, reason: 'destroy', catalog,
          destination: { player: target.owner, zone: 'hell' } });
        if (moved.status === 'moved') {
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          const movedTarget = next.cards[targetId]!;
          next = appendEvent(next, events, event(next, link, effectId, 'burn', 'keyword_zone_moved', {
            targetCardId: targetId, targetVisibility, fromZone: target.location.zone, toZone: movedTarget.location.zone,
          }));
          if (moved.events.some((item) => item.type === 'cardMoved' && item.reason === 'destroy')) {
            const statusId = `keyword:${link.id}:${index}:${targetId}:burn`;
            const phaseTickAtEnd = operation.tickAt === 'turnEnd' && affectedPlayer === next.turnPlayer && next.phase !== 'end'
              ? next.globalTurn : next.globalTurn + (affectedPlayer === next.turnPlayer ? 2 : 1);
            const status: KeywordStatus = { id: statusId, keywordId: 'burn', sourceLinkId: link.id, effectId,
              ...(link.source.kind === 'card' ? { sourceId: link.source.instanceId } : {}), sourceVisibility: link.sourceVisibility,
              targetVisibility, player: affectedPlayer, damage: operation.damage, remainingTicks: operation.ticks,
              tickAt: operation.tickAt, nextTickGlobalTurn: phaseTickAtEnd };
            next = { ...next, keywordStatuses: [...(next.keywordStatuses ?? []), status] };
            next = appendEvent(next, events, event(next, link, effectId, 'burn', 'keyword_status_created', {
              targetCardId: targetId, targetVisibility, statusId, amount: operation.damage,
            }));
            success = true;
          } else failure = 'move-failed';
        } else failure = 'move-failed';
        }
      } else failure = protectedByEffect ? 'condition-not-met' : 'target-invalid';
    } else if (operation.keywordId === 'execute') {
      const inMonsterZone = target.location.zone === 'normal' || target.location.zone === 'frontline';
      const definition = catalog.cards[target.cardId];
      const isMage = definition?.profession === 'mage' || definition?.profession === '法师';
      const attackStat = isMage ? 'directAttackDamage' as const : 'atk' as const;
      const attack = readStat(next, targetId, attackStat, catalog);
      const defense = isMage ? undefined : readStat(next, targetId, 'def', catalog);
      if (inMonsterZone && Number.isInteger(operation.amount) && operation.amount > 0 && attack !== undefined &&
        (attack - operation.amount < 0 || defense !== undefined && defense - operation.amount < 0)) {
        const moved = moveCard(next, { cardId: targetId, actor: link.player, reason: 'send', catalog,
          destination: { player: target.owner, zone: 'hell' } });
        if (moved.status === 'moved' && moved.state.cards[targetId]!.location.zone === 'hell') {
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          next = appendEvent(next, events, event(next, link, effectId, 'execute', 'keyword_zone_moved', {
            targetCardId: targetId, targetVisibility, fromZone: target.location.zone, toZone: 'hell',
          }));
          success = true;
        } else failure = 'move-failed';
      } else if (inMonsterZone && Number.isInteger(operation.amount) && operation.amount > 0 && attack !== undefined &&
        (isMage || defense !== undefined)) {
        const current = next.cards[targetId]!;
        next = { ...next, cards: { ...next.cards, [targetId]: { ...current,
          modifiers: [...current.modifiers, { id: `execute:${link.id}:${index}`, atk: -operation.amount,
            ...(!isMage ? { def: -operation.amount } : {}) }],
        } } };
        next = appendEvent(next, events, event(next, link, effectId, 'execute', 'keyword_applied', {
          targetCardId: targetId, targetVisibility, amount: operation.amount,
        }));
        success = true;
      } else failure = 'condition-not-met';
    } else if (operation.keywordId === 'blast') {
      if ((['mainDeck', 'extraDeck', 'hand', 'normal', 'frontline', 'spellCounter', 'heaven', 'hell'] as const)
        .includes(target.location.zone) && (awaitActivatedThisTurn(next, targetId))) {
        const moved = moveCard(next, { cardId: targetId, actor: link.player, reason: 'send', catalog,
          destination: { player: target.owner, zone: 'hell' } });
        if (moved.status === 'moved' && moved.state.cards[targetId]!.location.zone === 'hell') {
          next = observeMove(moved.state, moved.events);
          events.push(...moved.events);
          next = appendEvent(next, events, event(next, link, effectId, 'blast', 'keyword_zone_moved', {
            targetCardId: targetId, targetVisibility, fromZone: target.location.zone, toZone: 'hell',
          }));
          success = true;
        } else failure = 'move-failed';
      } else failure = 'condition-not-met';
    } else {
      const definition = catalog.cards[target.cardId];
      const zone: Zone = operation.keywordId === 'send_to_heaven' ? 'heaven'
        : operation.keywordId === 'send_to_hell' ? 'hell'
          : operation.keywordId === 'return_to_hand' ? 'hand'
            : definition?.deck === 'extra' ? 'extraDeck' : 'mainDeck';
      const reason = operation.keywordId === 'return_to_hand' || operation.keywordId === 'return_to_deck' ? 'return' : 'send';
      const destination = operation.keywordId === 'return_to_deck' && operation.destination !== 'shuffle'
        ? { player: target.owner, zone, position: operation.destination === 'mainDeckTop' ? 'top' as const : 'bottom' as const }
        : { player: target.owner, zone };
      const moved = definition && moveCard(next, { cardId: targetId, actor: link.player, reason, catalog, destination,
        ...(operation.keywordId === 'return_to_deck' && operation.destination === 'shuffle' ? { shuffleDestination: true } : {}) });
      if (moved?.status === 'moved' && moved.state.cards[targetId]!.location.zone === zone) {
        next = observeMove(moved.state, moved.events);
        events.push(...moved.events);
        next = appendEvent(next, events, event(next, link, effectId, operation.keywordId, 'keyword_zone_moved', {
          targetCardId: targetId, targetVisibility, fromZone: target.location.zone, toZone: zone,
        }));
        success = true;
      } else failure = 'move-failed';
    }

    if (success) {
      anyApplied = true;
      next = appendEvent(next, events, event(next, link, effectId, operation.keywordId, 'keyword_applied', {
        targetCardId: targetId, targetVisibility,
        ...(operation.keywordId === 'execute' ? { amount: operation.amount } : {}),
      }));
    } else {
      next = appendEvent(next, events, event(next, link, effectId, operation.keywordId, 'keyword_failed', {
        targetCardId: targetId, targetVisibility, failure,
      }));
    }
  }
  return { state: next, events, applied: anyApplied };
}

function awaitActivatedThisTurn(state: GameState, cardId: CardInstanceId): boolean {
  return (['p1', 'p2'] as const).some((player) => state.counters[player].turn === state.globalTurn &&
    state.counters[player].activatedCardIds.includes(cardId));
}

function statusExpiredEvent(state: GameState, status: Exclude<KeywordStatus, { keywordId: 'burn' }>): KeywordEvent {
  const definition = KEYWORD_REGISTRY[status.keywordId];
  return { type: 'keyword_expired', sequence: state.eventSequence + 1, keywordId: status.keywordId,
    linkId: status.sourceLinkId, effectId: status.effectId, player: status.player,
    ...(status.sourceId ? { sourceId: status.sourceId } : {}), sourceVisibility: status.sourceVisibility,
    targetCardId: status.targetCardId, targetVisibility: status.targetVisibility, statusId: status.id,
    presentation: definition.presentation };
}

/** Runs deterministic keyword duration and burn hooks on phase transitions. */
export function processKeywordPhase(state: GameState, phaseEvent: PhaseChangedEvent): KeywordOperationResult {
  let next = state;
  const events: GameEvent[] = [];
  const statuses = [...(next.keywordStatuses ?? [])];
  const retained: KeywordStatus[] = [];
  for (const status of statuses) {
    if (status.keywordId !== 'burn') {
      const card = next.cards[status.targetCardId];
      const activeIdentity = card && card.zoneEntrySequence === status.targetZoneEntrySequence &&
        (card.location.zone === 'normal' || card.location.zone === 'frontline');
      if (activeIdentity && (status.expiresAtPhase === 'battleEnd' && phaseEvent.from === 'battle' && phaseEvent.to !== 'battle' ||
        status.expiresAtGlobalTurn !== undefined && phaseEvent.to === 'start' && state.globalTurn >= status.expiresAtGlobalTurn)) {
        const expired = statusExpiredEvent(next, status);
        next = appendEvent(next, events, expired);
      } else if (activeIdentity) retained.push(status);
      continue;
    }
    const phaseMatches = phaseEvent.to === (status.tickAt === 'turnStart' ? 'start' : 'end');
    const playerTurn = phaseMatches && (status.tickAt === 'turnStart' ? next.turnPlayer : phaseEvent.player) === status.player;
    if (!playerTurn || status.nextTickGlobalTurn > next.globalTurn || next.result !== null) {
      retained.push(status);
      continue;
    }
    const life = next.players[status.player].life - status.damage;
    const damageEvent: GameEvent = { type: 'lifeDamaged', sequence: next.eventSequence + 1,
      player: status.player, amount: status.damage, source: 'effect' };
    next = { ...next, players: { ...next.players, [status.player]: { ...next.players[status.player], life } } };
    next = appendEvent(next, events, damageEvent);
    const dealt: KeywordEvent = { type: 'keyword_damage_dealt', sequence: next.eventSequence + 1,
      keywordId: 'burn', linkId: status.sourceLinkId, effectId: status.effectId, player: status.player,
      ...(status.sourceId ? { sourceId: status.sourceId } : {}), sourceVisibility: status.sourceVisibility,
      targetVisibility: status.targetVisibility, statusId: status.id, amount: status.damage,
      presentation: KEYWORD_REGISTRY.burn.presentation };
    next = appendEvent(next, events, dealt);
    const remainingTicks = status.remainingTicks - 1;
    if (remainingTicks > 0) retained.push({ ...status, remainingTicks, nextTickGlobalTurn: next.globalTurn + 2 });
    else {
      const expired: KeywordEvent = { type: 'keyword_expired', sequence: next.eventSequence + 1,
        keywordId: 'burn', linkId: status.sourceLinkId, effectId: status.effectId, player: status.player,
        ...(status.sourceId ? { sourceId: status.sourceId } : {}), sourceVisibility: status.sourceVisibility,
        targetVisibility: status.targetVisibility, statusId: status.id, presentation: KEYWORD_REGISTRY.burn.presentation };
      next = appendEvent(next, events, expired);
    }
    const result = resultForLifeTotals({ p1: next.players.p1.life, p2: next.players.p2.life });
    if (result) {
      const ended: GameEvent = { type: 'gameEnded', sequence: next.eventSequence + 1,
        winner: result.winner, reason: result.reason };
      next = { ...next, result };
      next = appendEvent(next, events, ended);
    }
  }
  next = { ...next, keywordStatuses: retained };
  return { state: next, events, applied: events.length > 0 };
}
