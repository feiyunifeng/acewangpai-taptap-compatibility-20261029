/** JSON-safe fixed algorithm; the version is part of replay metadata. */
export interface RngState {
  readonly algorithm: 'lcg32-v1';
  readonly value: number;
  readonly draws: number;
}

export function createRng(seed: number): RngState {
  if (!Number.isInteger(seed) || seed < 0 || seed > 0xffff_ffff) {
    throw new RangeError('Seed must be an unsigned 32-bit integer');
  }
  return { algorithm: 'lcg32-v1', value: seed, draws: 0 };
}

export function nextRandom(rng: RngState): { value: number; rng: RngState } {
  if (rng.algorithm !== 'lcg32-v1') throw new Error('Unsupported RNG algorithm');
  const value = (Math.imul(rng.value, 1664525) + 1013904223) >>> 0;
  return { value: value / 0x1_0000_0000, rng: { algorithm: rng.algorithm, value, draws: rng.draws + 1 } };
}

export function shuffle<T>(items: readonly T[], initialRng: RngState): { items: T[]; rng: RngState } {
  const result = [...items];
  let rng = initialRng;
  for (let index = result.length - 1; index > 0; index -= 1) {
    const draw = nextRandom(rng);
    rng = draw.rng;
    const other = Math.floor(draw.value * (index + 1));
    [result[index], result[other]] = [result[other]!, result[index]!];
  }
  return { items: result, rng };
}
