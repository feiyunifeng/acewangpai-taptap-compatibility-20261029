import { otherPlayer, type PlayerId } from '../model/ids.js';
import type { GameResult } from '../model/state.js';

/** Multiple losses produced by the same resolution are a draw. */
export function resultForLosses(losers: readonly PlayerId[], reason: string): GameResult {
  const unique = new Set(losers);
  return { winner: unique.size === 2 ? null : otherPlayer(losers[0]!), reason };
}

export function resultForLifeTotals(life: Readonly<Record<PlayerId, number>>, reason = 'lifeZero'): GameResult | null {
  const losers: PlayerId[] = [];
  if (life.p1 <= 0) losers.push('p1');
  if (life.p2 <= 0) losers.push('p2');
  return losers.length === 0 ? null : resultForLosses(losers, reason);
}

export function resultForSpecialWin(winner: PlayerId, reason = 'specialVictory'): GameResult {
  return { winner, reason };
}
