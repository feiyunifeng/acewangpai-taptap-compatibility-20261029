import type { RuleError } from '../model/command.js';
import type { PlayerId } from '../model/ids.js';
import type { GameState, TurnCounters } from '../model/state.js';

export function freshTurnCounters(turn: number): TurnCounters {
  return { turn, terminalSummonsUsed: 0, skillsUsed: 0, activatedNames: [], activatedEffects: [],
    activatedCardIds: [], attacksDeclared: {} };
}

export function hasActivatedCardEffectThisTurn(state: GameState, cardId: string): boolean {
  return (['p1', 'p2'] as const).some((player) => currentTurnCounters(state, player).activatedCardIds.includes(cardId));
}

export function effectActivationKey(name: string, effectIndex: number): string {
  return `${name}\u0000${effectIndex}`;
}

export function hasEffectActivation(state: GameState, player: PlayerId, name: string, effectIndex: number,
  cooldownTurns = 1): boolean {
  const key = effectActivationKey(name, effectIndex);
  if (currentTurnCounters(state, player).activatedEffects.includes(key)) return true;
  if (cooldownTurns <= 1) return false;
  const lastActivation = state.effectCooldowns?.[player]?.[key];
  return lastActivation !== undefined && state.globalTurn - lastActivation < cooldownTurns;
}

export function consumeEffectActivation(state: GameState, player: PlayerId, name: string, effectIndex: number,
  cooldownTurns = 1):
  { readonly ok: true; readonly state: GameState } | { readonly ok: false; readonly state: GameState; readonly error: RuleError } {
  if (!Number.isInteger(effectIndex) || effectIndex < 1 || effectIndex > 3) {
    return { ok: false, state, error: { code: 'INVALID_EFFECT_SOURCE' } };
  }
  const counters = currentTurnCounters(state, player);
  const key = effectActivationKey(name, effectIndex);
  if (hasEffectActivation(state, player, name, effectIndex, cooldownTurns)) {
    return { ok: false, state, error: { code: 'NAME_ALREADY_ACTIVATED' } };
  }
  const cooldowns: Readonly<Record<PlayerId, Readonly<Record<string, number>>>> = state.effectCooldowns ?? {
    p1: {}, p2: {},
  };
  return { ok: true, state: {
    ...state,
    counters: { ...state.counters,
      [player]: { ...counters,
        activatedNames: counters.activatedNames.includes(name) ? counters.activatedNames : [...counters.activatedNames, name],
        activatedEffects: [...counters.activatedEffects, key],
      },
    },
    ...(cooldownTurns > 1 ? { effectCooldowns: {
      p1: player === 'p1' ? { ...cooldowns.p1, [key]: state.globalTurn } : cooldowns.p1,
      p2: player === 'p2' ? { ...cooldowns.p2, [key]: state.globalTurn } : cooldowns.p2,
    } } : {}),
  } };
}

export function currentTurnCounters(state: GameState, player: PlayerId): TurnCounters {
  const counters = state.counters[player];
  return counters.turn === state.globalTurn ? counters : freshTurnCounters(state.globalTurn);
}

export function hasTerminalSummonQuota(state: GameState, player: PlayerId): boolean {
  return currentTurnCounters(state, player).terminalSummonsUsed < state.config.terminalSummonsPerTurn;
}

export function consumeTerminalSummonQuota(state: GameState, player: PlayerId): GameState {
  const counters = currentTurnCounters(state, player);
  return { ...state, counters: { ...state.counters,
    [player]: { ...counters, terminalSummonsUsed: counters.terminalSummonsUsed + 1 },
  } };
}

export function consumeNameActivation(state: GameState, player: PlayerId, name: string):
  { readonly ok: true; readonly state: GameState } | { readonly ok: false; readonly state: GameState; readonly error: RuleError } {
  const counters = currentTurnCounters(state, player);
  if (counters.activatedNames.includes(name)) return { ok: false, state, error: { code: 'NAME_ALREADY_ACTIVATED' } };
  return { ok: true, state: { ...state, counters: {
    ...state.counters,
    [player]: { ...counters, activatedNames: [...counters.activatedNames, name] },
  } } };
}
