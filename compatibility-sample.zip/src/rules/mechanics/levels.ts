import type { CardCatalog } from '../model/card.js';
import type { CardInstanceId } from '../model/ids.js';
import type { CardInstance, GameState } from '../model/state.js';

export function getCurrentLevel(state: GameState, cardId: CardInstanceId, catalog: CardCatalog): number | null {
  if (catalog.version !== state.catalogVersion) return null;
  const card = Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId || !Number.isInteger(definition.level)) return null;
  return definition.level + card.modifiers.reduce((total, modifier) => total + (modifier.level ?? 0), 0);
}

export function addLevelModifier(state: GameState, cardId: CardInstanceId, amount: number,
  expiresAtTurn: number, id: string): GameState {
  if (!Number.isInteger(amount) || amount === 0 || !Number.isInteger(expiresAtTurn) || !id ||
    !Object.hasOwn(state.cards, cardId)) return state;
  const card = state.cards[cardId]!;
  const modifiers = card.modifiers.filter((modifier) => modifier.id !== id);
  const nextCard: CardInstance = { ...card, modifiers: [...modifiers, { id, level: amount, expiresAtTurn }] };
  return { ...state, cards: { ...state.cards, [cardId]: nextCard } };
}
