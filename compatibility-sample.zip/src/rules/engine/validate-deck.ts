import type { CardCatalog, DeckList } from '../model/card.js';
import type { RulesConfig } from '../model/config.js';

export interface DeckIssue {
  readonly code: 'MAIN_SIZE' | 'EXTRA_SIZE' | 'UNKNOWN_CARD' | 'WRONG_DECK' | 'COPY_LIMIT' | 'INVALID_LEVEL' | 'DESIGN_LEVEL_GATE';
  readonly cardId?: string;
}

function hasV13HardOperation(card: CardCatalog['cards'][string], catalog: CardCatalog): boolean {
  return (card.effectIds ?? []).some((id) => {
    const effect = catalog.effects?.[id];
    if (!effect) return false;
    if (['destroyTargets', 'sendTargetsToHeaven', 'negateActivation', 'negateEffect', 'negateSummon', 'negateAttack'].includes(effect.handlerId)) return true;
    if (effect.cost && ['release', 'discard', 'send'].includes(effect.cost.kind)) return true;
    return effect.program?.some((step) => step.kind === 'destroySelected' || step.kind === 'releaseSelected' ||
      step.kind === 'moveSelected' && (step.to === 'heaven' || step.to === 'hell')) ?? false;
  });
}

export function v13CardLevelGateIssue(card: CardCatalog['cards'][string], catalog: CardCatalog): boolean {
  if (card.designVersion !== '1.3') return false;
  let minimum = 1;
  const effects = (card.effectIds ?? []).map((id) => catalog.effects?.[id]).filter((effect) => effect !== undefined);
  if (card.kind === 'spell' && card.spellMode === 'quick' ||
    (card.kind === 'spell' || card.kind === 'counter') && effects.some((effect) => effect.speed === 2 && effect.mode !== 'continuous')) {
    minimum = Math.max(minimum, 5);
  }
  if (card.kind === 'counter') {
    minimum = Math.max(minimum, effects.some((effect) => effect.speed === 3 && effect.mode !== 'continuous') ? 9 : 5);
  }
  if ((card.kind === 'spell' || card.kind === 'counter') && hasV13HardOperation(card, catalog)) minimum = Math.max(minimum, 4);
  return card.level < minimum;
}

export interface DeckValidation {
  readonly valid: boolean;
  readonly issues: readonly DeckIssue[];
}

export function validateDeck(deck: DeckList, catalog: CardCatalog, config: RulesConfig): DeckValidation {
  const issues: DeckIssue[] = [];
  if (deck.main.length < config.mainDeckMin || deck.main.length > config.mainDeckMax) issues.push({ code: 'MAIN_SIZE' });
  if (deck.extra.length < config.extraDeckMin || deck.extra.length > config.extraDeckMax) issues.push({ code: 'EXTRA_SIZE' });

  for (const [zone, cardIds] of [['main', deck.main], ['extra', deck.extra]] as const) {
    const names = new Map<string, number>();
    for (const cardId of cardIds) {
      const card = Object.hasOwn(catalog.cards, cardId) ? catalog.cards[cardId] : undefined;
      if (!card || card.id !== cardId) {
        issues.push({ code: 'UNKNOWN_CARD', cardId });
        continue;
      }
      if (card.deck !== zone || (zone === 'extra' && card.kind !== 'monster')) issues.push({ code: 'WRONG_DECK', cardId });
      if (!Number.isInteger(card.level) || card.level <= 0) issues.push({ code: 'INVALID_LEVEL', cardId });
      if (v13CardLevelGateIssue(card, catalog) && !issues.some((issue) => issue.cardId === cardId && issue.code === 'DESIGN_LEVEL_GATE')) {
        issues.push({ code: 'DESIGN_LEVEL_GATE', cardId });
      }
      const count = (names.get(card.name) ?? 0) + 1;
      names.set(card.name, count);
      if (count === config.sameNameMax + 1) issues.push({ code: 'COPY_LIMIT', cardId });
    }
  }
  return { valid: issues.length === 0, issues };
}
