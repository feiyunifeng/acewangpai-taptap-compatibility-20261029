import type { CardCatalog } from '../model/card.js';
import type { Command, TriggerChoice } from '../model/command.js';
import type { EffectCardFilter, EffectDefinition } from '../model/effect.js';
import type { PlayerId } from '../model/ids.js';
import type { GameState } from '../model/state.js';
import { appendChainLink } from './chain-engine.js';
import { canSelectEffectCostCard } from '../mechanics/tp.js';
import { matchingEffectCards } from '../mechanics/effects.js';
import { hiddenFieldTargetRef, resolveHiddenTargetCommand } from '../model/hidden-field-target.js';
import { otherPlayer } from '../model/ids.js';

/** Enumerate card and skill effect commands before the command boundary validates them. */
export function knownCardIds(state: GameState, player: PlayerId): readonly string[] {
  const own = state.players[player].zones;
  const publicIds = (['normal', 'frontline', 'spellCounter', 'heaven', 'hell'] as const)
    .flatMap((zone) => (['p1', 'p2'] as const).flatMap((owner) => state.players[owner].zones[zone]))
    .filter((id): id is string => id !== null)
    .filter((id) => state.cards[id]?.face === 'up' ||
      state.cards[id]?.location.zone === 'heaven' || state.cards[id]?.location.zone === 'hell' ||
      state.cards[id]?.location.player === player);
  return [...new Set([...own.hand, ...own.extraDeck, ...publicIds])];
}

export function* combinations<T>(items: readonly T[], min: number, max: number): Generator<readonly T[]> {
  function* visit(index: number, selected: T[]): Generator<readonly T[]> {
    if (selected.length >= min && selected.length <= max) yield [...selected];
    if (selected.length >= max) return;
    for (let i = index; i < items.length; i++) {
      selected.push(items[i]!);
      yield* visit(i + 1, selected);
      selected.pop();
    }
  }
  yield* visit(0, []);
}

function costIds(state: GameState, player: PlayerId, effect: EffectDefinition, catalog: CardCatalog,
  known: readonly string[], sourceCardId?: string): readonly string[] {
  if (!effect.cost) return [];
  if (effect.cost.mustBeSource) return sourceCardId && canSelectEffectCostCard(state, player, effect, sourceCardId, catalog)
    ? [sourceCardId] : [];
  const costZones = [effect.cost.zone, ...(effect.cost.alsoZones ?? [])];
  const eligible = costZones.flatMap((zone) => state.players[player].zones[zone])
    .filter((id): id is string => id !== null);
  return [...new Set([...known, ...eligible])].filter((id) => id !== sourceCardId || !effect.cost?.excludeSource)
    .filter((id) => canSelectEffectCostCard(state, player, effect, id, catalog));
}

function* targetSets(state: GameState, player: PlayerId, effect: EffectDefinition, catalog: CardCatalog,
  known: readonly string[], sourceCardId?: string, eventCardId?: string): Generator<readonly string[]> {
  const candidatesFor = (filter: EffectCardFilter | undefined): readonly string[] => {
    const safeKeys = new Set(['zones', 'side', 'kinds', 'face', 'excludeSource']);
    const publicBackrow = filter && filter.zones.includes('spellCounter') && filter.side !== 'self' && filter.face !== 'up' &&
      Object.keys(filter).every((key) => safeKeys.has(key)) &&
      (!filter.kinds || filter.kinds.includes('spell') && filter.kinds.includes('counter'))
      ? state.players[otherPlayer(player)].zones.spellCounter.filter((id): id is string => id !== null && state.cards[id]?.face === 'down') : [];
    return [...new Set([...known, ...publicBackrow])];
  };
  if (effect.triggerTarget === 'eventCard') {
    const target = eventCardId ? state.cards[eventCardId] : undefined;
    const filter = effect.targets?.filter;
    if (target && effect.targets?.zones.includes(target.location.zone) &&
      (!filter || matchingEffectCards(state, player, filter, catalog, sourceCardId).includes(target.id))) yield [target.id];
    return;
  }
  if (effect.responseTarget) {
    const top = state.chain.at(-1);
    if (!effect.targets) {
      yield [];
      return;
    }
    const targetIds = effect.responseTarget === 'opponentEffectSource'
      ? top?.player !== player && top?.source.kind === 'card' ? [top.source.instanceId] : []
      : effect.responseTarget === 'opponentAttackSource'
        ? state.pendingBattle?.player !== player && state.pendingBattle?.stage === 'attackDeclaration'
          ? [state.pendingBattle.attackerId] : []
        : top?.player !== player ? top?.targetSnapshots.filter((snapshot) => snapshot.player === player)
          .map((snapshot) => snapshot.id) ?? [] : [];
    for (const targetId of targetIds) {
      const target = state.cards[targetId];
      if (target && effect.targets.zones.includes(target.location.zone) &&
        (!effect.targets.filter || matchingEffectCards(state, player, effect.targets.filter, catalog, sourceCardId).includes(targetId))) {
        yield [targetId];
      }
    }
    return;
  }
  if (!effect.targets && !effect.targetGroups?.length) {
    yield [];
    return;
  }
  if (effect.targetGroups?.length) {
    const groups = effect.targetGroups;
    function* visit(groupIndex: number, selected: readonly string[]): Generator<readonly string[]> {
      if (groupIndex >= groups.length) { yield selected; return; }
      const group = groups[groupIndex]!;
      const eligible = candidatesFor(group.filter).filter((id) => group.zones.includes(state.cards[id]!.location.zone) &&
        (!group.filter || matchingEffectCards(state, player, group.filter, catalog, sourceCardId).includes(id)))
        .map((id) => hiddenFieldTargetRef(state, player, id));
      for (const groupIds of combinations(eligible, group.min, group.max)) {
        if (new Set([...selected, ...groupIds]).size !== selected.length + groupIds.length) continue;
        yield* visit(groupIndex + 1, [...selected, ...groupIds]);
      }
    }
    yield* visit(0, []);
    return;
  }
  const eligible = candidatesFor(effect.targets!.filter).filter((id) => (!effect.targets!.excludeSource || id !== sourceCardId) &&
    effect.targets!.zones.includes(state.cards[id]!.location.zone) &&
    (!effect.targets!.filter || matchingEffectCards(state, player, effect.targets!.filter, catalog, sourceCardId).includes(id)))
    .map((id) => hiddenFieldTargetRef(state, player, id));
  yield* combinations(eligible, effect.targets!.min, effect.targets!.max);
}

export function* materialSets(state: GameState, player: PlayerId, effect: EffectDefinition | null,
  known: readonly string[]): Generator<readonly string[]> {
  const eligible = known.filter((id) => {
    const card = state.cards[id]!;
    if (card.face === 'up' && card.controller === player &&
      (card.location.zone === 'normal' || card.location.zone === 'frontline')) return true;
    return !!effect?.materialPermission?.zones.includes(card.location.zone) &&
      (card.owner === player || effect.materialPermission.allowOpponent) &&
      (card.owner === player || card.face === 'up');
  });
  yield* combinations(eligible, 1, eligible.length);
}

export function* effectChoices(state: GameState, player: PlayerId, effect: EffectDefinition, catalog: CardCatalog,
  known: readonly string[], sourceCardId?: string, eventCardId?: string): Generator<Omit<TriggerChoice, 'triggerId'>> {
  const costs = effect.cost ? costIds(state, player, effect, catalog, known, sourceCardId) : [undefined];
  const resourceArchetypeId = effect.resourceCost?.filter?.archetypeId;
  const resourceCosts = effect.resourceCost
    ? known.filter((id) => state.cards[id]?.location.zone === effect.resourceCost!.zone &&
      state.cards[id]?.owner === player && state.cards[id]?.location.player === player &&
      (resourceArchetypeId === undefined ||
        catalog.cards[state.cards[id]!.cardId]?.archetypeIds?.includes(resourceArchetypeId) === true))
    : [undefined];
  for (const costCardId of costs) {
    for (const resourceCostCardId of resourceCosts) {
      for (const targetIds of targetSets(state, player, effect, catalog, known, sourceCardId, eventCardId)) {
        if (effect.fieldMark) {
          const marks = state.fieldMarks?.[player] ?? {};
          for (let slot = 0; slot < state.players[player].zones.normal.length; slot++) {
            if (state.players[player].zones.normal[slot] === null && !marks[slot]) yield {
              ...(costCardId ? { costCardId } : {}), ...(resourceCostCardId ? { resourceCostCardId } : {}),
              ...(effect.targets || effect.targetGroups?.length ? { targetIds } : {}), fieldMarkSlot: slot,
            };
          }
          continue;
        }
        if (effect.handlerId === 'effectSummonTerminal') {
          for (const terminalId of state.players[player].zones.extraDeck) {
            for (const materialIds of materialSets(state, player, effect, known)) {
              for (const zone of ['frontline', 'normal'] as const) {
                const slots = state.players[player].zones[zone];
                for (let slot = 0; slot < slots.length; slot++) yield {
                  ...(costCardId ? { costCardId } : {}), ...(resourceCostCardId ? { resourceCostCardId } : {}),
                  ...(effect.targets || effect.targetGroups?.length ? { targetIds } : {}), terminalId, materialIds, terminalZone: zone, terminalSlot: slot,
                };
              }
            }
          }
        } else {
          yield { ...(costCardId ? { costCardId } : {}), ...(resourceCostCardId ? { resourceCostCardId } : {}),
            ...(effect.targets || effect.targetGroups?.length ? { targetIds } : {}) };
        }
      }
    }
  }
}

export function* sourceCommands(state: GameState, player: PlayerId, catalog: CardCatalog,
  known: readonly string[] = knownCardIds(state, player),
  effectFilter?: (effect: EffectDefinition) => boolean,
  sourceIdFilter?: ReadonlySet<string>): Generator<Command> {
  const top = state.chain.at(-1);
  const responseTo = top?.id ?? (state.pendingBattle && state.window.kind === 'response'
    ? `battle:${state.pendingBattle.id}` : state.pendingSummon && state.window.kind === 'response'
      ? `summon:${state.window.id}` : undefined);
  for (const id of known) {
    if (sourceIdFilter && !sourceIdFilter.has(id)) continue;
    const card = state.cards[id]!;
    const definition = catalog.cards[card.cardId];
    if (!definition || definition.id !== card.cardId) continue;
    for (const effectId of new Set(definition.effectIds ?? [])) {
      const effect = catalog.effects?.[effectId];
      if (!effect || effect.source !== 'card' || effectFilter && !effectFilter(effect)) continue;
      for (const choice of effectChoices(state, player, effect, catalog, known, id)) yield {
        type: 'activateEffect', player, source: { kind: 'card', instanceId: id }, effectId,
        ...(responseTo ? { responseTo } : {}), ...choice,
      };
    }
  }
  for (const copyId of state.players[player].skillCopies) {
    if (sourceIdFilter && !sourceIdFilter.has(copyId)) continue;
    const copy = state.skills[copyId]!;
    const definition = catalog.skills[copy.skillId];
    if (!definition || definition.id !== copy.skillId) continue;
    for (const effectId of new Set(definition.effectIds ?? [])) {
      const effect = catalog.effects?.[effectId];
      if (!effect || effect.source !== 'skill' || effectFilter && !effectFilter(effect)) continue;
      for (const choice of effectChoices(state, player, effect, catalog, known)) yield {
        type: 'activateEffect', player, source: { kind: 'skill', copyId }, effectId,
        ...(responseTo ? { responseTo } : {}), ...choice,
      };
    }
  }
}

/** Checks real response legality for either player without exposing hidden cards to a view. */
export function hasLegalBattleResponse(state: GameState, player: PlayerId, catalog: CardCatalog): boolean {
  if (state.result !== null || !state.pendingBattle || state.window.kind !== 'response' ||
    state.chain.length > 0 || state.pendingTriggers.length > 0 || state.pendingSummon) return false;
  const responseState = state.window.priorityPlayer === player ? state : {
    ...state, window: { ...state.window, priorityPlayer: player },
  };
  for (const command of sourceCommands(responseState, player, catalog, undefined, (effect) => effect.mode === 'response')) {
    const resolved = resolveHiddenTargetCommand(responseState, command);
    if (resolved?.type === 'activateEffect' && appendChainLink(responseState, resolved, catalog).ok) return true;
  }
  return false;
}
