import type { CardCatalog } from '../model/card.js';
import { hiddenFieldTargetRef } from '../model/hidden-field-target.js';
import type { Command, TriggerChoice } from '../model/command.js';
import type { EffectMode, TriggerCandidate } from '../model/effect.js';
import type { PlayerId } from '../model/ids.js';
import type { GameState } from '../model/state.js';
import { getAttackTargets } from '../mechanics/combat.js';
import { mainSummonMaterialSets } from '../mechanics/main-summon.js';
import { effectTpCost } from '../mechanics/tp.js';
import { projectState } from '../view/project-state.js';
import { applyCommand } from './submit-command.js';
import { combinations, effectChoices, knownCardIds, materialSets, sourceCommands } from './effect-action-candidates.js';

export interface LegalActionActivation {
  readonly effectId: string;
  readonly effectIndex: 1 | 2 | 3;
  readonly speed: 1 | 2 | 3;
  readonly mode: EffectMode;
  readonly tpCost: number;
  readonly sourceKind: 'card' | 'skill';
  readonly sourceId: string;
  readonly sourceCardId?: string;
  readonly sourceName: string;
}

export interface LegalActionCardChoice {
  readonly id: string;
  readonly cardId: string;
}

export interface TpUnavailableEffectAction {
  readonly activation: LegalActionActivation;
  readonly currentTp: number;
}

export interface LegalAction {
  readonly command: Command;
  readonly label: string;
  /** Trusted activation facts computed from the same state/catalog used to authorize the command. */
  readonly activation?: LegalActionActivation;
  readonly triggerActivations?: readonly LegalActionActivation[];
  /** Hidden own-deck identities only for card instances explicitly selected by this authorized command. */
  readonly authorizedCardChoices?: readonly LegalActionCardChoice[];
}
export interface LegalActionQueryOptions { readonly cursor?: string; readonly pageSize?: number }
export interface LegalActionPage { readonly actions: readonly LegalAction[]; readonly nextCursor: string | null }

const EMPTY_PAGE: LegalActionPage = { actions: [], nextCursor: null };
const MAX_PAGE_SIZE = 100;

function activationInfo(state: GameState, catalog: CardCatalog, effectId: string,
  source: { readonly kind: 'card'; readonly instanceId: string } | { readonly kind: 'skill'; readonly copyId: string }): LegalActionActivation | undefined {
  const effect = catalog.effects?.[effectId];
  if (!effect) return undefined;
  if (source.kind === 'card') {
    const instance = state.cards[source.instanceId];
    const definition = instance && catalog.cards[instance.cardId];
    const tpCost = definition ? effectTpCost(definition.level) : null;
    if (!instance || !definition || tpCost === null) return undefined;
    return { effectId, effectIndex: effect.effectIndex ?? 1, speed: effect.speed, mode: effect.mode,
      tpCost, sourceKind: 'card', sourceId: instance.id, sourceCardId: definition.id, sourceName: definition.name };
  }
  const copy = state.skills[source.copyId];
  const definition = copy && catalog.skills[copy.skillId];
  if (!copy || !definition) return undefined;
  return { effectId, effectIndex: effect.effectIndex ?? 1, speed: effect.speed, mode: effect.mode,
    tpCost: 0, sourceKind: 'skill', sourceId: copy.id, sourceName: definition.name };
}

function actionActivation(state: GameState, command: Command, catalog: CardCatalog): LegalActionActivation | undefined {
  if (command.type !== 'activateEffect') return undefined;
  return activationInfo(state, catalog, command.effectId, command.source);
}

function triggerActivations(state: GameState, command: Command, catalog: CardCatalog): readonly LegalActionActivation[] | undefined {
  if (command.type !== 'chooseTriggers') return undefined;
  const activations = command.orderedTriggerIds.flatMap((id) => {
    const trigger = state.pendingTriggers.find((item) => item.id === id);
    if (!trigger) return [];
    const source = Object.hasOwn(state.skills, trigger.sourceId)
      ? { kind: 'skill' as const, copyId: trigger.sourceId }
      : { kind: 'card' as const, instanceId: trigger.sourceId };
    const activation = activationInfo(state, catalog, trigger.effectId, source);
    return activation ? [activation] : [];
  });
  return activations.length > 0 ? activations : undefined;
}

function authorizedCardChoices(state: GameState, player: PlayerId, command: Command): readonly LegalActionCardChoice[] | undefined {
  const selectedIds = command.type === 'activateEffect'
    ? [command.costCardId, command.terminalId]
    : command.type === 'ruleSummonTerminal' ? [command.terminalId]
      : command.type === 'chooseTriggers' ? command.choices?.flatMap((choice) => [choice.costCardId, choice.terminalId]) ?? []
        : [];
  const choices = [...new Set(selectedIds.filter((id): id is string => !!id))].flatMap((id) => {
    const card = state.cards[id];
    if (!card || card.owner !== player || !['mainDeck', 'extraDeck'].includes(card.location.zone)) return [];
    return [{ id, cardId: card.cardId }];
  });
  return choices.length ? choices : undefined;
}

function legalActionsFromSources(state: GameState, player: PlayerId, catalog: CardCatalog,
  sourceKind: 'card' | 'skill', known: readonly string[], sourceIds?: ReadonlySet<string>): readonly LegalAction[] {
  if (catalog.version !== state.catalogVersion || state.result !== null) return [];
  const actions: LegalAction[] = [];
  for (const command of sourceCommands(state, player, catalog, known,
    (effect) => effect.source === sourceKind && (effect.mode === 'active' || effect.mode === 'response'), sourceIds)) {
    if (command.type !== 'activateEffect' || command.source.kind !== sourceKind || sourceIds && !sourceIds.has(
      command.source.kind === 'card' ? command.source.instanceId : command.source.copyId) ||
      !applyCommand(state, command, catalog).ok) continue;
    const activation = actionActivation(state, command, catalog);
    const choices = authorizedCardChoices(state, player, command);
    actions.push({ command, label: command.effectId, ...(activation ? { activation } : {}),
      ...(choices ? { authorizedCardChoices: choices } : {}) });
  }
  return actions;
}

/** Legal proactive and response actions sourced from the observer's public Heaven/Hell cards. */
export function getLegalResourceActions(state: GameState, player: PlayerId, catalog: CardCatalog): readonly LegalAction[] {
  const resources = [...state.players[player].zones.heaven, ...state.players[player].zones.hell]
    .filter((id): id is string => id !== null)
    .filter((id) => state.cards[id]?.owner === player && state.cards[id]?.location.player === player &&
      (state.cards[id]?.location.zone === 'heaven' || state.cards[id]?.location.zone === 'hell'));
  return legalActionsFromSources(state, player, catalog, 'card', knownCardIds(state, player), new Set(resources));
}

/** Legal actions for only the requesting player's visible, configured skill copies. */
export function getLegalSkillActions(state: GameState, player: PlayerId, catalog: CardCatalog): readonly LegalAction[] {
  const effects = legalActionsFromSources(state, player, catalog, 'skill', knownCardIds(state, player));
  const direct = state.players[player].skillCopies.flatMap((skillCopyId) => {
    const copy = state.skills[skillCopyId];
    const skill = copy && catalog.skills[copy.skillId];
    if (!skill?.directAbility) return [];
    const command: Command = { type: 'useSkill', player, skillCopyId };
    return applyCommand(state, command, catalog).ok ? [{ command, label: skill.name }] : [];
  });
  return [...effects, ...direct];
}

/** All legal speed-2/3 card effects at the current exact window, from hand, field, Heaven and Hell. */
export function getLegalQuickActions(state: GameState, player: PlayerId, catalog: CardCatalog): readonly LegalAction[] {
  return [...legalActionsFromSources(state, player, catalog, 'card', knownCardIds(state, player))]
    .filter((action) => action.activation !== undefined && action.activation.speed > 1);
}

function* permutations<T>(items: readonly T[]): Generator<readonly T[]> {
  const selected: T[] = [];
  const used = Array(items.length).fill(false) as boolean[];
  function* visit(): Generator<readonly T[]> {
    if (selected.length === items.length) {
      yield [...selected];
      return;
    }
    for (let i = 0; i < items.length; i++) {
      if (used[i]) continue;
      used[i] = true;
      selected.push(items[i]!);
      yield* visit();
      selected.pop();
      used[i] = false;
    }
  }
  yield* visit();
}

function* choicesForTriggers(state: GameState, player: PlayerId, catalog: CardCatalog,
  known: readonly string[], triggers: readonly TriggerCandidate[], index: number,
  selected: readonly TriggerChoice[]): Generator<Command> {
  if (index === triggers.length) {
    yield { type: 'chooseTriggers', player, orderedTriggerIds: triggers.map((item) => item.id),
      choices: selected };
    return;
  }
  const trigger = triggers[index]!;
  const effect = catalog.effects?.[trigger.effectId];
  if (!effect) return;
  let hasChoice = false;
    for (const choice of effectChoices(state, player, effect, catalog, known,
      trigger.sourceId.startsWith('skill:') ? undefined : trigger.sourceId, trigger.eventCardId)) {
    hasChoice = true;
    yield* choicesForTriggers(state, player, catalog, known, triggers, index + 1,
      [...selected, { triggerId: trigger.id, ...choice }]);
  }
  if (!hasChoice && trigger.mandatory) {
    yield* choicesForTriggers(state, player, catalog, known, triggers, index + 1,
      [...selected, { triggerId: trigger.id }]);
  }
}

function* triggerCommands(state: GameState, player: PlayerId, catalog: CardCatalog,
  known: readonly string[]): Generator<Command> {
  if (state.window.kind !== 'choice' || state.pendingTriggers.length === 0) return;
  const own = state.pendingTriggers.filter((item) => item.player === player);
  const mandatory = own.filter((item) => item.mandatory);
  const optional = own.filter((item) => !item.mandatory);
  for (const selected of combinations(optional, 0, optional.length)) {
    for (const orderedMandatory of permutations(mandatory)) {
      for (const orderedOptional of permutations(selected)) {
        yield* choicesForTriggers(state, player, catalog, known,
          [...orderedMandatory, ...orderedOptional], 0, []);
      }
    }
  }
}

function* candidateCommands(state: GameState, player: PlayerId, catalog: CardCatalog,
  known: readonly string[]): Generator<Command> {
  if (state.pendingResolution) {
    const pending = state.pendingResolution;
    if (pending.player !== player) return;
    for (const candidate of pending.candidates) {
      const cardId = hiddenFieldTargetRef(state, player, candidate);
      if (pending.destinations) {
        for (const destination of pending.destinations) yield { type: 'chooseResolutionCard', player, cardId, destination };
      } else yield { type: 'chooseResolutionCard', player, cardId };
    }
    if (pending.selected.length >= pending.minimum) yield { type: 'finishResolutionChoice', player };
    return;
  }
  yield { type: 'concede', player };
  yield { type: 'passPriority', player };
  yield { type: 'passSummonResponse', player };
  for (const skillCopyId of state.players[player].skillCopies) {
    if (catalog.skills[state.skills[skillCopyId]?.skillId]?.directAbility) yield { type: 'useSkill', player, skillCopyId };
  }
  yield { type: 'drawCard', player };
  for (const to of ['start', 'draw', 'main1', 'battle', 'main2', 'end'] as const) {
    yield { type: 'advancePhase', player, to };
  }
  for (const cardId of state.players[player].zones.hand) {
    for (const materialIds of mainSummonMaterialSets(state, player, cardId, catalog)) {
      for (let slot = 0; slot < state.players[player].zones.normal.length; slot++) {
        yield { type: 'ruleSummonMonster', player, cardId, ...(materialIds.length ? { materialIds } : {}), slot };
      }
    }
    for (let slot = 0; slot < state.players[player].zones.spellCounter.length; slot++) {
      yield { type: 'setCard', player, cardId, slot };
    }
    yield { type: 'discardCard', player, cardId };
  }
  for (const terminalId of state.players[player].zones.extraDeck) {
    for (const materialIds of materialSets(state, player, null, known)) {
      for (const zone of ['frontline', 'normal'] as const) {
        for (let slot = 0; slot < state.players[player].zones[zone].length; slot++) {
          yield { type: 'ruleSummonTerminal', player, terminalId, materialIds, zone, slot };
        }
      }
    }
  }
  yield* sourceCommands(state, player, catalog, known);
  yield* triggerCommands(state, player, catalog, known);
  if (state.phase === 'battle') {
    for (const attackerId of [...state.players[player].zones.normal, ...state.players[player].zones.frontline]) {
      if (!attackerId) continue;
      for (const target of getAttackTargets(state, attackerId, catalog)) {
        yield { type: 'declareAttack', player, attackerId, target };
      }
    }
  }
  if (state.pendingBattle?.stage === 'retarget' && state.pendingBattle.player === player) {
    yield { type: 'chooseBattleTarget', player, target: null };
    for (const target of getAttackTargets(state, state.pendingBattle.attackerId, catalog)) {
      yield { type: 'chooseBattleTarget', player, target };
    }
  }
}

/** Bind to observer-safe state and the non-secret event revision, never hidden identities. */
function fingerprint(state: GameState, player: PlayerId, catalogVersion: string): string {
  const serialized = JSON.stringify([projectState(state, player), state.eventSequence, player, catalogVersion]);
  let hash = 0xcbf29ce484222325n;
  for (let i = 0; i < serialized.length; i++) {
    hash ^= BigInt(serialized.charCodeAt(i));
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return hash.toString(16).padStart(16, '0');
}

function cursorOffset(cursor: string | undefined, token: string): number | null {
  if (cursor === undefined) return 0;
  const match = /^([0-9a-f]{16})\.(0|[1-9][0-9]*)$/.exec(cursor);
  if (!match || match[1] !== token) return null;
  const offset = Number(match[2]);
  return Number.isSafeInteger(offset) ? offset : null;
}

/** Generate observer-known candidates one at a time and validate each through the command boundary. */
export function getLegalActions(state: GameState, player: PlayerId, catalog: CardCatalog,
  options: LegalActionQueryOptions = {}): LegalActionPage {
  if (catalog.version !== state.catalogVersion || state.result !== null) return EMPTY_PAGE;
  const token = fingerprint(state, player, catalog.version);
  const offset = cursorOffset(options.cursor, token);
  if (offset === null) return EMPTY_PAGE;
  const pageSize = Number.isInteger(options.pageSize) ? Math.min(MAX_PAGE_SIZE, Math.max(1, options.pageSize!)) : MAX_PAGE_SIZE;
  const known = knownCardIds(state, player);
  const actions: LegalAction[] = [];
  let position = 0;
  for (const command of candidateCommands(state, player, catalog, known)) {
    const current = position++;
    if (current < offset || !applyCommand(state, command, catalog).ok) continue;
    if (actions.length === pageSize) return { actions, nextCursor: `${token}.${current}` };
    const activation = actionActivation(state, command, catalog);
    const triggerEffects = triggerActivations(state, command, catalog);
    const cardChoices = authorizedCardChoices(state, player, command);
    const skillLabel = command.type === 'useSkill' ? catalog.skills[state.skills[command.skillCopyId]?.skillId]?.name : undefined;
    actions.push({ command, label: skillLabel ?? (command.type === 'activateEffect' ? command.effectId : command.type),
      ...(activation ? { activation } : {}), ...(triggerEffects ? { triggerActivations: triggerEffects } : {}),
      ...(cardChoices ? { authorizedCardChoices: cardChoices } : {}) });
  }
  return { actions, nextCursor: null };
}

/** Effects that otherwise pass the real command checks but are blocked only by current TP. */
export function getTpUnavailableEffectActions(state: GameState, player: PlayerId, catalog: CardCatalog,
  sourceId: string): readonly TpUnavailableEffectAction[] {
  if (catalog.version !== state.catalogVersion || state.result !== null || !Object.hasOwn(state.cards, sourceId)) return [];
  const known = knownCardIds(state, player);
  const blocked = new Map<string, TpUnavailableEffectAction>();
  for (const command of sourceCommands(state, player, catalog, known,
    (effect) => effect.source === 'card' && (effect.mode === 'active' || effect.mode === 'response'),
    new Set([sourceId]))) {
    if (command.type !== 'activateEffect') continue;
    const activation = actionActivation(state, command, catalog);
    if (!activation || activation.tpCost <= state.players[player].tp) continue;
    const key = JSON.stringify([command.effectId, command.responseTo, activation.mode]);
    if (blocked.has(key)) continue;
    const attempt = applyCommand(state, command, catalog);
    if (attempt.ok || attempt.error.code !== 'INSUFFICIENT_TP') continue;
    const playerState = state.players[player];
    const affordableState = { ...state, players: { ...state.players,
      [player]: { ...playerState, tp: activation.tpCost } } };
    if (applyCommand(affordableState, command, catalog).ok) blocked.set(key, { activation, currentTp: playerState.tp });
  }
  return [...blocked.values()];
}
