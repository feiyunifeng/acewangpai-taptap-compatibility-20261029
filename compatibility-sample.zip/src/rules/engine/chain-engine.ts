import type { CardCatalog, CardDefinition, SkillDefinition } from '../model/card.js';
import type { ChainLink } from '../model/chain.js';
import type { ActivateEffectCommand, ChooseResolutionCardCommand, FinishResolutionChoiceCommand,
  ChooseTriggersCommand, RuleErrorCode, TriggerChoice } from '../model/command.js';
import type { EffectDefinition, EffectSpeed, ResolutionSelection, TriggerCandidate } from '../model/effect.js';
import { cardIdentityVisibility, type EffectActivatedEvent, type EffectNegationEvent,
  type EffectResolvedEvent, type GameEvent } from '../model/event.js';
import { isKeywordStatusActive, type RuleOperationEvent } from '../model/keyword.js';
import { otherPlayer, type PlayerId } from '../model/ids.js';
import type { BattleStep, CardInstance, GameState } from '../model/state.js';
import { consumeEffectActivation, currentTurnCounters, effectActivationKey, hasEffectActivation } from '../mechanics/counters.js';
import { applyNamedEffect, deriveAuthorizedMaterials, effectFromCatalog, matchingEffectCards,
  meetsEffectActivationRequirements } from '../mechanics/effects.js';
import { failNegatedKeywordOperations } from '../mechanics/keyword-runtime.js';
import { canEffectSummonTerminal, resolveRuleSummon } from '../mechanics/summoning.js';
import { consumeSkillCopy, skillCopyForActivation } from '../mechanics/skills.js';
import { canSelectEffectCostCard, effectLifeCost, effectTpCost, payEffectCosts, validateEffectPayment } from '../mechanics/tp.js';
import { moveCard } from './move-card.js';
import { consumeEffectDestructionProtection } from '../mechanics/effect-protection.js';
import { canonicalCommandSelections } from '../model/selection.js';
import type { CommandResult } from './submit-command.js';

function rejected(state: GameState, code: RuleErrorCode): CommandResult {
  return { ok: false, state, error: { code } };
}
function accepted(state: GameState, events: readonly GameEvent[]): CommandResult {
  return { ok: true, state, events };
}

function cardDefinition(catalog: CardCatalog, card: CardInstance): CardDefinition | undefined {
  const found = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  return found?.id === card.cardId ? found : undefined;
}

function conditionMatches(state: GameState, player: PlayerId, effect: EffectDefinition): boolean {
  switch (effect.conditionId) {
    case 'ownTurn': return state.turnPlayer === player;
    case 'opponentTurn': return state.turnPlayer !== player;
    case 'ownBattlePhase': return state.turnPlayer === player && state.phase === 'battle';
    case 'battlePhase': return state.phase === 'battle';
    default: return true;
  }
}

function mainMonsterEffectBlocked(state: GameState, player: PlayerId, sourceId: string,
  definition: CardDefinition | undefined): boolean {
  const lock = state.mainMonsterEffectLocks?.[player];
  return !!lock && lock.globalTurn === state.globalTurn && lock.exceptCardId !== sourceId &&
    definition?.kind === 'monster' && definition.deck === 'main';
}

function matchEffectWasUsed(state: GameState, player: PlayerId, name: string, effect: EffectDefinition): boolean {
  return effect.oncePerGame === true && (state.matchEffectActivations?.[player] ?? [])
    .includes(effectActivationKey(name, effect.effectIndex ?? 1));
}

function consumeMatchEffect(state: GameState, player: PlayerId, name: string,
  effect: EffectDefinition): GameState {
  if (!effect.oncePerGame) return state;
  const key = effectActivationKey(name, effect.effectIndex ?? 1);
  const used = state.matchEffectActivations?.[player] ?? [];
  if (used.includes(key)) return state;
  const current = state.matchEffectActivations ?? { p1: [], p2: [] };
  return { ...state, matchEffectActivations: { ...current,
    [player]: [...used, key] } };
}

function lockOtherMainMonsterEffects(state: GameState, player: PlayerId, sourceId: string,
  effect: EffectDefinition): GameState {
  return effect.locksOtherMainMonsterEffects ? { ...state, mainMonsterEffectLocks: {
    ...state.mainMonsterEffectLocks, [player]: { globalTurn: state.globalTurn, exceptCardId: sourceId },
  } } : state;
}

interface SourceInfo {
  readonly name: string;
  readonly speed: EffectSpeed;
  readonly card?: CardInstance;
  readonly cardDefinition?: CardDefinition;
  readonly skillDefinition?: SkillDefinition;
}

function sourceInfo(state: GameState, command: ActivateEffectCommand, catalog: CardCatalog,
  effect: EffectDefinition): SourceInfo | RuleErrorCode {
  if (command.source.kind === 'card') {
    if (effect.source !== 'card') return 'INVALID_EFFECT_SOURCE';
    const card = Object.hasOwn(state.cards, command.source.instanceId) ? state.cards[command.source.instanceId] : undefined;
    const source = card ? cardDefinition(catalog, card) : undefined;
    if (!card || !source || !source.effectIds?.includes(effect.id) ||
      !effect.allowedZones.includes(card.location.zone) || card.flags.includes('effectsNegated') ||
      card.effectsDisabledUntilTurn !== undefined && card.effectsDisabledUntilTurn >= state.globalTurn ||
      mainMonsterEffectBlocked(state, command.player, card.id, source) ||
      isKeywordStatusActive(state, card.id, 'freeze')) return 'INVALID_EFFECT_SOURCE';
    if (card.location.zone === 'normal' || card.location.zone === 'frontline' || card.location.zone === 'spellCounter') {
      if (card.controller !== command.player || card.location.player !== command.player ||
        (source.kind === 'monster' && card.face !== 'up')) return 'INVALID_EFFECT_SOURCE';
    } else if (card.owner !== command.player) return 'INVALID_EFFECT_SOURCE';
    if (source.kind === 'counter') {
      if (card.location.zone === 'spellCounter') {
        if (card.face !== 'down' || card.setOnTurn === null || card.setOnTurn >= state.globalTurn) {
          return 'INVALID_EFFECT_TIMING';
        }
      }
    } else if (source.kind === 'spell') {
      if (card.location.zone === 'hand' && source.spellMode === 'quick' && command.player !== state.turnPlayer) {
        return 'INVALID_EFFECT_TIMING';
      }
      if (card.location.zone === 'spellCounter' && card.face === 'down' && source.spellMode === 'quick' &&
        card.setOnTurn !== null && card.setOnTurn >= state.globalTurn) return 'INVALID_EFFECT_TIMING';
      if (source.spellMode === 'normal') {
        if (effect.speed !== 1) return 'INVALID_EFFECT_SPEED';
      }
      if (source.spellMode === 'quick' && effect.speed !== 2) return 'INVALID_EFFECT_SPEED';
    }
    return { name: source.name, speed: effect.speed, card, cardDefinition: source };
  }
  if (effect.source !== 'skill') return 'INVALID_EFFECT_SOURCE';
  const checked = skillCopyForActivation(state, catalog, command.player, command.source.copyId);
  if ('error' in checked) return checked.error;
  const source = Object.hasOwn(catalog.skills, checked.copy.skillId) ? catalog.skills[checked.copy.skillId] : undefined;
  if (!source || source.id !== checked.copy.skillId || !source.effectIds?.includes(effect.id)) return 'INVALID_EFFECT_SOURCE';
  return { name: checked.name, speed: checked.speed, skillDefinition: source };
}

function linkedEffectIsTrusted(state: GameState, link: ChainLink, effect: EffectDefinition, catalog: CardCatalog): boolean {
  if (link.source.kind === 'card') {
    const card = Object.hasOwn(state.cards, link.source.instanceId) ? state.cards[link.source.instanceId] : undefined;
    const source = card ? cardDefinition(catalog, card) : undefined;
    return effect.source === 'card' && !!source?.effectIds?.includes(effect.id) && source.name === link.sourceName;
  }
  const copy = Object.hasOwn(state.skills, link.source.copyId) ? state.skills[link.source.copyId] : undefined;
  const source = copy && Object.hasOwn(catalog.skills, copy.skillId) ? catalog.skills[copy.skillId] : undefined;
  return effect.source === 'skill' && !!source && source.id === copy?.skillId &&
    !!source.effectIds?.includes(effect.id) && source.name === link.sourceName;
}

function battleTimingAllows(stage: BattleStep, timing: EffectDefinition['timing']): boolean {
  if (stage === 'damageCalculation') return timing === 'damageCalculation';
  if (stage === 'retarget') return false;
  return timing === undefined || timing === stage;
}

function linkDestroysSelectedCard(link: ChainLink, catalog: CardCatalog): boolean {
  const effect = effectFromCatalog(catalog, link.effectId);
  return !!effect && (effect.handlerId === 'destroyTargets' ||
    effect.program?.some((step) => step.kind === 'destroySelected') === true);
}

function linkSearchesDeckToHand(link: ChainLink, catalog: CardCatalog): boolean {
  const effect = effectFromCatalog(catalog, link.effectId);
  if (!effect) return false;
  if (effect.targets?.zones.includes('mainDeck') && effect.program?.some((step) =>
    step.kind === 'moveSelected' && step.to === 'hand')) return true;
  return effect.program?.some((step, index, program) => step.kind === 'selectCards' &&
    step.filter.zones.includes('mainDeck') && program.slice(index + 1).some((next) =>
      next.kind === 'moveSelected' && next.key === step.key && next.to === 'hand')) ?? false;
}

function linkTargetsOwnMonsterForDestruction(state: GameState, link: ChainLink, player: PlayerId,
  catalog: CardCatalog): boolean {
  return link.player !== player && linkDestroysSelectedCard(link, catalog) && link.targetSnapshots.some((snapshot) => {
    const target = state.cards[snapshot.id];
    return target && snapshot.player === player && target.controller === player && target.face === 'up' &&
      (target.location.zone === 'normal' || target.location.zone === 'frontline' || target.location.zone === 'spellCounter');
  });
}

function linkTargetsOwnFieldForDestruction(state: GameState, link: ChainLink, player: PlayerId,
  catalog: CardCatalog): boolean {
  return link.player !== player && linkDestroysSelectedCard(link, catalog) && link.targetSnapshots.some((snapshot) => {
    const target = state.cards[snapshot.id];
    return target && snapshot.player === player && target.controller === player &&
      ['normal', 'frontline', 'spellCounter'].includes(target.location.zone);
  });
}

function linkTargetsOwnField(state: GameState, link: ChainLink, player: PlayerId): boolean {
  return link.player !== player && link.targetSnapshots.some((snapshot) => {
    const target = state.cards[snapshot.id];
    return target && snapshot.player === player && target.controller === player &&
      ['normal', 'frontline', 'spellCounter'].includes(target.location.zone);
  });
}

function timingError(state: GameState, command: ActivateEffectCommand, effect: EffectDefinition,
  speed: EffectSpeed, catalog: CardCatalog): RuleErrorCode | null {
  if (state.result !== null || state.window.kind === 'resolution' || state.window.kind === 'choice' ||
    state.window.priorityPlayer !== command.player) return 'INVALID_EFFECT_TIMING';
  const top = state.chain.at(-1);
  if (top) {
    if (state.window.kind !== 'response' || effect.mode === 'trigger' || effect.mode === 'continuous' ||
      effect.timing === 'summonNegation' || speed === 1) return 'INVALID_EFFECT_TIMING';
    if (state.pendingBattle && !battleTimingAllows(state.pendingBattle.stage, effect.timing)) return 'INVALID_EFFECT_TIMING';
    if (!state.pendingBattle && ['attackDeclaration', 'damageBefore', 'damageCalculation', 'battleEnd'].includes(effect.timing ?? '')) {
      return 'INVALID_EFFECT_TIMING';
    }
    if (command.responseTo !== top.id) return 'INVALID_RESPONSE';
    if (top.speed === 3 && speed !== 3) return 'INVALID_EFFECT_SPEED';
    if (effect.respondsTo && effect.respondsTo !== 'any' && effect.respondsTo !== top.source.kind) return 'INVALID_RESPONSE';
    if (effect.responseTarget === 'opponentEffectSource' &&
      (top.player === command.player || top.source.kind !== 'card' || !command.targetIds?.includes(top.source.instanceId))) {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseTarget === 'opponentGrabbedOwnField' && top.player === command.player) return 'INVALID_RESPONSE';
    const requirement = effect.responseRequirement;
    if (requirement && ['opponentCardEffect', 'opponentMonsterEffect', 'opponentSpellEffect'].includes(requirement.kind)) {
      const sourceCard = top.source.kind === 'card' ? state.cards[top.source.instanceId] : undefined;
      const sourceDefinition = sourceCard && catalog.cards[sourceCard.cardId];
      if (top.player === command.player || !sourceDefinition ||
        requirement.kind === 'opponentMonsterEffect' && sourceDefinition.kind !== 'monster' ||
        requirement.kind === 'opponentSpellEffect' && sourceDefinition.kind !== 'spell') return 'INVALID_RESPONSE';
    }
    if (requirement?.kind === 'opponentGrabbedCard' &&
      (top.player === command.player || top.source.kind !== 'card' ||
        !top.targetSnapshots.some((snapshot) => state.cards[snapshot.id]?.cardId === requirement.cardId))) {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentAttack' &&
      (!state.pendingBattle || state.pendingBattle.player === command.player || state.pendingBattle.stage !== 'attackDeclaration' ||
        effect.targets && effect.targets.filter?.side !== 'self' && !command.targetIds?.includes(state.pendingBattle.attackerId))) {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentDirectAttack' &&
      (!state.pendingBattle || state.pendingBattle.player === command.player || state.pendingBattle.stage !== 'attackDeclaration' ||
        state.pendingBattle.target.kind !== 'player')) return 'INVALID_RESPONSE';
    if (effect.responseRequirement?.kind === 'opponentSourceMonsterMaxLevel') {
      const sourceCard = top.source.kind === 'card' ? state.cards[top.source.instanceId] : undefined;
      const sourceDefinition = sourceCard && catalog.cards[sourceCard.cardId];
      if (top.player === command.player || sourceDefinition?.kind !== 'monster' ||
        sourceDefinition.level > effect.responseRequirement.maxLevel) return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentNormalSpellActivation') {
      const sourceCard = top.source.kind === 'card' ? state.cards[top.source.instanceId] : undefined;
      const sourceDefinition = sourceCard && catalog.cards[sourceCard.cardId];
      if (top.player === command.player || sourceDefinition?.kind !== 'spell' ||
        sourceDefinition.spellMode === 'quick' || sourceDefinition.spellMode === 'continuous') return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentDeckSearch' &&
      (top.player === command.player || !linkSearchesDeckToHand(top, catalog))) return 'INVALID_RESPONSE';
    if (effect.responseRequirement?.kind === 'opponentTargetedOwnMonsterForDestruction' &&
      (!linkTargetsOwnMonsterForDestruction(state, top, command.player, catalog) ||
        !command.targetIds?.some((id) => top.targetSnapshots.some((snapshot) => snapshot.id === id && snapshot.player === command.player)))) {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentTargetedOwnFieldForDestruction' &&
      (!linkTargetsOwnFieldForDestruction(state, top, command.player, catalog) ||
        !command.targetIds?.some((id) => top.targetSnapshots.some((snapshot) => snapshot.id === id && snapshot.player === command.player)))) {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentTargetedOwnField' &&
      !linkTargetsOwnField(state, top, command.player)) return 'INVALID_RESPONSE';
    const responseRequirement = effect.responseRequirement;
    if (responseRequirement?.kind === 'opponentTargetedOwnArchetypeMonster' &&
      (top.player === command.player || !top.targetSnapshots.some((snapshot) => {
        const card = state.cards[snapshot.id];
        const definition = card && catalog.cards[card.cardId];
        return snapshot.player === command.player && ['normal', 'frontline'].includes(snapshot.zone) &&
          definition?.kind === 'monster' && definition.archetypeIds?.includes(responseRequirement.archetypeId);
      }))) return 'INVALID_RESPONSE';
    if (responseRequirement?.kind === 'opponentRespondedToOwnArchetype') {
      const base = top.responseTo ? state.chain.find((candidate) => candidate.id === top.responseTo) : undefined;
      const baseCard = base?.source.kind === 'card' ? state.cards[base.source.instanceId] : undefined;
      const baseDefinition = baseCard && catalog.cards[baseCard.cardId];
      if (top.player === command.player || !base || base.player !== command.player ||
        !baseDefinition?.archetypeIds?.includes(responseRequirement.archetypeId)) return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentEffectDestroysAtLeast' &&
      (top.player === command.player || !linkDestroysSelectedCard(top, catalog) ||
        new Set(top.targetSnapshots.filter((snapshot) => ['normal', 'frontline', 'spellCounter'].includes(snapshot.zone))
          .map((snapshot) => snapshot.id)).size < effect.responseRequirement.count)) return 'INVALID_RESPONSE';
    return null;
  }
  if (state.pendingBattle && state.window.kind === 'response') {
    if ((effect.mode !== 'response' && effect.mode !== 'active') || speed === 1 ||
      command.responseTo !== `battle:${state.pendingBattle.id}` ||
      !battleTimingAllows(state.pendingBattle.stage, effect.timing)) return 'INVALID_EFFECT_TIMING';
    if (effect.respondsTo && effect.respondsTo !== 'any' && effect.respondsTo !== 'card') return 'INVALID_RESPONSE';
    const battleRequirement = effect.responseRequirement?.kind;
    if (battleRequirement && battleRequirement !== 'opponentAttack' && battleRequirement !== 'opponentDirectAttack') {
      return 'INVALID_RESPONSE';
    }
    if (effect.responseRequirement?.kind === 'opponentAttack' &&
      (state.pendingBattle.player === command.player || state.pendingBattle.stage !== 'attackDeclaration' ||
        effect.targets && effect.targets.filter?.side !== 'self' && !command.targetIds?.includes(state.pendingBattle.attackerId))) return 'INVALID_RESPONSE';
    if (effect.responseRequirement?.kind === 'opponentDirectAttack' &&
      (state.pendingBattle.player === command.player || state.pendingBattle.stage !== 'attackDeclaration' ||
        state.pendingBattle.target.kind !== 'player')) return 'INVALID_RESPONSE';
    return null;
  }
  if (!state.pendingBattle && ['attackDeclaration', 'damageBefore', 'damageCalculation', 'battleEnd'].includes(effect.timing ?? '')) {
    return 'INVALID_EFFECT_TIMING';
  }
  if (state.pendingSummon && state.window.kind === 'response') {
    return effect.mode === 'response' && effect.timing === 'summonNegation' &&
      effect.handlerId === 'negateSummon' && speed >= 2 &&
      command.responseTo === `summon:${state.window.id}` ? null : 'INVALID_EFFECT_TIMING';
  }
  if (command.responseTo !== undefined || state.pendingSummon || state.window.kind !== 'open' ||
    effect.mode === 'response' || effect.mode === 'trigger' || effect.mode === 'continuous') return 'INVALID_EFFECT_TIMING';
  if (speed === 1 && (command.player !== state.turnPlayer || (state.phase !== 'main1' && state.phase !== 'main2'))) {
    return 'INVALID_EFFECT_TIMING';
  }
  return null;
}

function selectedTargetSnapshots(state: GameState, player: PlayerId, ids: readonly string[], effect: EffectDefinition,
  catalog: CardCatalog, sourceCardId?: string):
  ChainLink['targetSnapshots'] | null {
  if (effect.targetGroups?.length) {
    if (new Set(ids).size !== ids.length || ids.some((id) => id === sourceCardId)) return null;
    let remaining = [...ids];
    for (const group of effect.targetGroups) {
      const matches = remaining.filter((id) => {
        const card = state.cards[id];
        return !!card && group.zones.includes(card.location.zone) && (!group.filter ||
          matchingEffectCards(state, player, group.filter, catalog, sourceCardId).includes(id));
      });
      if (matches.length < group.min || matches.length > group.max) return null;
      remaining = remaining.filter((id) => !matches.includes(id));
    }
    if (remaining.length > 0 || ids.length !== effect.targetGroups.reduce((count, group) => count + group.min, 0)) return null;
  } else if (!effect.targets) return ids.length === 0 ? [] : null;
  else if (ids.length < effect.targets.min || ids.length > effect.targets.max || new Set(ids).size !== ids.length ||
    effect.targets.excludeSource && sourceCardId && ids.includes(sourceCardId)) return null;
  const snapshots: { id: string; player: PlayerId; zone: CardInstance['location']['zone']; zoneEntrySequence: number }[] = [];
  for (const id of ids) {
    const card = Object.hasOwn(state.cards, id) ? state.cards[id] : undefined;
    if (!card || effect.targetGroups?.length && !effect.targetGroups.some((group) =>
      group.zones.includes(card.location.zone) && (!group.filter ||
        matchingEffectCards(state, player, group.filter, catalog, sourceCardId).includes(id))) ||
      !effect.targetGroups?.length && effect.targets && (!effect.targets.zones.includes(card.location.zone) ||
        effect.targets.filter && !matchingEffectCards(state, player, effect.targets.filter, catalog, sourceCardId).includes(id))) return null;
    snapshots.push({ id, player: card.location.player, zone: card.location.zone,
      zoneEntrySequence: card.zoneEntrySequence });
  }
  return snapshots;
}

function targetSnapshots(state: GameState, command: ActivateEffectCommand, effect: EffectDefinition, catalog: CardCatalog):
  ChainLink['targetSnapshots'] | null {
  return selectedTargetSnapshots(state, command.player, command.targetIds ?? [], effect, catalog,
    command.source.kind === 'card' ? command.source.instanceId : undefined);
}

/** The only command path for card and skill effect activation. */
export function appendChainLink(state: GameState, incoming: ActivateEffectCommand, catalog: CardCatalog): CommandResult {
  const command = canonicalCommandSelections(incoming) as ActivateEffectCommand;
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (Object.hasOwn(command, 'authorizedMaterialIds')) return rejected(state, 'INVALID_MATERIAL');
  const effect = effectFromCatalog(catalog, command.effectId);
  if (!effect) return rejected(state, 'UNKNOWN_EFFECT');
  const source = sourceInfo(state, command, catalog, effect);
  if (typeof source === 'string') return rejected(state, source);
  const selfSummon = effect.program?.find((step) => step.kind === 'summonSelf');
  if (source.card && selfSummon) {
    const allowedSourceZones = typeof selfSummon.from === 'string' ? [selfSummon.from] : selfSummon.from;
    if (!allowedSourceZones.includes(source.card.location.zone)) return rejected(state, 'INVALID_EFFECT_SOURCE');
    if (state.players[command.player].zones[selfSummon.to].every((id) => id !== null)) {
      return rejected(state, 'INVALID_EFFECT_TIMING');
    }
  }
  if (!conditionMatches(state, command.player, effect)) {
    return rejected(state, 'INVALID_EFFECT_TIMING');
  }
  if (!meetsEffectActivationRequirements(state, command.player, effect, catalog,
    command.source.kind === 'card' ? command.source.instanceId : undefined)) return rejected(state, 'INVALID_EFFECT_TIMING');
  const timing = timingError(state, command, effect, source.speed, catalog);
  if (timing) return rejected(state, timing);
  const top = state.chain.at(-1);
  if (command.source.kind === 'skill' && top && state.chain.some((link) => link.player === command.player &&
    link.source.kind === 'skill' && link.sourceName === source.name && link.responseTo === command.responseTo)) {
    return rejected(state, 'SKILL_DUPLICATE_RESPONSE');
  }
  const tpCost = source.card ? effectTpCost(source.cardDefinition!.level) : 0;
  if (tpCost === null) return rejected(state, 'INVALID_COST');
  if (source.card && state.players[command.player].tp < tpCost) return rejected(state, 'INSUFFICIENT_TP');
  const payment = validateEffectPayment(state, command.player, effect,
    source.card ? source.cardDefinition!.level : null, command.costCardId, command.resourceCostCardId, catalog);
  if (!payment) {
    if (source.card && state.players[command.player].tp < tpCost) return rejected(state, 'INSUFFICIENT_TP');
    return rejected(state, 'INVALID_COST');
  }
  if (effect.cost?.mustBeSource && (command.source.kind !== 'card' || command.costCardId !== command.source.instanceId)) {
    return rejected(state, 'INVALID_COST');
  }
  if (effect.cost?.excludeSource && command.source.kind === 'card' && command.costCardId === command.source.instanceId) {
    return rejected(state, 'INVALID_COST');
  }
  if (effect.handlerId === 'effectSummonTerminal') {
    if (!command.terminalId || !command.materialIds) return rejected(state, 'INVALID_SUMMON');
    const authorizedMaterialIds = deriveAuthorizedMaterials(state, command.player, command.materialIds, effect);
    if (!authorizedMaterialIds) return rejected(state, 'INVALID_MATERIAL');
    const check = canEffectSummonTerminal(state, { player: command.player, terminalId: command.terminalId,
      materialIds: command.materialIds, authorizedMaterialIds, zone: command.terminalZone, slot: command.terminalSlot }, catalog);
    if (!check.ok) return rejected(state, check.error.code);
  } else if (command.terminalId || command.materialIds || command.terminalZone || command.terminalSlot) return rejected(state, 'INVALID_SUMMON');
  if (effect.fieldMark) {
    const slot = command.fieldMarkSlot;
    if (slot === undefined || !Number.isInteger(slot) || state.players[command.player].zones.normal[slot] !== null ||
      state.fieldMarks?.[command.player]?.[slot]) return rejected(state, 'INVALID_TARGET');
  } else if (command.fieldMarkSlot !== undefined) return rejected(state, 'INVALID_TARGET');
  if (effect.battleReward && state.battleRewards?.[command.player]) return rejected(state, 'INVALID_EFFECT_TIMING');
  if (source.card && source.cardDefinition?.kind === 'spell' && source.card.location.zone === 'hand' &&
    state.players[command.player].zones.spellCounter.every((id) => id !== null)) return rejected(state, 'ZONE_FULL');
  if (source.card && effect.oncePerName !== 'unlimited' &&
    hasEffectActivation(state, command.player, source.name, effect.effectIndex ?? 1, effect.cooldownTurns ?? 1)) return rejected(state, 'NAME_ALREADY_ACTIVATED');
  if (matchEffectWasUsed(state, command.player, source.name, effect)) return rejected(state, 'NAME_ALREADY_ACTIVATED');

  let next = state;
  const events: GameEvent[] = [];
  if (source.card && source.cardDefinition?.kind === 'spell' && source.card.location.zone === 'hand') {
    const moved = moveCard(next, { cardId: source.card.id, actor: command.player, reason: 'effect', catalog,
      destination: { player: command.player, zone: 'spellCounter' }, face: 'up' });
    if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
    next = recordTriggerEvents(moved.state, moved.events, catalog);
    events.push(...moved.events);
  } else if (source.card && (source.cardDefinition?.kind === 'spell' || source.cardDefinition?.kind === 'counter') &&
    source.card.location.zone === 'spellCounter' && source.card.face === 'down') {
    const flipped = moveCard(next, { cardId: source.card.id, actor: command.player, reason: 'effect', catalog,
      destination: source.card.location, face: 'up' });
    if (flipped.status !== 'moved') return rejected(state, 'MOVE_FAILED');
    next = recordTriggerEvents(flipped.state, flipped.events, catalog);
    events.push(...flipped.events);
  }
  if (effect.cost) {
    const card = next.cards[command.costCardId!]!;
    const paid = moveCard(next, { cardId: command.costCardId!, actor: command.player, reason: effect.cost.kind, catalog,
      ...(effect.cost.destination ? { destination: { player: card.owner, zone: effect.cost.destination } } : {}) });
    if (paid.status !== 'moved' || effect.cost.destination && paid.state.cards[command.costCardId!]!.location.zone !== effect.cost.destination) {
      return rejected(state, 'INVALID_COST');
    }
    next = recordTriggerEvents(paid.state, paid.events, catalog);
    events.push(...paid.events);
  }
  const paid = payEffectCosts(next, command.player, payment, catalog);
  if (!paid) return rejected(state, 'INVALID_COST');
  next = recordTriggerEvents(paid.state, paid.events, catalog);
  events.push(...paid.events);
  const targets = targetSnapshots(next, command, effect, catalog);
  if (!targets) return rejected(state, 'INVALID_TARGET');
  if (effect.handlerId === 'effectSummonTerminal') {
    const authorizedMaterialIds = deriveAuthorizedMaterials(next, command.player, command.materialIds!, effect);
    if (!authorizedMaterialIds) return rejected(state, 'INVALID_MATERIAL');
    const check = canEffectSummonTerminal(next, { player: command.player, terminalId: command.terminalId!,
      materialIds: command.materialIds!, authorizedMaterialIds }, catalog);
    if (!check.ok) return rejected(state, check.error.code);
  }
  if (command.source.kind === 'skill') next = consumeSkillCopy(next, command.player, command.source.copyId);
  else if (effect.oncePerName !== 'unlimited') {
    const consumed = consumeEffectActivation(next, command.player, source.name, effect.effectIndex ?? 1, effect.cooldownTurns ?? 1);
    if (!consumed.ok) return rejected(state, consumed.error.code);
    next = consumed.state;
  }
  next = consumeMatchEffect(next, command.player, source.name, effect);
  if (command.source.kind === 'card') next = lockOtherMainMonsterEffects(next, command.player, command.source.instanceId, effect);
  const sequence = next.eventSequence + 1;
  const sourceVisibility = command.source.kind === 'skill' ? command.player :
    cardIdentityVisibility(next.cards[command.source.instanceId], command.player);
  const respondingTo = effect.program?.some((step) => step.kind === 'sendResponseSourceToHeaven')
    ? next.chain.find((item) => item.id === command.responseTo) : undefined;
  const responseCard = respondingTo?.source.kind === 'card' ? next.cards[respondingTo.source.instanceId] : undefined;
  const link: ChainLink = {
    id: `link:${sequence}`, player: command.player, source: command.source, sourceName: source.name,
    effectId: effect.id, sourceVisibility, speed: source.speed,
    ...(command.responseTo ? { responseTo: command.responseTo } : {}),
    ...(responseCard ? { responseSourceSnapshot: { id: responseCard.id, player: responseCard.location.player,
      zone: responseCard.location.zone, zoneEntrySequence: responseCard.zoneEntrySequence } } : {}),
    targetSnapshots: targets,
    ...(command.costCardId ? { costCardId: command.costCardId } : {}),
    ...(command.resourceCostCardId ? { resourceCostCardId: command.resourceCostCardId } : {}),
    tpCost: payment.tp,
    payment: { tp: payment.tp, life: payment.life },
    ...(command.terminalId ? { terminalId: command.terminalId } : {}),
    ...(command.materialIds ? { materialIds: [...command.materialIds] } : {}),
    ...(command.terminalZone ? { terminalZone: command.terminalZone } : {}),
    ...(command.terminalSlot !== undefined ? { terminalSlot: command.terminalSlot } : {}),
    ...(command.fieldMarkSlot !== undefined ? { fieldMarkSlot: command.fieldMarkSlot } : {}),
    activationNegated: false, effectNegated: false,
  };
  const selectionMode = effect.selectionMode ?? (effect.targets ? 'grab'
    : effect.program?.some((step) => step.kind === 'selectCards' || step.kind === 'resolveSelect') ? 'noGrab' : 'none');
  const event: EffectActivatedEvent = { type: 'effectActivated', sequence, linkId: link.id,
    effectId: effect.id, player: command.player,
    sourceId: command.source.kind === 'card' ? command.source.instanceId : command.source.copyId,
    sourceKind: command.source.kind,
    sourceVisibility, selectionMode };
  const activatedCounters = currentTurnCounters(next, command.player);
  const counters = command.source.kind === 'card' ? { ...next.counters,
    [command.player]: { ...activatedCounters, activatedCardIds: activatedCounters.activatedCardIds.includes(command.source.instanceId)
      ? activatedCounters.activatedCardIds : [...activatedCounters.activatedCardIds, command.source.instanceId] },
  } : next.counters;
  const operationEvent: RuleOperationEvent | undefined = selectionMode === 'none' ? undefined : {
    type: 'ruleOperation', sequence: sequence + 1, operationId: selectionMode === 'grab' ? 'grab' : 'no_grab',
    player: command.player, effectId: effect.id, linkId: link.id,
    ...(command.source.kind === 'card' ? { cardId: command.source.instanceId, identityVisibility: sourceVisibility } : {}),
  };
  const activationEvents: GameEvent[] = operationEvent ? [event, operationEvent] : [event];
  next = recordTriggerEvents({ ...next, counters, eventSequence: operationEvent?.sequence ?? sequence }, activationEvents, catalog);
  return accepted({ ...next, chain: [...next.chain, link], responsePasses: 0,
    window: { kind: 'response', priorityPlayer: otherPlayer(command.player), id: state.window.id + 1 },
  }, [...events, ...activationEvents]);
}

export function orderSimultaneousTriggers(state: GameState, candidates: readonly TriggerCandidate[],
  choices?: Partial<Record<PlayerId, readonly string[]>>): readonly TriggerCandidate[] {
  const rank = (item: TriggerCandidate): number => (item.player === state.turnPlayer ? 0 : 1) + (item.mandatory ? 0 : 2);
  return [...candidates].sort((a, b) => {
    const group = rank(a) - rank(b);
    if (group !== 0) return group;
    const selected = choices?.[a.player];
    if (selected) {
      const ai = selected.indexOf(a.id);
      const bi = selected.indexOf(b.id);
      if (ai >= 0 && bi >= 0) return ai - bi;
    }
    return candidates.indexOf(a) - candidates.indexOf(b);
  });
}

function collectTriggers(state: GameState, events: readonly GameEvent[], catalog: CardCatalog): readonly TriggerCandidate[] {
  const candidates: TriggerCandidate[] = [];
  for (const event of events) {
    for (const card of Object.values(state.cards)) {
      const source = cardDefinition(catalog, card);
      if (!source || card.flags.includes('effectsNegated') ||
        card.effectsDisabledUntilTurn !== undefined && card.effectsDisabledUntilTurn >= state.globalTurn ||
        mainMonsterEffectBlocked(state, card.controller, card.id, source) ||
        isKeywordStatusActive(state, card.id, 'freeze')) continue;
      for (const effectId of source.effectIds ?? []) {
        const effect = effectFromCatalog(catalog, effectId);
        const setCounterTrigger = effect?.triggerFromSet === true && source.kind === 'counter' &&
          card.location.zone === 'spellCounter' && card.face === 'down' && card.setOnTurn !== null &&
          card.setOnTurn < state.globalTurn;
        if (!effect || effect.source !== 'card' || effect.mode !== 'trigger' ||
          effect.triggerEvent !== event.type || !effect.allowedZones.includes(card.location.zone) ||
          effect.triggerMove && (event.type !== 'cardMoved' || !effect.triggerMove.from.includes(event.from.zone) ||
            effect.triggerMove.to !== event.to.zone ||
            (effect.triggerMove.actor === 'any' ? false : effect.triggerMove.actor === 'opponent' ? event.actor === card.controller :
              effect.triggerMove.actor === 'opponentOrBattle' ? event.actor === card.controller && event.destructionCause !== 'battle' :
                event.actor !== card.controller) ||
            effect.triggerMove.reasons && !effect.triggerMove.reasons.includes(event.reason as 'effect' | 'send' | 'destroy')) ||
          effect.triggerMethods && (!('method' in event) || !effect.triggerMethods.includes(event.method as NonNullable<typeof effect.triggerMethods>[number])) ||
          (card.location.zone === 'normal' || card.location.zone === 'frontline' || card.location.zone === 'spellCounter') &&
            card.face !== 'up' && !setCounterTrigger ||
          effect.triggerRequirement === 'opponentMonsterSummoned' &&
            (event.type !== 'monsterSummoned' || event.player === card.controller) ||
          effect.triggerRequirement === 'selfTributeSummoned' &&
            (event.type !== 'monsterSummoned' || event.cardId !== card.id || event.player !== card.controller ||
              (event.tributeCount ?? 0) < 1) ||
          effect.triggerRequirement === 'selfTributeMaterial' &&
            (event.type !== 'monsterSummoned' || event.player !== card.controller ||
              !event.tributeMaterialIds?.includes(card.id) ||
              effect.triggerSummonedArchetypeId !== undefined &&
                !catalog.cards[event.cardId === undefined ? '' : state.cards[event.cardId]?.cardId ?? '']?.archetypeIds?.includes(effect.triggerSummonedArchetypeId)) ||
          effect.triggerSource === 'self' && (!('cardId' in event) || event.cardId !== card.id)) continue;
        const player = card.location.zone === 'normal' || card.location.zone === 'frontline' || card.location.zone === 'spellCounter'
          ? card.controller : card.owner;
        if (!conditionMatches(state, player, effect) || !meetsEffectActivationRequirements(state, player, effect, catalog, card.id) ||
          effect.oncePerName !== 'unlimited' && hasEffectActivation(state, player, source.name, effect.effectIndex ?? 1, effect.cooldownTurns ?? 1) ||
          matchEffectWasUsed(state, player, source.name, effect)) continue;
        candidates.push({ id: `trigger:${event.sequence}:${card.id}:${effect.id}`, player,
          mandatory: effect.mandatory === true, eventSequence: event.sequence,
          sourceId: card.id, effectId: effect.id,
          sourceLocation: { player: card.location.player, zone: card.location.zone,
            zoneEntrySequence: card.zoneEntrySequence },
          ...(effect.triggerTarget === 'eventCard' && 'cardId' in event ? { eventCardId: event.cardId } : {}) });
      }
    }
  }
  return orderSimultaneousTriggers(state, candidates);
}

/** Capture at the event boundary; a later link cannot erase a trigger already caused. */
export function recordTriggerEvents(state: GameState, events: readonly GameEvent[], catalog: CardCatalog): GameState {
  let observedThrough = state.triggerObservedThrough ?? 0;
  const candidates: TriggerCandidate[] = [];
  for (const event of events) {
    if (event.sequence <= observedThrough) continue;
    candidates.push(...collectTriggers(state, [event], catalog));
    observedThrough = event.sequence;
  }
  return observedThrough === (state.triggerObservedThrough ?? 0) ? state : {
    ...state, triggerObservedThrough: observedThrough,
    pendingTriggers: [...state.pendingTriggers, ...candidates],
  };
}

function triggerChoiceValid(state: GameState, candidate: TriggerCandidate, choice: TriggerChoice,
  catalog: CardCatalog): boolean {
  const effect = effectFromCatalog(catalog, candidate.effectId);
  if (!effect || effect.mode !== 'trigger' || choice.triggerId !== candidate.id) return false;
  if (effect.triggerTarget === 'eventCard' && (!candidate.eventCardId || choice.targetIds?.length !== 1 ||
    choice.targetIds[0] !== candidate.eventCardId)) return false;
  if (effect.triggerTarget !== 'eventCard' && candidate.eventCardId && choice.targetIds?.includes(candidate.eventCardId)) return false;
  if (effect.cost) {
    const cost = choice.costCardId && Object.hasOwn(state.cards, choice.costCardId) ? state.cards[choice.costCardId] : undefined;
    if (!cost || effect.cost.mustBeSource && candidate.sourceId !== choice.costCardId ||
      !canSelectEffectCostCard(state, candidate.player, effect, cost.id, catalog)) return false;
  } else if (choice.costCardId) return false;
  if (effect.resourceCost) {
    const resource = choice.resourceCostCardId ? state.cards[choice.resourceCostCardId] : undefined;
    const definition = resource && catalog.cards[resource.cardId];
    if (!resource || resource.location.zone !== effect.resourceCost.zone || resource.owner !== candidate.player ||
      resource.location.player !== candidate.player || effect.resourceCost.filter?.archetypeId !== undefined &&
        !definition?.archetypeIds?.includes(effect.resourceCost.filter.archetypeId)) return false;
  } else if (choice.resourceCostCardId) return false;
  if (!selectedTargetSnapshots(state, candidate.player, choice.targetIds ?? [], effect, catalog, candidate.sourceId) ||
    choice.targetIds?.includes(choice.costCardId ?? '') ||
    choice.targetIds?.includes(choice.resourceCostCardId ?? '')) return false;
  if (effect.handlerId === 'effectSummonTerminal') {
    if (!choice.terminalId || !choice.materialIds) return false;
    const authorizedMaterialIds = deriveAuthorizedMaterials(state, candidate.player, choice.materialIds, effect);
    return authorizedMaterialIds !== null && canEffectSummonTerminal(state, {
      player: candidate.player, terminalId: choice.terminalId, materialIds: choice.materialIds,
      authorizedMaterialIds, zone: choice.terminalZone, slot: choice.terminalSlot,
    }, catalog).ok;
  }
  return !choice.terminalId && !choice.materialIds;
}

function mandatoryPaymentUnavailable(state: GameState, candidate: TriggerCandidate,
  effect: EffectDefinition, level: number, catalog: CardCatalog): boolean {
  const tp = effectTpCost(level);
  if (tp === null || state.players[candidate.player].tp < tp ||
    effectLifeCost(effect, state.players[candidate.player].life) === null) return true;
  if (effect.cost && !Object.values(state.cards).some((card) =>
    canSelectEffectCostCard(state, candidate.player, effect, card.id, catalog))) return true;
  if (effect.resourceCost && state.players[candidate.player].zones[effect.resourceCost.zone].length === 0) return true;
  return false;
}

function establishTriggerChain(state: GameState, candidates: readonly TriggerCandidate[], catalog: CardCatalog,
  choices: readonly TriggerChoice[] = []): CommandResult {
  let next: GameState = { ...state, pendingTriggers: [], triggerSelections: {} };
  const events: GameEvent[] = [];
  const chain: ChainLink[] = [];
  const selected = new Map(choices.map((choice) => [choice.triggerId, choice]));
  for (const candidate of orderSimultaneousTriggers(state, candidates)) {
    const card = Object.hasOwn(next.cards, candidate.sourceId) ? next.cards[candidate.sourceId] : undefined;
    const source = card ? cardDefinition(catalog, card) : undefined;
    const effect = effectFromCatalog(catalog, candidate.effectId);
    const choice = selected.get(candidate.id) ?? { triggerId: candidate.id };
    if (!card || !source || !effect || effect.mode !== 'trigger' || !source.effectIds?.includes(effect.id) ||
      !candidate.sourceLocation || !effect.allowedZones.includes(candidate.sourceLocation.zone)) {
      return rejected(state, 'INVALID_TRIGGER_CHOICE');
    }
    if (isKeywordStatusActive(next, card.id, 'freeze')) continue;
    if (!conditionMatches(next, candidate.player, effect) || !meetsEffectActivationRequirements(next, candidate.player, effect, catalog) ||
      effect.oncePerName !== 'unlimited' && hasEffectActivation(next, candidate.player, source.name, effect.effectIndex ?? 1, effect.cooldownTurns ?? 1)) {
      continue;
    }
    if (matchEffectWasUsed(next, candidate.player, source.name, effect)) continue;
    if (candidate.mandatory && mandatoryPaymentUnavailable(next, candidate, effect, source.level, catalog)) continue;
    if (!triggerChoiceValid(next, candidate, choice, catalog)) return rejected(state, 'INVALID_TRIGGER_CHOICE');
    const currentSource = next.cards[card.id];
    if (currentSource?.face === 'down' && effect.triggerFromSet && currentSource.location.zone === 'spellCounter') {
      const revealed = moveCard(next, { cardId: card.id, actor: candidate.player, reason: 'effect', catalog,
        destination: currentSource.location, face: 'up' });
      if (revealed.status !== 'moved') return rejected(state, 'INVALID_TRIGGER_CHOICE');
      next = recordTriggerEvents(revealed.state, revealed.events, catalog);
      events.push(...revealed.events);
    }
    const payment = validateEffectPayment(next, candidate.player, effect, source.level,
      choice.costCardId, choice.resourceCostCardId, catalog);
    if (!payment) {
      if (candidate.mandatory) continue;
      const tpCost = effectTpCost(source.level);
      if (tpCost !== null && next.players[candidate.player].tp < tpCost) return rejected(state, 'INSUFFICIENT_TP');
      return rejected(state, 'INVALID_TRIGGER_CHOICE');
    }
    if (effect.cost) {
      const card = next.cards[choice.costCardId!]!;
      const paid = moveCard(next, { cardId: choice.costCardId!, actor: candidate.player, reason: effect.cost.kind, catalog,
        ...(effect.cost.destination ? { destination: { player: card.owner, zone: effect.cost.destination } } : {}) });
      if (paid.status !== 'moved' || effect.cost.destination && paid.state.cards[choice.costCardId!]!.location.zone !== effect.cost.destination) {
        return rejected(state, 'INVALID_TRIGGER_CHOICE');
      }
      next = recordTriggerEvents(paid.state, paid.events, catalog);
      events.push(...paid.events);
    }
    const paid = payEffectCosts(next, candidate.player, payment, catalog);
    if (!paid) return rejected(state, 'INVALID_TRIGGER_CHOICE');
    next = recordTriggerEvents(paid.state, paid.events, catalog);
    events.push(...paid.events);
    if (effect.handlerId === 'effectSummonTerminal') {
      const authorizedMaterialIds = deriveAuthorizedMaterials(next, candidate.player, choice.materialIds!, effect);
      if (!authorizedMaterialIds || !canEffectSummonTerminal(next, { player: candidate.player,
        terminalId: choice.terminalId!, materialIds: choice.materialIds!, authorizedMaterialIds,
        zone: choice.terminalZone, slot: choice.terminalSlot }, catalog).ok) {
        return rejected(state, 'INVALID_TRIGGER_CHOICE');
      }
    }
    const snapshots = selectedTargetSnapshots(next, candidate.player, choice.targetIds ?? [], effect, catalog, candidate.sourceId);
    if (!snapshots) return rejected(state, 'INVALID_TRIGGER_CHOICE');
    if (effect.oncePerName !== 'unlimited') {
      const counted = consumeEffectActivation(next, candidate.player, source.name, effect.effectIndex ?? 1, effect.cooldownTurns ?? 1);
      if (!counted.ok) return rejected(state, counted.error.code);
      next = counted.state;
    }
    next = consumeMatchEffect(next, candidate.player, source.name, effect);
    next = lockOtherMainMonsterEffects(next, candidate.player, card.id, effect);
    const sequence = next.eventSequence + 1;
    const sourceVisibility = cardIdentityVisibility(next.cards[card.id], candidate.player);
    const link: ChainLink = { id: `link:${sequence}`, player: candidate.player,
      source: { kind: 'card', instanceId: card.id }, sourceName: source.name,
      effectId: effect.id, sourceVisibility, speed: effect.speed, targetSnapshots: snapshots,
      ...(choice.costCardId ? { costCardId: choice.costCardId } : {}),
      ...(choice.resourceCostCardId ? { resourceCostCardId: choice.resourceCostCardId } : {}),
      tpCost: payment.tp,
      payment: { tp: payment.tp, life: payment.life },
      ...(choice.terminalId ? { terminalId: choice.terminalId } : {}),
      ...(choice.materialIds ? { materialIds: [...choice.materialIds] } : {}),
      ...(choice.terminalZone ? { terminalZone: choice.terminalZone } : {}),
      ...(choice.terminalSlot !== undefined ? { terminalSlot: choice.terminalSlot } : {}),
      triggerOrigin: candidate.sourceLocation,
      activationNegated: false, effectNegated: false };
    const event: EffectActivatedEvent = { type: 'effectActivated', sequence, linkId: link.id,
      effectId: effect.id, player: candidate.player, sourceId: card.id, sourceKind: 'card',
      sourceVisibility, selectionMode: effect.selectionMode ?? (effect.targets ? 'grab'
        : effect.program?.some((step) => step.kind === 'selectCards' || step.kind === 'resolveSelect') ? 'noGrab' : 'none') };
    const activationCounters = currentTurnCounters(next, candidate.player);
    next = recordTriggerEvents({ ...next, eventSequence: sequence, counters: { ...next.counters,
      [candidate.player]: { ...activationCounters, activatedCardIds: activationCounters.activatedCardIds.includes(card.id)
        ? activationCounters.activatedCardIds : [...activationCounters.activatedCardIds, card.id] },
    } }, [event], catalog);
    chain.push(link);
    events.push(event);
  }
  if (chain.length === 0) return accepted({ ...next, chain: [], window: {
    kind: 'open', priorityPlayer: next.turnPlayer, id: next.window.id + 1,
  } }, events);
  return accepted({ ...next, chain, responsePasses: 0, window: {
    kind: 'response', priorityPlayer: otherPlayer(chain.at(-1)!.player), id: next.window.id + 1,
  } }, events);
}

export function chooseTriggers(state: GameState, incoming: ChooseTriggersCommand, catalog: CardCatalog): CommandResult {
  const command = canonicalCommandSelections(incoming) as ChooseTriggersCommand;
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (state.window.kind !== 'choice' || state.window.priorityPlayer !== command.player ||
    state.pendingTriggers.length === 0) return rejected(state, 'INVALID_TRIGGER_CHOICE');
  const own = state.pendingTriggers.filter((item) => item.player === command.player);
  const selected = new Set(command.orderedTriggerIds);
  if (selected.size !== command.orderedTriggerIds.length ||
    command.orderedTriggerIds.some((id) => !own.some((item) => item.id === id)) ||
    own.some((item) => item.mandatory && !isKeywordStatusActive(state, item.sourceId, 'freeze') && !selected.has(item.id))) {
    return rejected(state, 'INVALID_TRIGGER_CHOICE');
  }
  const supplied = command.choices ?? [];
  if (new Set(supplied.map((choice) => choice.triggerId)).size !== supplied.length ||
    supplied.some((choice) => !selected.has(choice.triggerId))) return rejected(state, 'INVALID_TRIGGER_CHOICE');
  const ownChoices = command.orderedTriggerIds.map((id) => supplied.find((choice) => choice.triggerId === id) ?? { triggerId: id });
  const seenEffects = new Set(currentTurnCounters(state, command.player).activatedEffects);
  const orderedOwn = orderSimultaneousTriggers(state,
    command.orderedTriggerIds.map((id) => own.find((item) => item.id === id)!));
  for (const candidate of orderedOwn) {
    const card = Object.hasOwn(state.cards, candidate.sourceId) ? state.cards[candidate.sourceId] : undefined;
    const source = card ? cardDefinition(catalog, card) : undefined;
    const effect = effectFromCatalog(catalog, candidate.effectId);
    if (!source || !effect) return rejected(state, 'INVALID_TRIGGER_CHOICE');
    if (isKeywordStatusActive(state, candidate.sourceId, 'freeze')) continue;
    const activationKey = effectActivationKey(source.name, effect.effectIndex ?? 1);
    if (!conditionMatches(state, command.player, effect) || !meetsEffectActivationRequirements(state, command.player, effect, catalog) ||
      effect.oncePerName !== 'unlimited' && seenEffects.has(activationKey)) continue;
    const choice = ownChoices.find((item) => item.triggerId === candidate.id)!;
    if (candidate.mandatory && mandatoryPaymentUnavailable(state, candidate, effect, source.level, catalog)) continue;
    if (!triggerChoiceValid(state, candidate, choice, catalog)) return rejected(state, 'INVALID_TRIGGER_CHOICE');
    if (effect.oncePerName !== 'unlimited') seenEffects.add(activationKey);
  }
  if (command.player === state.turnPlayer) {
    const paymentPreview = establishTriggerChain(state, orderedOwn, catalog, ownChoices);
    if (!paymentPreview.ok && paymentPreview.error.code === 'INSUFFICIENT_TP') {
      return rejected(state, paymentPreview.error.code);
    }
  }
  const selections = { ...state.triggerSelections, [command.player]: ownChoices };
  if (command.player === state.turnPlayer) return accepted({ ...state, triggerSelections: selections,
    window: { kind: 'choice', priorityPlayer: otherPlayer(command.player), id: state.window.id + 1 },
  }, []);
  const choices = [...(selections[state.turnPlayer] ?? []), ...(selections[otherPlayer(state.turnPlayer)] ?? [])];
  const candidates = choices.map((choice) => state.pendingTriggers.find((item) => item.id === choice.triggerId)!).filter(Boolean);
  return establishTriggerChain(state, candidates, catalog, choices);
}

export function finalizeTriggerQueue(state: GameState, catalog: CardCatalog): CommandResult {
  const triggers = state.pendingTriggers;
  if (triggers.length === 0 || state.chain.length > 0 || state.pendingSummon || state.result !== null) return accepted(state, []);
  if (triggers.length === 1 && triggers[0]!.mandatory) {
    const effect = effectFromCatalog(catalog, triggers[0]!.effectId);
    if (effect && !effect.cost && !effect.lifeCost && !effect.resourceCost && !effect.targets && effect.handlerId !== 'effectSummonTerminal') {
      return establishTriggerChain(state, triggers, catalog);
    }
  }
  return accepted({ ...state, triggerSelections: {}, window: {
    kind: 'choice', priorityPlayer: state.turnPlayer, id: state.window.id + 1,
  } }, []);
}

export type ResolutionResult = CommandResult;

function resolveLinks(state: GameState, catalog: CardCatalog, linksInput: readonly ChainLink[], startIndex: number,
  startingSummonNegated: boolean, resume?: { readonly stepIndex: number;
    readonly context: Readonly<Record<string, readonly ResolutionSelection[]>>;
    readonly successes: Readonly<Record<string, boolean>>; readonly applied: boolean }): ResolutionResult {
  const links = [...linksInput];
  let next: GameState = state.pendingResolution ? state : {
    ...state, window: { kind: 'resolution', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
  };
  const events: GameEvent[] = [];
  let summonNegated = startingSummonNegated;
  for (let index = startIndex; index >= 0; index--) {
    const eventStart = events.length;
    const link = links[index]!;
    const effect = effectFromCatalog(catalog, link.effectId);
    if (!effect) return rejected(state, 'UNKNOWN_EFFECT');
    let outcome: EffectResolvedEvent['outcome'] = 'noResult';
    if (link.activationNegated) {
      outcome = 'activationNegated';
      const failed = failNegatedKeywordOperations(next, link, effect, 'activation-negated');
      next = failed.state;
      events.push(...failed.events);
    } else if (link.effectNegated) {
      outcome = 'effectNegated';
      const failed = failNegatedKeywordOperations(next, link, effect, 'effect-negated');
      next = failed.state;
      events.push(...failed.events);
    }
    else {
      const applied = applyNamedEffect(next, link, effect, catalog,
        (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog),
        index === startIndex && resume ? resume : undefined);
      next = applied.state;
      events.push(...applied.events);
      outcome = applied.applied ? 'applied' : 'noResult';
      if (applied.choice) {
        const choice = applied.choice;
        next = { ...next, pendingResolution: {
          player: choice.player ?? link.player, links, linkIndex: index, summonNegated,
          stepIndex: choice.stepIndex, context: choice.context, successes: choice.successes,
          key: choice.key, candidates: choice.candidates, filter: choice.filter,
          ...(choice.alsoFilterWhenFaceUp ? { alsoFilterWhenFaceUp: choice.alsoFilterWhenFaceUp } : {}),
          minimum: choice.minimum, maximum: choice.maximum,
          ...(choice.destinations ? { destinations: choice.destinations } : {}),
          ...(choice.resumeCurrentStep ? { resumeCurrentStep: true } : {}),
          selected: [], applied: choice.applied,
        }, window: { kind: 'choice', priorityPlayer: choice.player ?? link.player, id: next.window.id + 1 } };
        return accepted(next, events);
      }
      if (applied.negation === 'summon' && next.pendingSummon) summonNegated = true;
      if (applied.negation && applied.negation !== 'summon' && link.responseTo) {
        const targetIndex = links.findIndex((candidate) => candidate.id === link.responseTo);
        if (targetIndex >= 0 && targetIndex < index) {
          const target = links[targetIndex]!;
          links[targetIndex] = { ...target,
            activationNegated: applied.negation === 'activation' ? true : target.activationNegated,
            effectNegated: applied.negation === 'effect' ? true : target.effectNegated,
          };
          const type = applied.negation === 'activation' ? 'activationNegated' : 'effectNegated';
          const event: EffectNegationEvent = { type, sequence: next.eventSequence + 1,
            linkId: target.id, effectId: target.effectId, player: link.player,
            sourceKind: target.source.kind, sourceVisibility: target.sourceVisibility };
          const operation: RuleOperationEvent = { type: 'ruleOperation', sequence: event.sequence + 1,
            operationId: applied.negation === 'activation' ? 'negate_activation' : 'negate_effect',
            player: link.player, effectId: target.effectId, linkId: target.id,
            ...(target.source.kind === 'card' ? { cardId: target.source.instanceId,
              identityVisibility: target.sourceVisibility } : {}) };
          next = { ...next, eventSequence: operation.sequence };
          events.push(event);
          events.push(operation);
          if (effect.destroysNegatedSource && target.source.kind === 'card') {
            const sourceCard = next.cards[target.source.instanceId];
            if (sourceCard && ['normal', 'frontline', 'spellCounter'].includes(sourceCard.location.zone)) {
              const protectedState = link.source.kind === 'card'
                ? consumeEffectDestructionProtection(next, sourceCard.id, link.player, catalog) : null;
              if (protectedState) next = protectedState;
              else {
                const destroyed = moveCard(next, { cardId: sourceCard.id, actor: link.player, reason: 'destroy', catalog });
                if (destroyed.status === 'moved' && destroyed.state.cards[sourceCard.id]?.location.zone === 'hell') {
                  next = recordTriggerEvents(destroyed.state, destroyed.events, catalog);
                  events.push(...destroyed.events);
                }
              }
            }
          }
        }
      }
    }
    const protectionFlag = `protectedFromEffect:${link.id}`;
    if (Object.values(next.cards).some((card) => card.flags.includes(protectionFlag))) {
      const cards = { ...next.cards };
      for (const [id, card] of Object.entries(cards)) if (card.flags.includes(protectionFlag)) {
        cards[id] = { ...card, flags: card.flags.filter((flag) => flag !== protectionFlag) };
      }
      next = { ...next, cards };
    }
    if (link.source.kind === 'card') {
      const card = next.cards[link.source.instanceId];
      const definition = card ? cardDefinition(catalog, card) : undefined;
      if (card && definition && card.location.zone === 'spellCounter' &&
        (definition.kind === 'counter' || definition.kind === 'spell' &&
          (definition.spellMode !== 'continuous' || outcome !== 'applied'))) {
        const moved = moveCard(next, { cardId: card.id, actor: link.player, reason: 'resolve', catalog });
        if (moved.status === 'moved') {
          next = moved.state;
          events.push(...moved.events);
        }
      }
    }
    const event: EffectResolvedEvent = { type: 'effectResolved', sequence: next.eventSequence + 1,
      linkId: link.id, effectId: link.effectId, player: link.player, outcome,
      sourceKind: link.source.kind, sourceVisibility: link.sourceVisibility };
    next = { ...next, eventSequence: event.sequence };
    events.push(event);
    next = recordTriggerEvents(next, events.slice(eventStart), catalog);
  }
  next = { ...next, chain: [], responsePasses: 0, pendingResolution: undefined,
    window: { kind: next.pendingSummon || next.pendingBattle ? 'response' : 'open',
      priorityPlayer: next.pendingSummon ? otherPlayer(next.pendingSummon.player)
        : next.pendingBattle ? otherPlayer(next.pendingBattle.player) : next.turnPlayer,
      id: next.window.id + 1 },
  };
  if (next.pendingSummon) {
    const settled = resolveRuleSummon(next, summonNegated, catalog,
      (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog));
    if (settled.status === 'failed') return rejected(state, settled.error.code);
    next = settled.state;
    events.push(...settled.events);
    next = recordTriggerEvents(next, settled.events, catalog);
  }
  const scheduled = finalizeTriggerQueue(next, catalog);
  return scheduled.ok ? accepted(scheduled.state, [...events, ...scheduled.events]) : scheduled;
}

export function resolveChain(state: GameState, catalog: CardCatalog): ResolutionResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (state.window.kind !== 'response' || state.chain.length === 0) return rejected(state, 'INVALID_RESPONSE');
  for (const link of state.chain) {
    const effect = effectFromCatalog(catalog, link.effectId);
    if (!effect || !linkedEffectIsTrusted(state, link, effect, catalog)) return rejected(state, 'INVALID_EFFECT_SOURCE');
  }
  return resolveLinks(state, catalog, [...state.chain], state.chain.length - 1, false);
}

function resumeResolutionChoice(state: GameState, player: PlayerId, selected: readonly ResolutionSelection[],
  catalog: CardCatalog): CommandResult {
  const pending = state.pendingResolution;
  if (!pending || state.window.kind !== 'choice' || pending.player !== player || state.window.priorityPlayer !== player ||
    selected.length < pending.minimum || selected.length > pending.maximum ||
    new Set(selected.map((item) => item.cardId)).size !== selected.length) return rejected(state, 'INVALID_RESOLUTION_CHOICE');
  const context = { ...pending.context, [pending.key]: selected };
  const clean: GameState = { ...state, pendingResolution: undefined,
    window: { kind: 'resolution', priorityPlayer: state.turnPlayer, id: state.window.id + 1 } };
  return resolveLinks(clean, catalog,
    pending.links, pending.linkIndex, pending.summonNegated,
    { stepIndex: pending.stepIndex + (pending.resumeCurrentStep ? 0 : 1), context,
      successes: pending.successes, applied: pending.applied });
}

export function chooseResolutionCard(state: GameState, command: ChooseResolutionCardCommand,
  catalog: CardCatalog): CommandResult {
  const pending = state.pendingResolution;
  const conditional = pending?.alsoFilterWhenFaceUp;
  const conditionalSourceIsActive = conditional && [
    ...state.players[command.player].zones.normal,
    ...state.players[command.player].zones.frontline,
    ...state.players[command.player].zones.spellCounter,
  ].some((id) => id && state.cards[id]?.cardId === conditional.cardId &&
    state.cards[id]?.face === 'up' && !state.cards[id]?.flags.includes('effectsNegated'));
  const matchesPendingFilter = pending && (matchingEffectCards(state, command.player, pending.filter, catalog)
    .includes(command.cardId) || !!conditionalSourceIsActive && matchingEffectCards(state, command.player,
      conditional!.filter, catalog).includes(command.cardId));
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (!pending || state.window.kind !== 'choice' || pending.player !== command.player ||
    !pending.candidates.includes(command.cardId) || pending.selected.some((item) => item.cardId === command.cardId) ||
    !matchesPendingFilter) {
    return rejected(state, 'INVALID_RESOLUTION_CHOICE');
  }
  if (pending.destinations) {
    if (!command.destination || !pending.destinations.includes(command.destination)) return rejected(state, 'INVALID_RESOLUTION_CHOICE');
  } else if (command.destination) return rejected(state, 'INVALID_RESOLUTION_CHOICE');
  const selected = [...pending.selected, { cardId: command.cardId,
    ...(command.destination ? { destination: command.destination } : {}) }];
  const remaining = pending.candidates.filter((id) => id !== command.cardId);
  if (selected.length >= pending.maximum || selected.length === pending.candidates.length && selected.length >= pending.minimum) {
    return resumeResolutionChoice({ ...state, pendingResolution: { ...pending, candidates: remaining, selected } }, command.player, selected, catalog);
  }
  return accepted({ ...state, pendingResolution: { ...pending, candidates: remaining, selected } }, []);
}

export function finishResolutionChoice(state: GameState, command: FinishResolutionChoiceCommand,
  catalog: CardCatalog): CommandResult {
  const pending = state.pendingResolution;
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (!pending || pending.player !== command.player || state.window.kind !== 'choice' ||
    pending.selected.length < pending.minimum || pending.selected.length > pending.maximum) {
    return rejected(state, 'INVALID_RESOLUTION_CHOICE');
  }
  return resumeResolutionChoice(state, command.player, pending.selected, catalog);
}

export function passPriority(state: GameState, player: PlayerId, catalog: CardCatalog): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (state.window.kind === 'open' && state.window.priorityPlayer === player && state.chain.length === 0 &&
    state.pendingTriggers.length === 0 && !state.pendingSummon && state.result === null) {
    const passes = state.openPriorityPasses ?? 0;
    if (player === state.turnPlayer) {
      if (passes !== 0) return rejected(state, 'INVALID_RESPONSE');
      return accepted({ ...state, openPriorityPasses: 1,
        window: { kind: 'open', priorityPlayer: otherPlayer(player), id: state.window.id + 1 },
      }, []);
    }
    if (passes !== 1) return rejected(state, 'INVALID_RESPONSE');
    return accepted({ ...state, openPriorityPasses: 2,
      window: { kind: 'open', priorityPlayer: state.turnPlayer, id: state.window.id + 1 },
    }, []);
  }
  if (state.window.kind !== 'response' || state.window.priorityPlayer !== player || state.chain.length === 0) {
    return rejected(state, 'INVALID_RESPONSE');
  }
  if ((state.responsePasses ?? 0) === 0) return accepted({ ...state, responsePasses: 1,
    window: { kind: 'response', priorityPlayer: otherPlayer(player), id: state.window.id + 1 },
  }, []);
  return resolveChain(state, catalog);
}
