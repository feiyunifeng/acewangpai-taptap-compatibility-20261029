import type { CardCatalog } from '../model/card.js';
import type { Command, RuleError, RuleErrorCode } from '../model/command.js';
import type { GameEvent, GameEndedEvent, MonsterSummonedEvent, PhaseChangedEvent } from '../model/event.js';
import { otherPlayer } from '../model/ids.js';
import type { GameState } from '../model/state.js';
import { freshTurnCounters } from '../mechanics/counters.js';
import { declareRuleSummon, resolveRuleSummon } from '../mechanics/summoning.js';
import { checkMainSummonMaterials } from '../mechanics/main-summon.js';
import { resultForLosses, resultForSpecialWin } from '../mechanics/victory.js';
import { chooseBattleTarget, declareAttack, passBattlePriority, resumeBattleAfterChain } from '../mechanics/combat.js';
import { moveCard } from './move-card.js';
import { canAdvancePhase, isOpenMainWindow } from './phase-machine.js';
import { appendChainLink, chooseResolutionCard, chooseTriggers, finalizeTriggerQueue, finishResolutionChoice,
  passPriority, recordTriggerEvents } from './chain-engine.js';
import { canonicalCommandSelections } from '../model/selection.js';
import { resolveHiddenTargetCommand } from '../model/hidden-field-target.js';
import { hasLegalBattleResponse } from './effect-action-candidates.js';
import { advanceTurn } from './end-turn.js';
import { processKeywordPhase } from '../mechanics/keyword-runtime.js';
import { payRuleSummonTp, ruleSummonTpCost } from '../mechanics/tp.js';

export type CommandResult =
  | { readonly ok: true; readonly state: GameState; readonly events: readonly GameEvent[] }
  | { readonly ok: false; readonly state: GameState; readonly error: RuleError };

function rejected(state: GameState, code: RuleErrorCode): CommandResult {
  return { ok: false, state, error: { code } };
}

function accepted(state: GameState, events: readonly GameEvent[]): CommandResult {
  return { ok: true, state, events };
}

function withExternalTriggers(result: CommandResult, catalog: CardCatalog): CommandResult {
  if (!result.ok) return result;
  const recorded = recordTriggerEvents(result.state, result.events, catalog);
  const scheduled = finalizeTriggerQueue(recorded, catalog);
  return scheduled.ok ? accepted(scheduled.state, [...result.events, ...scheduled.events]) : scheduled;
}

/** Resume a battle paused for a response chain, summon-negation window, or queued trigger choices. */
function continueBattleAfterResponse(result: CommandResult, catalog: CardCatalog): CommandResult {
  if (!result.ok) return result;
  const battle = result.state.pendingBattle;
  if (!battle || result.state.pendingSummon || result.state.chain.length > 0 ||
    result.state.pendingTriggers.length > 0 || result.state.result !== null) return result;
  let next = result.state;
  if (next.window.kind === 'open') next = { ...next, responsePasses: 0,
    window: { kind: 'response', priorityPlayer: otherPlayer(battle.player), id: next.window.id + 1 },
  };
  if (next.window.kind !== 'response') return result;
  const resumed = resumeBattleAfterChain(next, catalog,
    (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog));
  return resumed.ok ? withExternalTriggers(accepted(resumed.state, [...result.events, ...resumed.events]), catalog) : resumed;
}

/** Treat response windows with no legal effects as implicit passes, preserving every real response opportunity. */
function autoPassUnavailableBattleResponses(result: CommandResult, catalog: CardCatalog): CommandResult {
  let current = result;
  for (let pass = 0; pass < 8; pass++) {
    if (!current.ok) return current;
    const state = current.state;
    if (!state.pendingBattle || state.window.kind !== 'response' || state.chain.length > 0 ||
      state.pendingTriggers.length > 0 || state.pendingSummon || state.result !== null) return current;
    if (hasLegalBattleResponse(state, state.window.priorityPlayer, catalog)) return current;
    const skipped = passBattlePriority(state, state.window.priorityPlayer, catalog,
      (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog));
    if (!skipped.ok) return skipped;
    current = withExternalTriggers(accepted(skipped.state, [...current.events, ...skipped.events]), catalog);
  }
  return current;
}

function endForLoss(state: GameState, loser: 'p1' | 'p2', reason: string): CommandResult {
  const result = resultForLosses([loser], reason);
  const event: GameEndedEvent = {
    type: 'gameEnded', sequence: state.eventSequence + 1, winner: result.winner, reason,
  };
  return accepted({ ...state, result, eventSequence: event.sequence }, [event]);
}

function advancePhase(state: GameState, command: Extract<Command, { type: 'advancePhase' }>): CommandResult {
  if (!canAdvancePhase(state, command.player, command.to)) return rejected(state, 'INVALID_PHASE');
  if (state.phase === 'end' && command.to === 'start') {
    return advanceTurn(state, { type: 'advanceTurn', player: command.player });
  }
  const nextTurn = state.phase === 'end' && command.to === 'start';
  const turnPlayer = nextTurn ? otherPlayer(state.turnPlayer) : state.turnPlayer;
  const globalTurn = nextTurn ? state.globalTurn + 1 : state.globalTurn;
  const nextWindowKind = command.to === 'start' ? 'turnStart' : command.to === 'draw' ? 'choice' : 'open';
  const event: PhaseChangedEvent = {
    type: 'phaseChanged', sequence: state.eventSequence + 1, player: command.player,
    from: state.phase, to: command.to, globalTurn,
  };
  const nextState: GameState = {
    ...state, phase: command.to, turnPlayer, globalTurn,
    counters: nextTurn ? { p1: freshTurnCounters(globalTurn), p2: freshTurnCounters(globalTurn) } : state.counters,
    window: { kind: nextWindowKind, priorityPlayer: turnPlayer, id: state.window.id + 1 },
    eventSequence: event.sequence,
  };
  const keyword = processKeywordPhase(nextState, event);
  return accepted(keyword.state, [event, ...keyword.events]);
}

function drawCard(state: GameState, command: Extract<Command, { type: 'drawCard' }>, catalog: CardCatalog): CommandResult {
  if (state.phase !== 'draw' || state.window.kind !== 'choice' || state.window.priorityPlayer !== command.player ||
    state.chain.length !== 0 || state.pendingTriggers.length !== 0) return rejected(state, 'DRAW_NOT_REQUIRED');
  const top = state.players[command.player].zones.mainDeck[0];
  if (!top) return endForLoss(state, command.player, 'emptyDraw');
  const moved = moveCard(state, { cardId: top, actor: command.player, reason: 'draw',
    destination: { player: command.player, zone: 'hand' }, catalog });
  if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
  return accepted({ ...moved.state, window: { kind: 'open', priorityPlayer: command.player, id: state.window.id + 1 } }, moved.events);
}

function useSkill(state: GameState, command: Extract<Command, { type: 'useSkill' }>, catalog: CardCatalog): CommandResult {
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  const { player, skillCopyId } = command;
  const copy = Object.hasOwn(state.skills, skillCopyId) ? state.skills[skillCopyId] : undefined;
  const definition = copy && Object.hasOwn(catalog.skills, copy.skillId) ? catalog.skills[copy.skillId] : undefined;
  if (!copy || copy.owner !== player || !state.players[player].skillCopies.includes(skillCopyId) || !definition?.directAbility) {
    return rejected(state, 'INVALID_EFFECT_SOURCE');
  }
  if (copy.used || state.players[player].skillCopies.some((id) => state.skills[id]?.used)) return rejected(state, 'SKILL_USED');
  if (player !== state.turnPlayer || (state.phase !== 'main1' && state.phase !== 'main2') ||
    state.window.kind !== 'open' || state.window.priorityPlayer !== player || state.chain.length > 0 ||
    state.pendingTriggers.length > 0 || state.pendingBattle || state.pendingSummon || state.pendingResolution || state.result !== null) {
    return rejected(state, 'INVALID_EFFECT_TIMING');
  }
  const opponent = otherPlayer(player);
  if (definition.directAbility === 'execute' && state.players[opponent].life >= 800) return rejected(state, 'INVALID_EFFECT_TIMING');
  const sequence = state.eventSequence + 1;
  const usedCopies = Object.fromEntries(state.players[player].skillCopies.map((id) => [id, { ...state.skills[id]!, used: true }]));
  const event: GameEvent = { type: 'summonSkillUsed', sequence, player, skillId: definition.id, ability: definition.directAbility };
  const next: GameState = { ...state, skills: { ...state.skills, ...usedCopies },
    eventSequence: sequence };
  if (definition.directAbility === 'heal') {
    const healedSequence = sequence + 1;
    const healed: GameEvent = { type: 'lifeRecovered', sequence: healedSequence, player, amount: 1000, reason: 'summonSkill' };
    return accepted({ ...next, players: { ...next.players, [player]: { ...next.players[player], life: next.players[player].life + 1000 } },
      eventSequence: healedSequence }, [event, healed]);
  }
  if (definition.directAbility === 'execute') {
    const result = resultForSpecialWin(player, 'summonSkillExecute');
    const ended: GameEndedEvent = { type: 'gameEnded', sequence: sequence + 1, winner: result.winner, reason: result.reason };
    return accepted({ ...next, result, eventSequence: ended.sequence }, [event, ended]);
  }
  const top = next.players[player].zones.mainDeck[0];
  if (!top) {
    const ended = endForLoss({ ...next, eventSequence: sequence }, player, 'emptyDraw');
    return ended.ok ? accepted(ended.state, [event, ...ended.events]) : ended;
  }
  const moved = moveCard(next, { cardId: top, actor: player, reason: 'draw',
    destination: { player, zone: 'hand' }, catalog });
  return moved.status === 'moved' ? accepted(moved.state, [event, ...moved.events]) : rejected(state, 'MOVE_FAILED');
}

function ruleSummonMonster(state: GameState, command: Extract<Command, { type: 'ruleSummonMonster' }>, catalog: CardCatalog): CommandResult {
  if (!isOpenMainWindow(state, command.player)) return rejected(state, 'NOT_OPEN_WINDOW');
  const card = Object.hasOwn(state.cards, command.cardId) ? state.cards[command.cardId] : undefined;
  if (!card) return rejected(state, 'INVALID_CARD');
  if (card.owner !== command.player || card.controller !== command.player ||
    card.location.player !== command.player || card.location.zone !== 'hand' ||
    !state.players[command.player].zones.hand.includes(command.cardId)) return rejected(state, 'WRONG_ZONE');
  const definition = Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!definition || definition.id !== card.cardId) return rejected(state, 'INVALID_CARD');
  if (definition.kind !== 'monster' || definition.deck !== 'main' || definition.noRuleSummon) return rejected(state, 'WRONG_CARD_TYPE');
  const materials = command.materialIds ?? [];
  const materialCheck = checkMainSummonMaterials(state, command.player, definition, materials, catalog);
  if (!materialCheck.ok) return rejected(state, materialCheck.error.code);
  const tpCost = ruleSummonTpCost(definition.level);
  const payment = tpCost === null ? null : payRuleSummonTp(state, command.player, tpCost);
  if (!payment) return rejected(state, 'INSUFFICIENT_TP');
  let next = payment.state;
  const events: GameEvent[] = [...payment.events];
  for (const materialId of materials) {
    const released = moveCard(next, { cardId: materialId, actor: command.player, reason: 'release', catalog });
    if (released.status !== 'moved') return rejected(state, 'MOVE_FAILED');
    next = recordTriggerEvents(released.state, released.events, catalog);
    events.push(...released.events);
  }
  const moved = moveCard(next, { cardId: card.id, actor: command.player, reason: 'deploy',
    destination: { player: command.player, zone: 'normal', ...(command.slot === undefined ? {} : { slot: command.slot }) }, catalog });
  if (moved.status !== 'moved') return rejected(state, moved.status === 'rejected' && moved.error.code === 'ZONE_FULL' ? 'ZONE_FULL' : 'MOVE_FAILED');
  const event: MonsterSummonedEvent = {
    type: 'monsterSummoned', sequence: moved.state.eventSequence + 1,
    player: command.player, cardId: card.id, method: 'ruleMain', tributeCount: materials.length,
    ...(materials.length ? { tributeMaterialIds: [...materials] } : {}),
    identityVisibility: 'public',
  };
  next = recordTriggerEvents({ ...moved.state, eventSequence: event.sequence }, [event], catalog);
  return accepted(next, [...events, ...moved.events, event]);
}

function discardCard(state: GameState, command: Extract<Command, { type: 'discardCard' }>, catalog: CardCatalog): CommandResult {
  if (state.phase !== 'end' || state.window.kind !== 'open' || state.window.priorityPlayer !== command.player ||
    state.chain.length !== 0 || state.pendingTriggers.length !== 0) return rejected(state, 'NOT_OPEN_WINDOW');
  const hand = state.players[command.player].zones.hand;
  if (hand.length <= state.config.handLimit) return rejected(state, 'HAND_LIMIT_NOT_EXCEEDED');
  const card = Object.hasOwn(state.cards, command.cardId) ? state.cards[command.cardId] : undefined;
  if (!card || card.owner !== command.player || card.location.player !== command.player ||
    card.location.zone !== 'hand' || !hand.includes(command.cardId)) return rejected(state, 'WRONG_ZONE');
  const moved = moveCard(state, { cardId: command.cardId, actor: command.player, reason: 'discard', catalog });
  if (moved.status !== 'moved') return rejected(state, 'MOVE_FAILED');
  return accepted(moved.state, moved.events);
}

function setCard(state: GameState, command: Extract<Command, { type: 'setCard' }>, catalog: CardCatalog): CommandResult {
  if (!isOpenMainWindow(state, command.player)) return rejected(state, 'NOT_OPEN_WINDOW');
  const card = Object.hasOwn(state.cards, command.cardId) ? state.cards[command.cardId] : undefined;
  const definition = card && Object.hasOwn(catalog.cards, card.cardId) ? catalog.cards[card.cardId] : undefined;
  if (!card || !definition || definition.id !== card.cardId ||
    (definition.kind !== 'spell' && definition.kind !== 'counter')) return rejected(state, 'INVALID_CARD');
  if (card.owner !== command.player || card.location.player !== command.player || card.location.zone !== 'hand' ||
    !state.players[command.player].zones.hand.includes(card.id)) return rejected(state, 'WRONG_ZONE');
  const moved = moveCard(state, { cardId: card.id, actor: command.player, reason: 'deploy', catalog,
    destination: { player: command.player, zone: 'spellCounter',
      ...(command.slot === undefined ? {} : { slot: command.slot }) }, face: 'down' });
  return moved.status === 'moved' ? accepted(moved.state, moved.events)
    : rejected(state, moved.status === 'rejected' && moved.error.code === 'ZONE_FULL' ? 'ZONE_FULL' : 'MOVE_FAILED');
}

/** The command boundary owns legality and ensures all rejected operations preserve the input object. */
function applyCommandInternal(state: GameState, incoming: Command, catalog: CardCatalog): CommandResult {
  const command = canonicalCommandSelections(incoming);
  if (catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  if (state.result !== null) return rejected(state, 'GAME_OVER');
  if (command.type === 'concede') return endForLoss(state, command.player, 'concede');
  if (command.type === 'advanceTurn') return withExternalTriggers(advanceTurn(state, command), catalog);
  if (command.type === 'passSummonResponse') {
    if (!state.pendingSummon || state.window.kind !== 'response' || state.window.priorityPlayer !== command.player ||
      state.chain.length !== 0) {
      return rejected(state, 'INVALID_RESPONSE');
    }
    const result = resolveRuleSummon(state, false, catalog,
      (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog));
    return result.status === 'summoned' || result.status === 'aborted'
      ? continueBattleAfterResponse(withExternalTriggers(accepted(result.state, result.events), catalog), catalog)
      : rejected(state, 'MOVE_FAILED');
  }
  if (command.type === 'activateEffect') return appendChainLink(state, command, catalog);
  if (command.type === 'useSkill') return withExternalTriggers(useSkill(state, command, catalog), catalog);
  if (command.type === 'declareAttack') return withExternalTriggers(declareAttack(state, command, catalog), catalog);
  if (command.type === 'chooseBattleTarget') return chooseBattleTarget(state, command, catalog);
  if (command.type === 'passPriority') {
    if (state.pendingBattle && state.chain.length === 0) {
      return withExternalTriggers(passBattlePriority(state, command.player, catalog,
        (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog)), catalog);
    }
    const passed = passPriority(state, command.player, catalog);
    if (passed.ok && state.pendingBattle && state.chain.length > 0 && passed.state.pendingBattle &&
      passed.state.chain.length === 0 && passed.state.pendingTriggers.length === 0 &&
      (passed.state.window.kind === 'response' || passed.state.window.kind === 'open')) {
      return continueBattleAfterResponse(passed, catalog);
    }
    return passed;
  }
  if (command.type === 'chooseTriggers') return continueBattleAfterResponse(chooseTriggers(state, command, catalog), catalog);
  if (command.type === 'chooseResolutionCard') return continueBattleAfterResponse(chooseResolutionCard(state, command, catalog), catalog);
  if (command.type === 'finishResolutionChoice') return continueBattleAfterResponse(finishResolutionChoice(state, command, catalog), catalog);
  if (command.player !== state.turnPlayer) return rejected(state, 'NOT_TURN_PLAYER');
  switch (command.type) {
    case 'advancePhase': return withExternalTriggers(advancePhase(state, command), catalog);
    case 'drawCard': return withExternalTriggers(drawCard(state, command, catalog), catalog);
    case 'ruleSummonMonster': return withExternalTriggers(ruleSummonMonster(state, command, catalog), catalog);
    case 'ruleSummonTerminal': {
      const result = declareRuleSummon(state, command.player, command, catalog,
        (atEvent, occurred) => recordTriggerEvents(atEvent, occurred, catalog));
      return result.status === 'failed' ? rejected(state, result.error.code)
        : withExternalTriggers(accepted(result.state, result.events), catalog);
    }
    case 'discardCard': return withExternalTriggers(discardCard(state, command, catalog), catalog);
    case 'setCard': return withExternalTriggers(setCard(state, command, catalog), catalog);
  }
}

/** Clears a closed empty open-priority cycle after any accepted game action. */
export function applyCommand(state: GameState, incoming: Command, catalog: CardCatalog): CommandResult {
  const resolved = resolveHiddenTargetCommand(state, incoming);
  if (!resolved) return rejected(state, 'INVALID_TARGET');
  let result = applyCommandInternal(state, resolved, catalog);
  if (!result.ok) return result;
  if (incoming.type !== 'passPriority' && (state.openPriorityPasses ?? 0) === 2) {
    result = accepted({ ...result.state, openPriorityPasses: 0 }, result.events);
  }
  return autoPassUnavailableBattleResponses(result, catalog);
}
