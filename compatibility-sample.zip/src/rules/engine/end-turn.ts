import type { AdvanceTurnCommand, RuleError } from '../model/command.js';
import type { GameEvent, PhaseChangedEvent } from '../model/event.js';
import { otherPlayer } from '../model/ids.js';
import type { CardInstance, GameState } from '../model/state.js';
import { freshTurnCounters } from '../mechanics/counters.js';
import { tpAllowance } from '../mechanics/tp.js';
import { processKeywordPhase } from '../mechanics/keyword-runtime.js';
import type { CommandResult } from './submit-command.js';

function rejected(state: GameState, code: RuleError['code']): CommandResult {
  return { ok: false, state, error: { code } };
}

/**
 * Remove only explicitly expiring state. Untagged modifiers and generic flags
 * are intentionally preserved because their duration is not known to the core.
 */
export function clearTurnTemporaryState(state: GameState): GameState {
  const cards: Record<string, CardInstance> = { ...state.cards };
  let changed = false;
  for (const [id, card] of Object.entries(state.cards)) {
    const modifiers = card.modifiers.filter((modifier) => modifier.expiresAtTurn !== state.globalTurn);
    const flags = card.flags.filter((flag) => {
      const match = /^temporaryUntil:(\d+)$/.exec(flag);
      return !match || Number(match[1]) !== state.globalTurn;
    });
    if (modifiers.length !== card.modifiers.length || flags.length !== card.flags.length) {
      cards[id] = { ...card, modifiers, flags };
      changed = true;
    }
  }
  const battleRewards = Object.fromEntries(Object.entries(state.battleRewards ?? {})
    .filter(([, reward]) => reward && reward.expiresAtTurn !== state.globalTurn));
  const rewardChanged = Object.keys(battleRewards).length !== Object.keys(state.battleRewards ?? {}).length;
  return changed || rewardChanged ? { ...state, cards, battleRewards } : state;
}

/** Advance from the end phase into the next player's start phase. */
export function advanceTurn(state: GameState, command: AdvanceTurnCommand): CommandResult {
  if (state.result !== null) return rejected(state, 'GAME_OVER');
  if (state.phase !== 'end' || state.window.kind !== 'open' ||
    state.window.priorityPlayer !== command.player || state.turnPlayer !== command.player ||
    state.chain.length > 0 || state.pendingTriggers.length > 0 || state.pendingBattle ||
    state.players[command.player].zones.hand.length > state.config.handLimit) {
    return rejected(state, 'INVALID_PHASE');
  }
  const cleaned = clearTurnTemporaryState(state);
  const nextPlayer = otherPlayer(command.player);
  const globalTurn = state.globalTurn + 1;
  const allowance = tpAllowance(globalTurn);
  const phaseEvent: PhaseChangedEvent = {
    type: 'phaseChanged', sequence: cleaned.eventSequence + 1, player: command.player,
    from: 'end', to: 'start', globalTurn,
  };
  const tpEvents = (['p1', 'p2'] as const).map((player, index) => ({
    type: 'tpChanged' as const,
    sequence: phaseEvent.sequence + index + 1,
    player,
    from: cleaned.players[player].tp,
    to: allowance,
    reason: 'turnRefresh' as const,
  }));
  const players = {
    ...cleaned.players,
    p1: { ...cleaned.players.p1, tp: allowance },
    p2: { ...cleaned.players.p2, tp: allowance },
  };
  const next: GameState = {
    ...cleaned,
    phase: 'start', turnPlayer: nextPlayer, globalTurn,
    players,
    counters: { p1: freshTurnCounters(globalTurn), p2: freshTurnCounters(globalTurn) },
    window: { kind: 'open', priorityPlayer: nextPlayer, id: cleaned.window.id + 1 },
    responsePasses: 0, eventSequence: tpEvents.at(-1)!.sequence,
  };
  const keyword = processKeywordPhase(next, phaseEvent);
  return { ok: true, state: keyword.state, events: [phaseEvent, ...tpEvents, ...keyword.events] as GameEvent[] };
}
