import type { CardInstanceId, PlayerId } from '../model/ids.js';
import type { CardCatalog, CardDefinition } from '../model/card.js';
import type { CardInstance, CardLocation, GameState, PlayerZones, Zone } from '../model/state.js';
import { KEYWORD_REGISTRY, type KeywordEvent, type KeywordStatus, type RuleOperationEvent } from '../model/keyword.js';
import { shuffle } from '../mechanics/rng.js';
import { fieldCapacity, isFieldZone, type FieldZone } from '../mechanics/zones.js';

export type MoveReason = 'destroy' | 'release' | 'sacrifice' | 'discard' | 'send' | 'resolve' | 'return' | 'deploy' | 'draw' | 'effect' | 'controlChange';

export interface MoveDestination extends CardLocation {
  /** The first element of a deck is its top. Omitted means shuffle on main-deck return. */
  readonly position?: 'top' | 'bottom';
}

export interface MoveReplacement {
  readonly id: string;
  readonly whenDestination: Zone;
  readonly destination: MoveDestination;
}

export interface MoveRequest {
  readonly cardId: CardInstanceId;
  readonly catalog: CardCatalog;
  readonly actor: PlayerId;
  readonly reason: MoveReason;
  readonly destructionCause?: 'battle';
  readonly destination?: MoveDestination;
  readonly replacements?: readonly MoveReplacement[];
  /** IDs chosen in application order, only needed where several effects compete. */
  readonly replacementOrder?: readonly string[];
  /** Card effects may explicitly allow a main-deck monster onto the frontline. */
  readonly allowMainMonsterFrontline?: boolean;
  /** A validated terminal summon may place an extra-deck monster in the normal monster zone. */
  readonly allowExtraMonsterNormal?: boolean;
  readonly face?: 'up' | 'down';
  /** Deterministically shuffle the destination deck after insertion. */
  readonly shuffleDestination?: boolean;
}

export interface CardMovedEvent {
  readonly type: 'cardMoved';
  readonly sequence: number;
  readonly cardId: CardInstanceId;
  readonly actor: PlayerId;
  readonly reason: MoveReason;
  readonly destructionCause?: 'battle';
  readonly from: CardLocation;
  readonly to: CardLocation;
  readonly replacementIds: readonly string[];
  readonly identityVisibility: 'public' | PlayerId;
}

export interface CardFaceChangedEvent {
  readonly type: 'cardFaceChanged';
  readonly sequence: number;
  readonly cardId: CardInstanceId;
  readonly actor: PlayerId;
  readonly reason: MoveReason;
  readonly location: CardLocation;
  readonly fromFace: 'up' | 'down';
  readonly toFace: 'up' | 'down';
  readonly identityVisibility: 'public' | PlayerId;
}

export type MoveEvent = CardMovedEvent | CardFaceChangedEvent | KeywordEvent | RuleOperationEvent;

export type MoveErrorCode = 'UNKNOWN_CARD' | 'INVALID_SOURCE' | 'INVALID_DESTINATION' | 'WRONG_DECK' |
  'WRONG_ZONE' | 'ZONE_FULL' | 'INVALID_REPLACEMENT' | 'NO_CONTROL_CHANGE' |
  'CATALOG_MISMATCH' | 'UNKNOWN_CARD_DEFINITION' | 'INVALID_FACE';

export type MoveResult =
  | { readonly status: 'moved'; readonly state: GameState; readonly events: readonly MoveEvent[] }
  | { readonly status: 'choice'; readonly state: GameState; readonly events: readonly []; readonly choice: {
      readonly player: PlayerId; readonly replacementIds: readonly string[];
    } }
  | { readonly status: 'rejected'; readonly state: GameState; readonly events: readonly []; readonly error: {
      readonly code: MoveErrorCode;
    } };

function rejected(state: GameState, code: MoveErrorCode): MoveResult {
  return { status: 'rejected', state, events: [], error: { code } };
}

/** Predict the final zone for a movement that has no player-choice replacement window. */
export function willCardReachZone(state: GameState, cardId: CardInstanceId, proposedZone: Zone): boolean {
  const card = Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  if (!card) return false;
  const leavesField = isFieldZone(card.location.zone) && !isFieldZone(proposedZone);
  const finalZone = leavesField && card.leaveFieldReplacement ? 'mainDeck' : proposedZone;
  return finalZone === proposedZone;
}

function defaultDestination(card: CardInstance, request: MoveRequest): MoveDestination | undefined {
  if (request.reason === 'discard') return { player: card.owner, zone: 'heaven' };
  if (request.destination) return request.destination;
  switch (request.reason) {
    case 'destroy': return { player: card.owner, zone: 'hell' };
    case 'release':
    case 'sacrifice':
    case 'send':
    case 'resolve': return { player: card.owner, zone: 'heaven' };
    default: return undefined;
  }
}

function sourceContains(state: GameState, card: CardInstance): boolean {
  const { player, zone, slot } = card.location;
  const cards = state.players[player]?.zones[zone];
  if (!cards) return false;
  if (isFieldZone(zone)) return Number.isInteger(slot) && slot! >= 0 && slot! < cards.length && cards[slot!] === card.id;
  return slot === undefined && cards.includes(card.id);
}

function destinationError(state: GameState, card: CardInstance, definition: CardDefinition, request: MoveRequest, destination: MoveDestination): MoveErrorCode | null {
  const { player, zone, slot, position } = destination;
  if (player !== 'p1' && player !== 'p2') return 'INVALID_DESTINATION';
  if (position && ((zone !== 'mainDeck' && zone !== 'extraDeck') || slot !== undefined)) return 'INVALID_DESTINATION';
  if (!isFieldZone(zone)) {
    if (slot !== undefined || player !== card.owner) return 'INVALID_DESTINATION';
    if (zone === 'extraDeck' && definition.deck !== 'extra') return 'WRONG_DECK';
    if ((zone === 'mainDeck' || zone === 'hand') && definition.deck !== 'main') return 'WRONG_DECK';
    if (zone === 'extraDeck' || zone === 'mainDeck' || zone === 'hand' || zone === 'heaven' || zone === 'hell') return null;
    return 'INVALID_DESTINATION';
  }
  if (zone === 'normal' && (definition.kind !== 'monster' || definition.deck !== 'main' && !request.allowExtraMonsterNormal)) return 'WRONG_ZONE';
  if (zone === 'frontline' && (definition.kind !== 'monster' || (definition.deck !== 'extra' && !request.allowMainMonsterFrontline))) return 'WRONG_ZONE';
  if (zone === 'spellCounter' && definition.kind === 'monster') return 'WRONG_ZONE';
  const slots = state.players[player].zones[zone];
  if (slots.length !== fieldCapacity(state.config, zone)) return 'INVALID_DESTINATION';
  if (slot !== undefined && (!Number.isInteger(slot) || slot < 0 || slot >= slots.length)) return 'INVALID_DESTINATION';
  if (slot === undefined ? slots.every((id) => id !== null) : slots[slot] !== null &&
    !(card.location.player === player && card.location.zone === zone && card.location.slot === slot && slots[slot] === card.id)) return 'ZONE_FULL';
  return null;
}

function withoutCard(zones: PlayerZones, card: CardInstance): PlayerZones {
  const zone = card.location.zone;
  const cards = [...zones[zone]];
  if (isFieldZone(zone)) cards[card.location.slot!] = null;
  else cards.splice(cards.indexOf(card.id), 1);
  return { ...zones, [zone]: cards };
}

function withCard(zones: PlayerZones, id: CardInstanceId, destination: MoveDestination): PlayerZones {
  const cards = [...zones[destination.zone]];
  if (isFieldZone(destination.zone)) cards[destination.slot!] = id;
  else if (destination.position === 'top') cards.unshift(id);
  else if (destination.position === 'bottom') cards.push(id);
  else cards.push(id);
  return { ...zones, [destination.zone]: cards };
}

/** Validate the final destination before changing any card, zone, RNG or event sequence. */
export function moveCard(state: GameState, request: MoveRequest): MoveResult {
  const card = Object.hasOwn(state.cards, request.cardId) ? state.cards[request.cardId] : undefined;
  if (!card) return rejected(state, 'UNKNOWN_CARD');
  if (request.catalog.version !== state.catalogVersion) return rejected(state, 'CATALOG_MISMATCH');
  const definition = Object.hasOwn(request.catalog.cards, card.cardId) ? request.catalog.cards[card.cardId] : undefined;
  if (!definition || definition.id !== card.cardId) return rejected(state, 'UNKNOWN_CARD_DEFINITION');
  if (!sourceContains(state, card)) return rejected(state, 'INVALID_SOURCE');
  let destination = defaultDestination(card, request);
  if (!destination) return rejected(state, 'INVALID_DESTINATION');
  if (request.reason === 'return' && !['hand', 'mainDeck', 'extraDeck'].includes(destination.zone)) return rejected(state, 'INVALID_DESTINATION');
  if (request.reason === 'controlChange') {
    if (!isFieldZone(card.location.zone) || !isFieldZone(destination.zone) || destination.player === card.controller) return rejected(state, 'NO_CONTROL_CHANGE');
  }

  const persistentReplacement: MoveReplacement[] = isFieldZone(card.location.zone) && !isFieldZone(destination.zone) &&
    card.leaveFieldReplacement ? [{ id: card.leaveFieldReplacement.id, whenDestination: destination.zone,
      destination: { player: card.owner, zone: 'mainDeck' } }] : [];
  const replacements = [...(request.replacements ?? []), ...persistentReplacement];
  if (new Set(replacements.map((replacement) => replacement.id)).size !== replacements.length) return rejected(state, 'INVALID_REPLACEMENT');
  const applied: string[] = [];
  let orderIndex = 0;
  while (true) {
    const currentDestination = destination;
    const available = replacements.filter((replacement) => replacement.whenDestination === currentDestination.zone && !applied.includes(replacement.id));
    if (available.length === 0) break;
    let replacement: MoveReplacement;
    if (available.length === 1) replacement = available[0]!;
    else {
      const chosen = request.replacementOrder?.[orderIndex++];
      if (!chosen) return { status: 'choice', state, events: [], choice: {
        player: isFieldZone(card.location.zone) ? card.controller : card.owner,
        replacementIds: available.map((item) => item.id),
      } };
      const selected = available.find((item) => item.id === chosen);
      if (!selected) return rejected(state, 'INVALID_REPLACEMENT');
      replacement = selected;
    }
    applied.push(replacement.id);
    destination = replacement.destination;
  }

  const error = destinationError(state, card, definition, request, destination);
  if (error) return rejected(state, error);
  const requiredFace = destination.zone === 'spellCounter' ? undefined
    : destination.zone === 'normal' || destination.zone === 'frontline' || destination.zone === 'heaven' || destination.zone === 'hell'
      ? 'up' : 'down';
  if (request.face !== undefined && requiredFace !== undefined && request.face !== requiredFace) return rejected(state, 'INVALID_FACE');
  const final: MoveDestination = isFieldZone(destination.zone)
    ? { player: destination.player, zone: destination.zone, slot: destination.slot ?? state.players[destination.player].zones[destination.zone].indexOf(null) }
    : destination;
  const sameLocation = card.location.player === final.player && card.location.zone === final.zone && card.location.slot === final.slot;
  if (sameLocation && !(final.zone === 'spellCounter' && request.face !== undefined && request.face !== card.face)) return rejected(state, 'INVALID_DESTINATION');

  const face = request.face ?? requiredFace ?? (card.location.zone === 'spellCounter' ? card.face : 'up');
  const waitsAfterSet = definition.kind === 'counter' || (definition.kind === 'spell' && definition.spellMode === 'quick');
  const setOnTurn = final.zone === 'spellCounter' && face === 'down' && waitsAfterSet
    ? card.location.zone === 'spellCounter' && card.face === 'down' ? card.setOnTurn : state.globalTurn
    : null;
  if (sameLocation) {
    const event: CardFaceChangedEvent = {
      type: 'cardFaceChanged', sequence: state.eventSequence + 1, cardId: card.id,
      actor: request.actor, reason: request.reason, location: card.location,
      fromFace: card.face, toFace: face,
      identityVisibility: face === 'up' ? 'public' : card.location.player,
    };
    return { status: 'moved', state: {
      ...state,
      cards: { ...state.cards, [card.id]: { ...card, face, setOnTurn } },
      eventSequence: event.sequence,
    }, events: [event] };
  }

  const sourcePlayer = card.location.player;
  const sourceZones = withoutCard(state.players[sourcePlayer].zones, card);
  const targetZones = withCard(sourcePlayer === final.player ? sourceZones : state.players[final.player].zones, card.id, final);
  let rng = state.rng;
  let finalZones = targetZones;
  if ((final.zone === 'mainDeck' && final.position === undefined || request.shuffleDestination) &&
    (final.zone === 'mainDeck' || final.zone === 'extraDeck')) {
    const shuffled = shuffle(targetZones[final.zone], rng);
    rng = shuffled.rng;
    finalZones = { ...targetZones, [final.zone]: shuffled.items };
  }
  const location: CardLocation = { player: final.player, zone: final.zone, ...(final.slot === undefined ? {} : { slot: final.slot }) };
  const reset = final.zone === 'extraDeck';
  const leavesField = isFieldZone(card.location.zone) && !isFieldZone(final.zone);
  const movedCard: CardInstance = {
    ...card, location, controller: isFieldZone(final.zone) ? final.player : card.owner,
    zoneEntrySequence: sourcePlayer === final.player && card.location.zone === final.zone
      ? card.zoneEntrySequence : state.eventSequence + 1,
    face,
    setOnTurn,
    properlySummoned: reset ? false : card.properlySummoned,
    modifiers: reset ? [] : leavesField ? card.modifiers.filter((modifier) =>
      !modifier.id.startsWith('fieldMark:') && !modifier.id.startsWith('execute:')) : card.modifiers,
    effectsDisabledUntilTurn: leavesField ? undefined : card.effectsDisabledUntilTurn,
    effectDestructionProtectionUsedTurn: leavesField ? undefined : card.effectDestructionProtectionUsedTurn,
    leaveFieldReplacement: final.zone === 'mainDeck' ? undefined : card.leaveFieldReplacement,
    flags: reset ? [] : leavesField
      ? card.flags.filter((flag) => flag !== 'effectsNegated' && !flag.startsWith('continuousActive:')) : card.flags,
  };
  const event: CardMovedEvent = {
    type: 'cardMoved', sequence: state.eventSequence + 1, cardId: card.id, actor: request.actor,
    reason: request.reason, ...(request.destructionCause ? { destructionCause: request.destructionCause } : {}),
    from: card.location, to: location, replacementIds: applied,
    identityVisibility: face === 'up' || final.zone === 'heaven' || final.zone === 'hell' ? 'public' : final.player,
  };
  const operationId = request.reason === 'destroy' ? 'destroy'
    : request.reason === 'release' ? 'release' : request.reason === 'sacrifice' ? 'sacrifice' : undefined;
  const operationEvent: RuleOperationEvent | undefined = operationId ? {
    type: 'ruleOperation', sequence: event.sequence + 1, operationId, player: request.actor,
    cardId: card.id, identityVisibility: event.identityVisibility,
  } : undefined;
  const players = {
    ...state.players,
    [sourcePlayer]: { ...state.players[sourcePlayer], zones: sourceZones },
    [final.player]: { ...state.players[final.player], zones: finalZones },
  };
  let nextState: GameState = {
    ...state, players, cards: { ...state.cards, [card.id]: movedCard }, rng,
    eventSequence: operationEvent?.sequence ?? event.sequence,
  };
  if (final.zone === 'normal' && final.slot !== undefined && definition.kind === 'monster') {
    const mark = state.fieldMarks?.[final.player]?.[final.slot];
    const stat = mark?.kind === 'attack' ? 'atk' : mark?.kind === 'defense' ? 'def' : undefined;
    if (mark && stat && definition[stat] !== undefined) {
      const entered = nextState.cards[card.id]!;
      nextState = { ...nextState, cards: { ...nextState.cards, [card.id]: { ...entered,
        modifiers: [...entered.modifiers, { id: `fieldMark:${final.player}:${final.slot}:${event.sequence}`, [stat]: mark.amount }] } },
        fieldMarks: { ...nextState.fieldMarks,
          [final.player]: Object.fromEntries(Object.entries(nextState.fieldMarks?.[final.player] ?? {})
            .filter(([slot]) => Number(slot) !== final.slot)) } };
    }
  }
  const retainedStatuses = (state.keywordStatuses ?? []).filter((status) =>
    status.keywordId === 'burn' || status.targetCardId !== card.id ||
    status.targetZoneEntrySequence === movedCard.zoneEntrySequence && (final.zone === 'normal' || final.zone === 'frontline'));
  const expiredStatuses = (state.keywordStatuses ?? []).filter((status) => status.keywordId !== 'burn' &&
    status.targetCardId === card.id && status.targetZoneEntrySequence !== movedCard.zoneEntrySequence) as
      Extract<KeywordStatus, { readonly keywordId: 'freeze' | 'weaken' }>[];
  const nextSequence = operationEvent?.sequence ?? event.sequence;
  const keywordEvents: KeywordEvent[] = expiredStatuses.map((status, index) => ({
    type: 'keyword_expired', sequence: nextSequence + index + 1, keywordId: status.keywordId,
    linkId: status.sourceLinkId, effectId: status.effectId, player: status.player,
    ...(status.sourceId ? { sourceId: status.sourceId } : {}), sourceVisibility: status.sourceVisibility,
    targetCardId: status.targetCardId, targetVisibility: status.targetVisibility, statusId: status.id,
    presentation: KEYWORD_REGISTRY[status.keywordId].presentation,
  }));
  if (expiredStatuses.length) nextState = { ...nextState, keywordStatuses: retainedStatuses,
    eventSequence: keywordEvents.at(-1)!.sequence };
  return { status: 'moved', state: nextState, events: [event, ...(operationEvent ? [operationEvent] : []), ...keywordEvents] };
}
