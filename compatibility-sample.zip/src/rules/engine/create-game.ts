import type { CardCatalog, DeckList } from '../model/card.js';
import { DEFAULT_RULES_CONFIG, type RulesConfig } from '../model/config.js';
import { otherPlayer, PLAYER_IDS, type CardInstanceId, type PlayerId, type SkillId } from '../model/ids.js';
import type { CardInstance, GameState, PlayerState, PlayerZones, SkillCopy, Zone } from '../model/state.js';
import { createRng, nextRandom, shuffle } from '../mechanics/rng.js';
import { freshTurnCounters } from '../mechanics/counters.js';
import { tpAllowance } from '../mechanics/tp.js';
import { validateDeck } from './validate-deck.js';

export interface PlayerSetup {
  readonly deck: DeckList;
  readonly skills: { readonly first: readonly SkillId[]; readonly second: readonly SkillId[] };
}

export interface CreateGameInput {
  readonly seed: number;
  readonly catalog: CardCatalog;
  readonly players: Readonly<Record<PlayerId, PlayerSetup>>;
  readonly config?: RulesConfig;
}

function validateSkills(ids: readonly SkillId[], count: number, catalog: CardCatalog, config: RulesConfig): void {
  if (ids.length !== count) throw new Error(`Expected ${count} skill copies`);
  const counts = new Map<string, number>();
  for (const id of ids) {
    const skill = Object.hasOwn(catalog.skills, id) ? catalog.skills[id] : undefined;
    if (!skill || skill.id !== id) throw new Error(`Unknown skill: ${id}`);
    const used = (counts.get(skill.name) ?? 0) + 1;
    if (used > config.sameSkillMax) throw new Error(`Too many copies of skill: ${skill.name}`);
    counts.set(skill.name, used);
  }
}

function emptyZones(config: RulesConfig): PlayerZones {
  return {
    mainDeck: [], extraDeck: [], hand: [],
    normal: Array(config.normalMonsterSlots).fill(null),
    frontline: Array(config.frontlineSlots).fill(null),
    spellCounter: Array(config.spellCounterSlots).fill(null),
    heaven: [], hell: [],
  };
}

export function createGame(input: CreateGameInput): GameState {
  const config = Object.freeze({ ...(input.config ?? DEFAULT_RULES_CONFIG) });
  let rng = createRng(input.seed);
  const initiative = nextRandom(rng);
  rng = initiative.rng;
  const firstPlayer: PlayerId = initiative.value < 0.5 ? 'p1' : 'p2';
  const secondPlayer = otherPlayer(firstPlayer);
  const cards: Record<CardInstanceId, CardInstance> = {};
  const skills: Record<string, SkillCopy> = {};
  const players = {} as Record<PlayerId, PlayerState>;

  for (const playerId of PLAYER_IDS) {
    const setup = input.players[playerId];
    const deckCheck = validateDeck(setup.deck, input.catalog, config);
    if (!deckCheck.valid) throw new Error(`Invalid deck for ${playerId}: ${deckCheck.issues.map((issue) => issue.code).join(', ')}`);
    const isFirst = playerId === firstPlayer;
    const chosenSkills = isFirst ? setup.skills.first : setup.skills.second;
    validateSkills(chosenSkills, isFirst ? config.firstPlayerSkillCopies : config.secondPlayerSkillCopies, input.catalog, config);

    const mainIds = setup.deck.main.map((cardId, index) => `${playerId}:main:${index}`);
    const extraIds = setup.deck.extra.map((cardId, index) => `${playerId}:extra:${index}`);
    for (const [zone, cardIds, instanceIds] of [
      ['mainDeck', setup.deck.main, mainIds], ['extraDeck', setup.deck.extra, extraIds],
    ] as const) {
      cardIds.forEach((cardId, index) => {
        const id = instanceIds[index]!;
        cards[id] = {
          id, cardId, owner: playerId, controller: playerId,
          location: { player: playerId, zone: zone as Zone },
          face: 'down', setOnTurn: null, properlySummoned: false, zoneEntrySequence: 0, modifiers: [], flags: [],
        };
      });
    }
    const mainShuffle = shuffle(mainIds, rng);
    rng = mainShuffle.rng;
    const extraShuffle = shuffle(extraIds, rng);
    rng = extraShuffle.rng;
    const hand = mainShuffle.items.slice(0, config.openingHand);
    const remainingMain = mainShuffle.items.slice(config.openingHand);
    for (const id of hand) cards[id] = { ...cards[id]!, location: { player: playerId, zone: 'hand' } };

    const skillCopies = chosenSkills.map((skillId, index) => {
      const id = `${playerId}:skill:${index}`;
      skills[id] = { id, skillId, owner: playerId, used: false };
      return id;
    });
    players[playerId] = {
      life: config.initialLife,
      tp: tpAllowance(1),
      zones: { ...emptyZones(config), mainDeck: remainingMain, extraDeck: extraShuffle.items, hand },
      skillCopies,
    };
  }

  return {
    rulesVersion: config.version,
    config,
    catalogVersion: input.catalog.version,
    seed: input.seed,
    rng,
    firstPlayer, secondPlayer, turnPlayer: firstPlayer,
    globalTurn: 1,
    phase: 'start',
    players, cards, skills,
    counters: { p1: freshTurnCounters(1), p2: freshTurnCounters(1) },
    window: { kind: 'open', priorityPlayer: firstPlayer, id: 1 },
    chain: [], responsePasses: 0, pendingTriggers: [], triggerSelections: {}, triggerObservedThrough: 0,
    eventSequence: 0, result: null, battleRewards: {}, fieldMarks: { p1: {}, p2: {} },
    matchEffectActivations: { p1: [], p2: [] }, mainMonsterEffectLocks: {},
  };
}
