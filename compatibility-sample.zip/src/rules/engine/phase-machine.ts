import type { PlayerId } from '../model/ids.js';
import type { GameState, Phase } from '../model/state.js';
import { isKeywordStatusActive } from '../model/keyword.js';

/** A rule action needs a clear chain/trigger queue and the turn player's open priority. */
export function isOpenMainWindow(state: GameState, player: PlayerId): boolean {
  return state.result === null && player === state.turnPlayer && (state.phase === 'main1' || state.phase === 'main2') &&
    state.window.kind === 'open' && state.window.priorityPlayer === player &&
    state.chain.length === 0 && state.pendingTriggers.length === 0;
}

export function canAdvancePhase(state: GameState, player: PlayerId, to: Phase): boolean {
  if (state.result !== null || state.pendingBattle || player !== state.turnPlayer || state.chain.length > 0 || state.pendingTriggers.length > 0) return false;
  if (state.phase === 'start') {
    if ((state.window.kind !== 'open' && state.window.kind !== 'turnStart') || state.window.priorityPlayer !== player) return false;
    return to === (state.globalTurn === 1 && player === state.firstPlayer ? 'main1' : 'draw');
  }
  if (state.window.kind !== 'open' || state.window.priorityPlayer !== player) return false;
  switch (state.phase) {
    case 'draw': return to === 'main1';
    case 'main1': return to === 'end' || (to === 'battle' && state.globalTurn > 1);
    case 'battle': return to === 'main2' || to === 'end';
    case 'main2': return to === 'end';
    case 'end': return to === 'start' && state.players[player].zones.hand.length <= state.config.handLimit;
    default: return false;
  }
}

export function canDeclareBasicAttack(state: GameState, player: PlayerId, cardId: string): boolean {
  const card = Object.hasOwn(state.cards, cardId) ? state.cards[cardId] : undefined;
  return state.result === null && state.phase === 'battle' && state.turnPlayer === player &&
    state.window.kind === 'open' && state.window.priorityPlayer === player &&
    state.chain.length === 0 && state.pendingTriggers.length === 0 &&
    card !== undefined && card.controller === player && card.face === 'up' &&
    card.location.player === player && (card.location.zone === 'normal' || card.location.zone === 'frontline') &&
    (state.counters[player].attacksDeclared[cardId] ?? 0) < 1 && !isKeywordStatusActive(state, cardId, 'freeze');
}
